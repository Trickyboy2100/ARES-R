from typing import Optional, Union

import numpy as np

from ._internal.epicraw_data import EpicRawDecoder
from ._internal.epicraw_parser import EpicRaw3DataType
from .epicraw_document import EpicRawDocument
from .epicraw_image import EpicRawImage


def try_load_epic_raw_document_from_bytes(raw_data: bytes):
    """将 EpicRaw 字节加载为可重复使用的 EpicRawDocument。"""
    return EpicRawDecoder.try_load_epic_raw_document_from_bytes(raw_data)


def decode_image_from_epicraw(
    epic_raw: EpicRawDocument,
    data_type: Optional[EpicRaw3DataType] = None,
) -> Optional[Union[np.ndarray, EpicRawImage]]:
    """解码纹理图，或按类型读取 EpicRaw3 原始图像并保留 MatType。"""
    return EpicRawDecoder.decode_image(_require_document(epic_raw), data_type)


def decode_depth_from_epicraw(epic_raw: EpicRawDocument):
    """从 EpicRawDocument 解码深度图。"""
    return EpicRawDecoder.decode_depth(_require_document(epic_raw))


def decode_camera_config_from_epicraw(epic_raw: EpicRawDocument):
    """从 EpicRaw1/2/3 文档解码拍摄时保存的相机配置。"""
    return EpicRawDecoder.decode_camera_config(_require_document(epic_raw))


def decode_point_cloud_from_epicraw(epic_raw: EpicRawDocument, undistort_lut=None):
    """从 EpicRawDocument 解码点云。"""
    return EpicRawDecoder.decode_point_cloud(_require_document(epic_raw), undistort_lut)


def get_depth_intrinsics_from_epicraw(epic_raw: EpicRawDocument):
    """从 EpicRawDocument 获取深度内参、畸变和分辨率。"""
    return EpicRawDecoder.get_depth_intrinsics(_require_document(epic_raw))


def decode_passive_binocular_images_from_epicraw(epic_raw: EpicRawDocument):
    """返回 (DepthSrcImg1, DepthSrcImg2, TextureBGR) NumPy 数组三元组。"""
    return EpicRawDecoder.decode_passive_binocular_images(_require_document(epic_raw))


def get_metadata_str_from_epicraw(
    epic_raw: EpicRawDocument,
    data_type: EpicRaw3DataType,
):
    """获取 EpicRaw3 指定元素的 MetaDataStr。"""
    return EpicRawDecoder.get_meta_data_str(_require_document(epic_raw), data_type)


def _require_document(epic_raw: EpicRawDocument) -> EpicRawDocument:
    if not isinstance(epic_raw, EpicRawDocument):
        raise TypeError(
            "epic_raw 必须是 EpicRawDocument，请先调用 "
            "try_load_epic_raw_document_from_bytes"
        )
    return epic_raw
