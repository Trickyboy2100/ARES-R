import numpy as np

from ._core import exception_handler, logger

_ALIGNED_ZC_THRESHOLD = 0.05


def _aligned_apply_distortion_and_project(xn, yn, texture_intrinsic, texture_distortion):
    fxc = float(texture_intrinsic[0, 0])
    fyc = float(texture_intrinsic[1, 1])
    cxc = float(texture_intrinsic[0, 2])
    cyc = float(texture_intrinsic[1, 2])
    k1, k2, p1, p2, k3 = (float(v) for v in texture_distortion)
    r2 = xn * xn + yn * yn
    r4 = r2 * r2
    r6 = r4 * r2
    radial = 1.0 + k1 * r2 + k2 * r4 + k3 * r6
    xd = xn * radial + 2.0 * p1 * xn * yn + p2 * (r2 + 2.0 * xn * xn)
    yd = yn * radial + p1 * (r2 + 2.0 * yn * yn) + 2.0 * p2 * xn * yn
    u_col = fxc * xd + cxc
    v_col = fyc * yd + cyc
    return u_col, v_col


def _aligned_bilinear_sample(texture, u_col, v_col, valid_mask):
    # 输出位深跟随纹理 dtype（8bit→uint8, 16bit→uint16），采样值域上限随之（255/65535）。
    out_dtype = texture.dtype
    max_val = 65535 if out_dtype == np.uint16 else 255
    out_h, out_w = valid_mask.shape
    out = np.zeros((out_h, out_w, 3), dtype=out_dtype)
    if not np.any(valid_mask):
        return out
    texture_h, texture_w = texture.shape[0], texture.shape[1]
    uc = u_col[valid_mask]
    vc = v_col[valid_mask]
    u0 = uc.astype(np.int32)
    v0 = vc.astype(np.int32)
    np.clip(u0, 0, texture_w - 2, out=u0)
    np.clip(v0, 0, texture_h - 2, out=v0)
    du = uc - u0
    dv = vc - v0
    inv_du = 1.0 - du
    inv_dv = 1.0 - dv
    w00 = inv_du * inv_dv
    w01 = du * inv_dv
    w10 = inv_du * dv
    w11 = du * dv
    p00 = texture[v0, u0].astype(np.float32)
    p01 = texture[v0, u0 + 1].astype(np.float32)
    p10 = texture[v0 + 1, u0].astype(np.float32)
    p11 = texture[v0 + 1, u0 + 1].astype(np.float32)
    sampled = p00 * w00[:, None] + p01 * w01[:, None] + p10 * w10[:, None] + p11 * w11[:, None] + 0.5
    np.clip(sampled, 0, max_val, out=sampled)
    out[valid_mask] = sampled.astype(out_dtype)
    return out


@exception_handler
def align_texture_from_depth(depth, texture, mat_type, depth_intrinsic, texture_intrinsic, texture_distortion, rotation, translation):
    # mat_type: 纹理的 OpenCV 类型编码（EpicRaw3 TextureBGR 元素 matType，如 CV_8UC3=16 / CV_16UC3=18）。
    # 决定期望位深并驱动采样/输出位深；深度源纹理是 16bit，按 8bit 会读错字节丢精度。
    depth = np.ascontiguousarray(depth, dtype=np.float32)
    texture = np.ascontiguousarray(texture)
    depth_intrinsic = np.asarray(depth_intrinsic, dtype=np.float64).reshape(3, 3)
    texture_intrinsic = np.asarray(texture_intrinsic, dtype=np.float64).reshape(3, 3)
    texture_distortion = np.asarray(texture_distortion, dtype=np.float64).reshape(-1)
    rotation = np.asarray(rotation, dtype=np.float64).reshape(3, 3)
    translation = np.asarray(translation, dtype=np.float64).reshape(-1)
    expected_dtype = np.uint16 if (int(mat_type) & 7) == 2 else np.uint8
    if texture.dtype != expected_dtype or texture.ndim != 3 or texture.shape[2] != 3:
        logger.error(f"align_texture_from_depth: texture must be (H,W,3) {np.dtype(expected_dtype).name} for mat_type={mat_type}")
        return None
    if depth.ndim != 2:
        logger.error("align_texture_from_depth: depth must be (H,W) float32")
        return None

    depth_h, depth_w = depth.shape
    inv_fx_d = 1.0 / float(depth_intrinsic[0, 0])
    inv_fy_d = 1.0 / float(depth_intrinsic[1, 1])
    cx_d = float(depth_intrinsic[0, 2])
    cy_d = float(depth_intrinsic[1, 2])
    u = np.arange(depth_w, dtype=np.float64)[None, :]
    v = np.arange(depth_h, dtype=np.float64)[:, None]
    z = depth.astype(np.float64, copy=False)
    x_d = (u - cx_d) * inv_fx_d * z
    y_d = (v - cy_d) * inv_fy_d * z
    xc = rotation[0, 0] * x_d + rotation[0, 1] * y_d + rotation[0, 2] * z + translation[0]
    yc = rotation[1, 0] * x_d + rotation[1, 1] * y_d + rotation[1, 2] * z + translation[1]
    zc = rotation[2, 0] * x_d + rotation[2, 1] * y_d + rotation[2, 2] * z + translation[2]
    valid = (z > 0) & (zc > _ALIGNED_ZC_THRESHOLD)
    inv_zc = np.zeros_like(zc)
    np.divide(1.0, zc, out=inv_zc, where=valid)
    xn = xc * inv_zc
    yn = yc * inv_zc
    u_col, v_col = _aligned_apply_distortion_and_project(xn, yn, texture_intrinsic, texture_distortion)
    texture_w_min = texture.shape[1] - 1
    texture_h_min = texture.shape[0] - 1
    valid &= (u_col >= 0) & (u_col < texture_w_min) & (v_col >= 0) & (v_col < texture_h_min)
    return _aligned_bilinear_sample(texture, u_col, v_col, valid)


@exception_handler
def align_texture_from_point_cloud(point_cloud, texture, mat_type, texture_intrinsic, texture_distortion, rotation, translation):
    # mat_type: 纹理 OpenCV 类型编码（同 align_texture_from_depth），决定采样/输出位深。
    point_cloud = np.ascontiguousarray(point_cloud, dtype=np.float32)
    texture = np.ascontiguousarray(texture)
    texture_intrinsic = np.asarray(texture_intrinsic, dtype=np.float64).reshape(3, 3)
    texture_distortion = np.asarray(texture_distortion, dtype=np.float64).reshape(-1)
    rotation = np.asarray(rotation, dtype=np.float64).reshape(3, 3)
    translation = np.asarray(translation, dtype=np.float64).reshape(-1)
    expected_dtype = np.uint16 if (int(mat_type) & 7) == 2 else np.uint8
    if texture.dtype != expected_dtype or texture.ndim != 3 or texture.shape[2] != 3:
        logger.error(f"align_texture_from_point_cloud: texture must be (H,W,3) {np.dtype(expected_dtype).name} for mat_type={mat_type}")
        return None
    if point_cloud.ndim != 3 or point_cloud.shape[2] != 3:
        logger.error("align_texture_from_point_cloud: point_cloud must be (H,W,3) float32")
        return None
    x = point_cloud[..., 0].astype(np.float64, copy=False)
    y = point_cloud[..., 1].astype(np.float64, copy=False)
    z = point_cloud[..., 2].astype(np.float64, copy=False)
    xc = rotation[0, 0] * x + rotation[0, 1] * y + rotation[0, 2] * z + translation[0]
    yc = rotation[1, 0] * x + rotation[1, 1] * y + rotation[1, 2] * z + translation[1]
    zc = rotation[2, 0] * x + rotation[2, 1] * y + rotation[2, 2] * z + translation[2]
    valid = (z > 0) & (zc > _ALIGNED_ZC_THRESHOLD)
    inv_zc = np.zeros_like(zc)
    np.divide(1.0, zc, out=inv_zc, where=valid)
    xn = xc * inv_zc
    yn = yc * inv_zc
    u_col, v_col = _aligned_apply_distortion_and_project(xn, yn, texture_intrinsic, texture_distortion)
    texture_w_min = texture.shape[1] - 1
    texture_h_min = texture.shape[0] - 1
    valid &= (u_col >= 0) & (u_col < texture_w_min) & (v_col >= 0) & (v_col < texture_h_min)
    return _aligned_bilinear_sample(texture, u_col, v_col, valid)
