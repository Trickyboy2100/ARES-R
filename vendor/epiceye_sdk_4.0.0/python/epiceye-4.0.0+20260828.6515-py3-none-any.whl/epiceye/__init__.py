from .epiceye import *
from .camera_parameters import CameraParametersConfig, IntrinsicParams, ReconstructorType, SwingLineScanLightPlaneParams, TransformationReference
from .stream2d import start_stream2d_rtc_session, stop_stream2d_rtc_session

SDK_VERSION = "4.0.0"


def get_sdk_version():
    return SDK_VERSION
