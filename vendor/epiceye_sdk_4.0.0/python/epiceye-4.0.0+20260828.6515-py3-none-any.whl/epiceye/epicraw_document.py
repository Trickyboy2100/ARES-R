"""EpicRaw 已解析文档数据模型。"""

from ._internal.epicraw_parser import FileType


class EpicRawDocument:
    """由 TryLoad 得到的已解析 EpicRaw，仅持有 Raw1 / Raw2 / Raw3 之一。"""

    def __init__(self, file_type: FileType, raw1=None, raw2=None, raw3=None):
        self.file_type = file_type
        self.raw1 = raw1
        self.raw2 = raw2
        self.raw3 = raw3
