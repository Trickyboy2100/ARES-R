import hashlib
import ipaddress
import json
import socket
import struct
import time
from typing import Callable, Optional

from ._core import _request, exception_handler, logger
from ._internal.discovery_monitor import DiscoveryMonitor

# 设置相机 IP 使用的多播地址与端口（与 C# SetEpicEyeIPConfig 一致）
_IP_CONFIG_MULTICAST_ADDR_IPV4 = "224.0.0.251"
_IP_CONFIG_MULTICAST_ADDR_IPV6 = "ff02::fb"
_IP_CONFIG_MULTICAST_PORT = 5661


@exception_handler
def start_discovery() -> None:
    """启动后台相机发现。"""
    DiscoveryMonitor.start()


@exception_handler
def stop_discovery() -> None:
    """停止后台相机发现。"""
    DiscoveryMonitor.stop()


@exception_handler
def get_discovered_cameras():
    """获取当前发现的相机列表快照。"""
    return DiscoveryMonitor.get_epiceye_list()


@exception_handler
def clear_discovered_cameras():
    """清空当前发现的相机列表。"""
    return DiscoveryMonitor.clear_epiceye_list()


@exception_handler
def set_discovery_callback(callback: Optional[Callable[[], None]]) -> None:
    """设置发现列表变化回调。"""
    DiscoveryMonitor.set_callback(callback)


@exception_handler
def get_info(ip: str):
    """获取相机信息，兼容 V3（裸 EpicEyeInfo）与 V4（包装 ApiResponse）。"""
    response = _request(ip, "get_info")
    if response is None:
        return None
    info = json.loads(response.content)
    if isinstance(info, dict) and "status" in info and "data" in info:
        if info.get("status", -1) != 0:
            logger.warning(f"get_info failed: {info.get('errorMessage')}")
            return None
        return info.get("data")
    return info


@exception_handler
def get_reconstructor_type(ip: str):
    """获取重建器类型（V4）。返回枚举整型：0=Mono，1=BinoWithoutColor，2=BinoWithColor，999=Unknown。"""
    response = _request(ip, "get_reconstructor_type")
    if response is None:
        return None
    body = json.loads(response.content)
    if not isinstance(body, dict) or body.get("status", -1) != 0:
        logger.warning(f"get_reconstructor_type failed: {body.get('errorMessage') if isinstance(body, dict) else body}")
        return None
    data = body.get("data")
    # v4 服务端返回的是枚举名字符串（如 "Mono"/"BinoWithColor"），按返回契约（docstring 承诺整型）映射成整型
    name_to_value = {"Mono": 0, "BinoWithoutColor": 1, "BinoWithColor": 2, "Unknown": 999}
    if isinstance(data, str):
        return name_to_value.get(data, 999)
    return data


@exception_handler
def get_temperature_info(ip: str, use_cache: bool = True) -> Optional[dict]:
    """获取相机内部温度信息（V4）。use_cache=False 时强制读取硬件温度。"""
    response = _request(ip, "get_temperature_info", str(use_cache).lower())
    if response is None:
        return None
    body = json.loads(response.content)
    if not isinstance(body, dict) or body.get("status", -1) != 0:
        logger.warning(f"get_temperature_info failed: {body.get('errorMessage') if isinstance(body, dict) else body}")
        return None
    data = body.get("data")
    if not isinstance(data, str):
        logger.warning("get_temperature_info failed: response data is not a JSON string")
        return None
    temperature_info = json.loads(data)
    if not isinstance(temperature_info, dict):
        logger.warning("get_temperature_info failed: temperature data is not a JSON object")
        return None
    return temperature_info


@exception_handler
def search_camera():
    """通过 UDP 广播自动搜索局域网内的相机，整个调用最多等待约 5 秒。"""
    port_list = [5665, 5666, 5667, 5668]
    found_camera = []
    camera_hash = set()
    sock_server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    bound = False
    for port in port_list:
        try:
            sock_server.bind(("0.0.0.0", port))
            bound = True
            break
        except Exception as ex:
            logger.error(f"{port}: {ex}")
    if not bound:
        sock_server.close()
        logger.error("search_camera: all candidate ports occupied")
        return None
    # 加入多播组，接收相机广播（224.0.0.251）
    mcast_group = "224.0.0.251"
    try:
        mreq = struct.pack("4sI", socket.inet_aton(mcast_group), socket.INADDR_ANY)
        sock_server.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    except Exception as ex:
        logger.error(f"join multicast group failed: {ex}")
    deadline = time.monotonic() + 5.0
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            sock_server.settimeout(remaining)
            try:
                payload, address = sock_server.recvfrom(1024)
            except socket.timeout:
                break
            try:
                data = json.loads(payload.decode("utf-8"))
                if "127.0.0.1" in data["ip"]:
                    data["ip"] = data["ip"].replace("127.0.0.1", address[0])
                if ":" not in data["ip"]:
                    data["ip"] += ":5000"
                data_hash = hashlib.sha256(data["ip"].encode("ascii")).hexdigest()
                if data_hash in camera_hash:
                    continue
                camera_hash.add(data_hash)
                found_camera.append(data)
                logger.info(f"receive data: {data}")
            except (KeyError, TypeError, UnicodeDecodeError, json.JSONDecodeError) as ex:
                logger.info(f"search_camera: ignore invalid broadcast from {address[0]}: {ex}")
    finally:
        sock_server.close()
    return found_camera if found_camera else None


def _local_ipv4_addresses():
    """尽力枚举本机 IPv4 地址，用于在每个网卡上向多播地址发送配置。"""
    addresses = set()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            addresses.add(info[4][0])
    except Exception as ex:
        logger.info(f"getaddrinfo failed: {ex}")
    # 再补一个默认出口地址（多网卡时更可靠）
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("8.8.8.8", 80))
        addresses.add(probe.getsockname()[0])
        probe.close()
    except Exception:
        pass
    return addresses


def _ipv6_multicast_interface_indexes():
    """枚举 IPv6 多播出口网卡；发送时由系统过滤未启用 IPv6 的接口。"""
    try:
        active_indexes = {
            address[3]
            for _, _, _, _, address in socket.getaddrinfo(
                socket.gethostname(), None, socket.AF_INET6, socket.SOCK_DGRAM
            )
            if address[3] > 0
        }
        if active_indexes:
            return active_indexes

        return {
            index
            for index, name in socket.if_nameindex()
            if index > 0 and name.lower() not in {"lo", "lo0"} and "loopback" not in name.lower()
        }
    except Exception as ex:
        logger.info(f"if_nameindex failed: {ex}")
        return set()


@exception_handler
def set_epiceye_ip_config(
    ip: str,
    new_ip: str = None,
    netmask: str = "255.255.255.0",
    ip_type: str = "DHCP",
    sn: str = "IMPOSSIBLE_SERIAL_NUMBER",
) -> bool:
    """设置相机 IP 地址配置（UDP 目标单播优先，并保留 IPv4/IPv6 多播兼容路径）。

    参数:
        ip: 目标相机当前的 IP（DestinationIP），用于定位要修改的相机。
        new_ip: 手动模式下要设置的新 IP；`ip_type="DHCP"` 时可不传。
        netmask: 子网掩码，默认 ``255.255.255.0``。
        ip_type: ``"DHCP"`` 或 ``"Manual"``。
        sn: 目标相机当前序列号，必须与设备一致，用于防止误改其他相机。

    返回:
        是否至少成功从一个网卡发出配置报文。
    """
    if not ip:
        return False

    # 手动模式必须给出合法 IPv4
    if ip_type != "DHCP":
        try:
            ipaddress.IPv4Address(new_ip)
        except Exception:
            logger.error(f"set_epiceye_ip_config: invalid manual IP: {new_ip}")
            return False

    # 字段名需与 C# EpicEyeIPConfig 序列化保持一致（PascalCase）
    message = {
        "DestinationIP": ip,
        "IP": new_ip,
        "NetMask": netmask,
        "Type": ip_type,
        "SN": sn,
    }
    data = json.dumps(message).encode("ascii")

    sent = False
    unicast_socket = None
    try:
        destination_ip = str(ipaddress.IPv4Address(ip))
        unicast_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        unicast_socket.sendto(data, (destination_ip, _IP_CONFIG_MULTICAST_PORT))
        sent = True
    except Exception as ex:
        logger.info(f"set_epiceye_ip_config unicast to {ip} failed: {ex}")
    finally:
        if unicast_socket is not None:
            unicast_socket.close()

    # UDP 没有配置结果 ACK；保留逐网卡组播发送，兼容旧相机及不同 IPv4 子网的直连场景。
    addresses = _local_ipv4_addresses() or {"0.0.0.0"}
    for local_ip in addresses:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((local_ip, 0))
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
            sock.sendto(data, (_IP_CONFIG_MULTICAST_ADDR_IPV4, _IP_CONFIG_MULTICAST_PORT))
            sock.close()
            sent = True
        except Exception as ex:
            logger.error(f"set_epiceye_ip_config via {local_ip} failed: {ex}")

    # 3.4.9 等旧相机端只加入 IPv6 组播组。链路本地组播必须显式指定接口索引，
    # 否则多网卡系统会走默认路由，出现能发现相机但配置报文到不了直连网卡的情况。
    for interface_index in _ipv6_multicast_interface_indexes():
        sock = None
        try:
            sock = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
            sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_MULTICAST_IF, interface_index)
            sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_MULTICAST_HOPS, 1)
            sock.sendto(
                data,
                (_IP_CONFIG_MULTICAST_ADDR_IPV6, _IP_CONFIG_MULTICAST_PORT, 0, interface_index),
            )
            sent = True
        except Exception as ex:
            logger.info(f"set_epiceye_ip_config IPv6 via ifindex {interface_index} failed: {ex}")
        finally:
            if sock is not None:
                sock.close()
    return sent
