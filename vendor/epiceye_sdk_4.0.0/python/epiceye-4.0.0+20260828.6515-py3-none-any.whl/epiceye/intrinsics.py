import json
from typing import Any, Dict, Optional

import numpy as np

from ._core import (
    _get_or_detect_version,
    _is_v4,
    _parse_api_data_or_none,
    _request,
    compute_array_hash,
    exception_handler,
    undistort_lut_dict,
)


@exception_handler
def get_camera_matrix(ip: str):
    """获取相机内参矩阵，兼容 V3 和 V4。"""
    version = _get_or_detect_version(ip)
    response = _request(ip, "get_camera_matrix")
    if response is None:
        return None
    if _is_v4(version):
        return _parse_api_data_or_none(response, "get_camera_matrix")
    return json.loads(response.content)


@exception_handler
def get_distortion(ip: str):
    """获取相机畸变系数，兼容 V3 和 V4。"""
    version = _get_or_detect_version(ip)
    response = _request(ip, "get_distortion")
    if response is None:
        return None
    if _is_v4(version):
        return _parse_api_data_or_none(response, "get_distortion")
    return json.loads(response.content)


@exception_handler
def get_camera_parameters(ip: str) -> Optional[Dict[str, Any]]:
    """读取相机保存的完整内外参 JSON。"""
    version = _get_or_detect_version(ip)
    response = _request(ip, "get_camera_parameters")
    if response is None:
        return None

    if _is_v4(version):
        data = _parse_api_data_or_none(response, "get_camera_parameters")
        if not isinstance(data, dict):
            return None
        return data

    data = json.loads(response.content)
    if isinstance(data, str):
        data = json.loads(data)
    if not isinstance(data, dict):
        return None
    return data


@exception_handler
def get_undistort_lut(
    ip: str,
    depth_width: int,
    depth_height: int,
    camera_matrix=None,
    distortion=None,
):
    """获取去畸变查找表，兼容 V3 和 V4。"""
    if depth_width <= 0 or depth_height <= 0:
        return None
    if distortion is not None and len(distortion) > 0 and all(
        float(value) == 0.0 for value in distortion
    ):
        return None

    is_v4 = _is_v4(_get_or_detect_version(ip))
    if is_v4 and (
        camera_matrix is None
        or len(camera_matrix) < 9
        or distortion is None
        or len(distortion) == 0
    ):
        return None

    if is_v4:
        cache_key = (
            f"{ip}_{depth_width}x{depth_height}"
            f"_{compute_array_hash(camera_matrix)}_{compute_array_hash(distortion)}"
        )
    else:
        cache_key = ip

    if cache_key in undistort_lut_dict:
        return undistort_lut_dict[cache_key]

    if is_v4:
        camera_matrix_arg = ",".join(str(value) for value in camera_matrix)
        distortion_arg = ",".join(str(value) for value in distortion)
        response = _request(
            ip,
            "get_undistort_lut",
            depth_width,
            depth_height,
            camera_matrix_arg,
            distortion_arg,
        )
    else:
        response = _request(ip, "get_undistort_lut")

    if response is None:
        return None
    result = np.frombuffer(response.content, dtype=np.float32).reshape(
        depth_height,
        depth_width,
        2,
    )
    undistort_lut_dict[cache_key] = result
    return result


@exception_handler
def compute_undistort_lut(width: int, height: int, camera_matrix, distortion):
    """离线计算去畸变 LUT，返回 (height, width, 2) 的 float32 数组。"""
    if width <= 0 or height <= 0:
        return None
    if camera_matrix is None or distortion is None or len(camera_matrix) < 9:
        return None
    if all(abs(float(value)) < 1e-8 for value in distortion):
        return None

    fx = float(camera_matrix[0])
    fy = float(camera_matrix[4])
    cx = float(camera_matrix[2])
    cy = float(camera_matrix[5])
    k1 = float(distortion[0]) if len(distortion) > 0 else 0.0
    k2 = float(distortion[1]) if len(distortion) > 1 else 0.0
    p1 = float(distortion[2]) if len(distortion) > 2 else 0.0
    p2 = float(distortion[3]) if len(distortion) > 3 else 0.0
    k3 = float(distortion[4]) if len(distortion) > 4 else 0.0

    lut = np.zeros((height, width, 2), dtype=np.float32)
    for row in range(height):
        for column in range(width):
            x0 = (column - cx) / fx
            y0 = (row - cy) / fy
            x, y = x0, y0
            for _ in range(5):
                radius_squared = x * x + y * y
                radial = (
                    1.0
                    + k1 * radius_squared
                    + k2 * radius_squared * radius_squared
                    + k3 * radius_squared * radius_squared * radius_squared
                )
                delta_x = 2.0 * p1 * x * y + p2 * (radius_squared + 2.0 * x * x)
                delta_y = p1 * (radius_squared + 2.0 * y * y) + 2.0 * p2 * x * y
                x = (x0 - delta_x) / radial
                y = (y0 - delta_y) / radial
            lut[row, column, 0] = x * fx + cx
            lut[row, column, 1] = y * fy + cy
    return lut
