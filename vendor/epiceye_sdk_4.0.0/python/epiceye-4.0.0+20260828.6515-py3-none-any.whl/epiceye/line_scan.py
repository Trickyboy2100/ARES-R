import struct
import time
from typing import Optional

from websockets.exceptions import ConnectionClosed
from websockets.sync.client import connect

from ._core import (
    LineScanStartRequest,
    _parse_api_data_or_none,
    _request,
    _to_payload,
    exception_handler,
    logger,
)

_LINE_SCAN_HEADER_SIZE = 12
_LINE_SCAN_STATUS_OFFSET = 4
_LINE_SCAN_SUCCESS_STATUS = 0
_LINE_SCAN_EOT_STATUS = 0xFF


@exception_handler
def start_line_scan(ip: str, enable_texture: bool = True, defer_epic_raw_save: bool = True):
    """启动线扫流，返回服务端分配的会话数据（含 frameId）。"""
    response = _request(ip, "line_scan_start", content=_to_payload(
        LineScanStartRequest(enableTexture=enable_texture, deferEpicRawSave=defer_epic_raw_save)))
    return _parse_api_data_or_none(response, "start_line_scan")


@exception_handler
def stop_line_scan(ip: str):
    """停止线扫流，返回服务端停止状态码。"""
    response = _request(ip, "line_scan_stop")
    data = _parse_api_data_or_none(response, "stop_line_scan")
    if isinstance(data, dict):
        return data.get("status")
    return data


@exception_handler
def get_line_scan_status(ip: str):
    """获取线扫状态。"""
    response = _request(ip, "line_scan_status")
    return _parse_api_data_or_none(response, "get_line_scan_status")


@exception_handler
def wait_line_scan_completion(ip: str, timeout_ms: int = 60000) -> Optional[bool]:
    """
    等待线扫完成。完成后即可通过 frameId 获取 EpicRaw 数据。
    连接线扫 WebSocket 并持续消费数据，收到 EOT（0xFF）时返回 True；
    收到异常状态、连接提前关闭或超时时返回 False。
    """
    deadline = time.monotonic() + timeout_ms / 1000.0
    websocket_url = f"ws://{ip}/api/LineScan/Connect"
    open_timeout = max(deadline - time.monotonic(), 0.001)

    try:
        with connect(
            websocket_url,
            open_timeout=open_timeout,
            close_timeout=1,
            max_size=None,
        ) as websocket:
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    logger.warning("wait_line_scan_completion timed out before EOT.")
                    return False

                message = websocket.recv(timeout=remaining)
                if not isinstance(message, bytes) or len(message) < _LINE_SCAN_HEADER_SIZE:
                    logger.warning("wait_line_scan_completion ignored malformed WebSocket message.")
                    continue

                status = struct.unpack_from("<i", message, _LINE_SCAN_STATUS_OFFSET)[0]
                if status == _LINE_SCAN_SUCCESS_STATUS:
                    continue
                if status == _LINE_SCAN_EOT_STATUS:
                    return True

                logger.warning(
                    f"wait_line_scan_completion received line scan error status: 0x{status:X}"
                )
                return False
    except TimeoutError:
        logger.warning("wait_line_scan_completion timed out before EOT.")
        return False
    except ConnectionClosed as ex:
        logger.warning(f"wait_line_scan_completion WebSocket closed before EOT: {ex}")
        return False
