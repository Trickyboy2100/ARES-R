import json
from dataclasses import dataclass
from typing import Any, Dict, Optional

from ._core import (
    _get_or_detect_version,
    _is_v4,
    _parse_api_data_or_none,
    _parse_api_success,
    _request,
    exception_handler,
    logger,
)


@dataclass(frozen=True, slots=True)
class SimpleCameraParameter:
    Id: str
    Name: str


@exception_handler
def get_config(ip: str):
    """获取当前相机配置，兼容 V3 / V4。"""
    version = _get_or_detect_version(ip)
    response = _request(ip, "get_config")
    if response is None:
        return None
    if _is_v4(version):
        return _parse_api_data_or_none(response, "get_config")
    # V3 返回的是被 JSON 序列化过的字符串，需要二次反序列化
    inner = json.loads(response.content)
    if isinstance(inner, str):
        return json.loads(inner)
    return inner


@exception_handler
def set_config(ip: str, config: Dict[str, Any]):
    """设置相机配置，兼容 V3 / V4。"""
    version = _get_or_detect_version(ip)
    response = _request(ip, "set_config", content=config)
    if _is_v4(version):
        return _parse_api_success(response, "set_config", require_true_data=True)
    return response is not None


@exception_handler
def get_parameter_list(ip: str) -> Optional[list[SimpleCameraParameter]]:
    """获取相机参数预设列表，并统一为 ``SimpleCameraParameter``。"""
    version = _get_or_detect_version(ip)
    response = _request(ip, "get_parameter_list")
    data = _parse_api_data_or_none(response, "get_parameter_list")
    if not isinstance(data, list):
        logger.warning("get_parameter_list failed: response data is not a list")
        return None

    presets: list[SimpleCameraParameter] = []
    if _is_v4(version):
        for item in data:
            if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not item["id"] or not isinstance(item.get("name"), str):
                logger.warning("get_parameter_list failed: V4 preset must contain exact string fields 'id' and 'name'")
                return None
            presets.append(SimpleCameraParameter(Id=item["id"], Name=item["name"]))
    else:
        for item in data:
            if not isinstance(item, dict) or not isinstance(item.get("Id"), str) or not item["Id"] or not isinstance(item.get("Name"), str):
                logger.warning("get_parameter_list failed: V3 preset must contain exact string fields 'Id' and 'Name'")
                return None
            presets.append(SimpleCameraParameter(Id=item["Id"], Name=item["Name"]))

    return presets


@exception_handler
def get_config_style(ip: str):
    """获取相机参数样式，兼容 V3 / V4。V3 的 data 是被 JSON 序列化过的字符串，需二次反序列化。"""
    response = _request(ip, "get_config_style")
    data = _parse_api_data_or_none(response, "get_config_style")
    if isinstance(data, str):
        return json.loads(data)
    return data


@exception_handler
def set_parameter(ip: str, param_id: str):
    """通过 paramId 切换相机参数；V3 走 query，V4 走 body。"""
    if not param_id:
        return False
    version = _get_or_detect_version(ip)
    if _is_v4(version):
        response = _request(ip, "set_parameter", content={"id": param_id})
    else:
        response = _request(ip, "set_parameter", param_id)
    return _parse_api_success(response, "set_parameter", require_true_data=_is_v4(version))
