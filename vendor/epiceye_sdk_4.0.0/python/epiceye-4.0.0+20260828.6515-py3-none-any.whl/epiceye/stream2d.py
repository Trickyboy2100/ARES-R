import asyncio
import copy
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from ._core import _parse_api_data_or_none, _request, exception_handler, logger


@exception_handler
def get_stream2d_status(ip: str):
    """获取 2D 流状态。"""
    response = _request(ip, "stream2d_status")
    return _parse_api_data_or_none(response, "get_stream2d_status")


@exception_handler
def start_stream2d(ip: str, offer_sdp: str, fps: int = 60, camera_index: int = 0):
    """通过 WebRTC Offer 开启 2D 流。"""
    if not offer_sdp:
        return None
    response = _request(
        ip,
        "stream2d_webrtc_offer",
        content={
            "sdp": offer_sdp,
            "fps": fps,
            "cameraIndex": camera_index,
        },
    )
    return _parse_api_data_or_none(response, "start_stream2d")


@exception_handler
def stop_stream2d(ip: str, peer_id: str):
    """通过 peerId 关闭指定 2D WebRTC 流。"""
    if not peer_id:
        return False
    response = _request(ip, "stream2d_webrtc_stop", content={"peerId": peer_id})
    if response is None:
        return False
    body = json.loads(response.content)
    return body.get("status", -1) == 0


@exception_handler
def stop_all_stream2d(ip: str):
    """停止全部 2D WebRTC 流。"""
    response = _request(ip, "stream2d_webrtc_stop_all")
    if response is None:
        return False
    body = json.loads(response.content)
    return body.get("status", -1) == 0


@dataclass
class Stream2DSessionResult:
    frame_count: int
    peer_id: Optional[str]


@dataclass
class Stream2DSession:
    ip: str
    pc: Any
    result: Stream2DSessionResult
    done: asyncio.Event
    progress_log_interval: int
    debug: bool
    on_frame: Optional[Callable[[int, Any], None]] = None
    track_task: Optional[asyncio.Task] = None
    stats_task: Optional[asyncio.Task] = None
    track_receiver: Any = None
    pli_sent: bool = False
    _close_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    _closed: bool = False

# Some cameras hardcode PT=96 for H264 in their WebRTC answer regardless of what the offer says.
# We reserve PT=96 for H264 so the camera's answer is a valid selection and aiortc can decode it.
H264_RESERVED_PAYLOAD_TYPE = 96

H264_PROFILE_VARIANTS = (
    ("1", "42001f"),
    ("1", "42e01f"),
    ("1", "4d001f"),
    ("1", "64001f"),
    ("0", "42e01f"),
)


def should_log_frame_progress(frame_count: int, interval: int = 30):
    if frame_count <= 0:
        return False
    if frame_count == 1:
        return True
    return interval > 0 and frame_count % interval == 0


def should_request_keyframe(packets_received: int, frame_count: int, pli_already_sent: bool):
    return packets_received > 0 and frame_count == 0


def build_extended_video_codecs(video_codecs):
    extended_codecs = [copy.deepcopy(codec) for codec in video_codecs]
    next_payload_type = (
        max((codec.get("payloadType", 96) for codec in extended_codecs), default=96) + 1
    )
    existing_variants = {
        (
            codec.get("parameters", {}).get("packetization-mode"),
            codec.get("parameters", {}).get("profile-level-id", "").lower(),
        )
        for codec in extended_codecs
        if codec.get("mimeType", "").lower() == "video/h264"
    }
    template = next(
        (c for c in extended_codecs if c.get("mimeType", "").lower() == "video/h264"),
        None,
    )
    if template is None:
        return extended_codecs

    template_feedback = copy.deepcopy(template.get("rtcpFeedback", []))
    for packetization_mode, profile_level_id in H264_PROFILE_VARIANTS:
        if (packetization_mode, profile_level_id) in existing_variants:
            continue
        extended_codecs.append(
            {
                "mimeType": "video/H264",
                "clockRate": template.get("clockRate", 90000),
                "payloadType": next_payload_type,
                "rtcpFeedback": copy.deepcopy(template_feedback),
                "parameters": {
                    "level-asymmetry-allowed": "1",
                    "packetization-mode": packetization_mode,
                    "profile-level-id": profile_level_id,
                },
            }
        )
        next_payload_type += 1
    return extended_codecs


def ensure_extended_h264_capabilities():
    from aiortc.codecs import CODECS
    from aiortc.rtcrtpparameters import RTCRtcpFeedback, RTCRtpCodecParameters

    codec_dicts = [
        {
            "mimeType": codec.mimeType,
            "clockRate": codec.clockRate,
            "payloadType": codec.payloadType,
            "rtcpFeedback": [
                {"type": fb.type, "parameter": fb.parameter}
                for fb in codec.rtcpFeedback
            ],
            "parameters": dict(codec.parameters),
        }
        for codec in CODECS["video"]
    ]

    extended_codec_dicts = build_extended_video_codecs(codec_dicts)

    # If H264_RESERVED_PAYLOAD_TYPE is not yet occupied, prepend an H264 entry with that PT.
    # This makes the camera's hardcoded PT answer a valid selection and lets aiortc route
    # incoming RTP packets to the H264 decoder instead of dropping them.
    used_pts = {c["payloadType"] for c in extended_codec_dicts}
    if H264_RESERVED_PAYLOAD_TYPE not in used_pts:
        h264_template = next(
            (c for c in extended_codec_dicts if "h264" in c.get("mimeType", "").lower()),
            None,
        )
        if h264_template:
            extended_codec_dicts = [
                {
                    "mimeType": "video/H264",
                    "clockRate": 90000,
                    "payloadType": H264_RESERVED_PAYLOAD_TYPE,
                    "rtcpFeedback": copy.deepcopy(h264_template.get("rtcpFeedback", [])),
                    "parameters": {
                        "level-asymmetry-allowed": "1",
                        "packetization-mode": "1",
                        "profile-level-id": "42001f",
                    },
                }
            ] + extended_codec_dicts

    if len(extended_codec_dicts) == len(codec_dicts):
        return

    CODECS["video"] = [
        RTCRtpCodecParameters(
            mimeType=codec["mimeType"],
            clockRate=codec["clockRate"],
            payloadType=codec["payloadType"],
            rtcpFeedback=[
                RTCRtcpFeedback(
                    type=fb["type"],
                    parameter=fb.get("parameter"),
                )
                for fb in codec.get("rtcpFeedback", [])
            ],
            parameters=codec.get("parameters", {}),
        )
        for codec in extended_codec_dicts
    ]


def _log_sdp_summary(label: str, sdp: str, debug: bool = False):
    if not debug:
        return
    codecs, candidates = [], []
    for line in sdp.splitlines():
        if line.startswith("a=rtpmap:") or line.startswith("a=fmtp:"):
            codecs.append(line)
        elif line.startswith("a=candidate:"):
            candidates.append(line)
    logger.info(f"Stream2D {label} SDP codecs: {codecs}")
    logger.info(f"Stream2D {label} SDP ICE candidates ({len(candidates)}): {candidates}")


async def start_stream2d_peer(
    ip: str,
    fps: int,
    camera_index: int,
    peer_connection=None,
    debug: bool = False,
):
    from aiortc import RTCPeerConnection, RTCSessionDescription
    from aiortc.exceptions import OperationError

    pc = peer_connection or RTCPeerConnection()
    pc.addTransceiver("video", direction="recvonly")
    offer = await pc.createOffer()
    await pc.setLocalDescription(offer)

    _log_sdp_summary("offer", pc.localDescription.sdp, debug=debug)

    response = start_stream2d(ip, pc.localDescription.sdp, fps=fps, camera_index=camera_index)
    if not response:
        raise RuntimeError(
            "start_stream2d returned an empty response, so the realtime video stream could not be established."
        )

    peer_id = response.get("peerId")
    answer_sdp = response.get("answerSdp")
    if not peer_id or not answer_sdp:
        raise RuntimeError(f"start_stream2d returned incomplete data: {response}")

    _log_sdp_summary("answer", answer_sdp, debug=debug)

    try:
        await pc.setRemoteDescription(RTCSessionDescription(sdp=answer_sdp, type="answer"))
    except OperationError as ex:
        logger.error(f"Stream2D answer SDP codec negotiation failed: {repr(ex)}")
        logger.error(f"Stream2D answer SDP was:\n{answer_sdp}")
        raise

    return pc, peer_id, answer_sdp


async def cleanup_stream2d_peer(
    ip: str,
    peer_connection,
    peer_id: Optional[str],
):
    if peer_id:
        stopped = stop_stream2d(ip, peer_id)
        logger.info(f"Stream2D stop requested: peer_id={peer_id}, success={stopped}")

    await peer_connection.close()
    logger.info(f"Stream2D status after stop: {get_stream2d_status(ip)}")


def process_stream2d_frame(session: Stream2DSession, frame):
    session.result.frame_count += 1

    if should_log_frame_progress(session.result.frame_count, session.progress_log_interval):
        logger.info(f"Stream2D frame received: count={session.result.frame_count}")

    if session.on_frame is not None:
        session.on_frame(session.result.frame_count, frame)


async def log_stream2d_receiver_stats(track_receiver, frame_count: int):
    stats = await track_receiver.getStats()
    inbound_stats = [v for v in stats.values() if getattr(v, "type", None) == "inbound-rtp"]
    packets_received = sum(getattr(s, "packetsReceived", 0) for s in inbound_stats)
    packets_lost = sum(getattr(s, "packetsLost", 0) for s in inbound_stats)
    logger.info(
        f"Stream2D receiver stats: packets_received={packets_received}, "
        f"packets_lost={packets_lost}, decoded_frames={frame_count}"
    )
    return inbound_stats, packets_received, packets_lost


async def request_stream2d_keyframe_if_needed(
    track_receiver, inbound_stats, packets_received: int, frame_count: int, pli_sent: bool
):
    if not should_request_keyframe(packets_received, frame_count, pli_sent):
        return pli_sent
    for item in inbound_stats:
        ssrc = getattr(item, "ssrc", None)
        if ssrc:
            try:
                await track_receiver._send_rtcp_pli(ssrc)
                logger.info(f"Stream2D requested a keyframe via RTCP PLI for SSRC {ssrc}.")
                return True
            except Exception as ex:
                logger.warning(f"Stream2D failed to request a keyframe: {repr(ex)}")
                return pli_sent
    return pli_sent


class _EncodedH264Frame:
    """透传用的 H264 编码帧（Annex-B NAL），不解码。on_frame 回调可取 .data 拿到原始码流。"""

    def __init__(self, data, pts):
        self.data = bytes(data)
        self.pts = pts


class _H264PassthroughDecoder:
    """绕过 aiortc 的 H264 解码，直接透传 jitter buffer 组装好的完整 access unit。

    与 SDK"透传不解码"定位一致；解决某些相机的 H264 流 aiortc 解不出（decoded_frames=0）拿不到帧的问题。
    """

    def decode(self, encoded_frame):
        return [_EncodedH264Frame(encoded_frame.data, getattr(encoded_frame, "timestamp", None))]


_h264_passthrough_installed = False


def _install_h264_passthrough_decoder():
    """把 aiortc 接收侧的 H264 解码器替换为透传器（幂等）。"""
    global _h264_passthrough_installed
    if _h264_passthrough_installed:
        return
    import aiortc.rtcrtpreceiver as _recv

    _orig_get_decoder = _recv.get_decoder

    def _patched_get_decoder(codec):
        if getattr(codec, "name", "").upper() == "H264":
            return _H264PassthroughDecoder()
        return _orig_get_decoder(codec)

    _recv.get_decoder = _patched_get_decoder
    _h264_passthrough_installed = True


async def consume_stream2d_track(session: Stream2DSession, track):
    try:
        while not session.done.is_set():
            frame = await track.recv()
            process_stream2d_frame(session, frame)
    except asyncio.CancelledError:
        raise
    except Exception as ex:
        logger.warning(f"Stream2D receive loop ended: {repr(ex)}")
        session.done.set()


async def monitor_stream2d_receiver_stats(session: Stream2DSession):
    while not session.done.is_set():
        await asyncio.sleep(1.0)
        if session.result.frame_count > 0:
            return
        if session.track_receiver is None:
            continue
        try:
            inbound_stats, packets_received, _ = await log_stream2d_receiver_stats(
                session.track_receiver, session.result.frame_count
            )
        except Exception as ex:
            logger.warning(f"Stream2D receiver stats failed: {repr(ex)}")
            continue

        session.pli_sent = await request_stream2d_keyframe_if_needed(
            session.track_receiver,
            inbound_stats,
            packets_received,
            session.result.frame_count,
            session.pli_sent,
        )


def attach_stream2d_track_handler(session: Stream2DSession):
    @session.pc.on("track")
    def on_track(track):
        logger.info(f"Stream2D track received: kind={track.kind}")
        if track.kind == "video":
            session.track_receiver = next(
                (r for r in session.pc.getReceivers() if r.track and r.track.kind == "video"),
                None,
            )
            logger.info(
                "Stream2D receiver binding: "
                f"{'attached' if session.track_receiver is not None else 'missing'}"
            )
            session.track_task = asyncio.create_task(consume_stream2d_track(session, track))


def attach_stream2d_connection_handler(session: Stream2DSession):
    @session.pc.on("connectionstatechange")
    async def on_connectionstatechange():
        logger.info(f"Stream2D connection state: {session.pc.connectionState}")
        if session.pc.connectionState in {"failed", "closed", "disconnected"}:
            session.done.set()

    @session.pc.on("iceconnectionstatechange")
    async def on_iceconnectionstatechange():
        if session.debug:
            logger.info(f"Stream2D ICE connection state: {session.pc.iceConnectionState}")

    @session.pc.on("icegatheringstatechange")
    async def on_icegatheringstatechange():
        if session.debug:
            logger.info(f"Stream2D ICE gathering state: {session.pc.iceGatheringState}")


async def start_stream2d_rtc_session(
    ip: str,
    fps: int = 60,
    camera_index: int = 0,
    progress_log_interval: int = 30,
    on_frame: Optional[Callable[[int, Any], None]] = None,
    debug: bool = False,
) -> Stream2DSession:
    """创建并启动由 SDK 托管的 Stream2D WebRTC 会话。"""
    try:
        from aiortc import RTCPeerConnection
    except ImportError as ex:
        raise RuntimeError(
            "Stream2D requires aiortc. Please run `pip install -r requirements.txt` first."
        ) from ex

    ensure_extended_h264_capabilities()
    _install_h264_passthrough_decoder()

    session = Stream2DSession(
        ip=ip,
        pc=RTCPeerConnection(),
        result=Stream2DSessionResult(frame_count=0, peer_id=None),
        done=asyncio.Event(),
        progress_log_interval=progress_log_interval,
        on_frame=on_frame,
        debug=debug,
    )
    attach_stream2d_track_handler(session)
    attach_stream2d_connection_handler(session)

    logger.info(f"Stream2D status before start: {get_stream2d_status(ip)}")

    try:
        _, session.result.peer_id, _ = await start_stream2d_peer(
            ip=ip,
            fps=fps,
            camera_index=camera_index,
            peer_connection=session.pc,
            debug=debug,
        )
    except Exception:
        await session.pc.close()
        raise

    logger.info(f"Stream2D started: peer_id={session.result.peer_id}")

    session.stats_task = asyncio.create_task(monitor_stream2d_receiver_stats(session))
    return session


async def close_stream2d_session(session: Stream2DSession):
    async with session._close_lock:
        if session._closed:
            return
        session._closed = True
        session.done.set()
        for task in (session.track_task, session.stats_task):
            if task is not None:
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

        await cleanup_stream2d_peer(
            ip=session.ip,
            peer_connection=session.pc,
            peer_id=session.result.peer_id,
        )


async def stop_stream2d_rtc_session(session: Stream2DSession) -> None:
    """主动停止一个由 SDK 托管的 Stream2D WebRTC 会话。"""
    if session is None:
        raise ValueError("session is required")
    await close_stream2d_session(session)
