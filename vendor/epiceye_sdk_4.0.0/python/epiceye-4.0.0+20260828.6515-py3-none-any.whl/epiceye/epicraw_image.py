from typing import NamedTuple

from ._internal.epicraw_parser import EpicRaw3DataType


class EpicRawImage(NamedTuple):
    """EpicRaw3 原始图像的只读描述。"""

    data_type: EpicRaw3DataType
    width: int
    height: int
    mat_type: int
    data: memoryview
