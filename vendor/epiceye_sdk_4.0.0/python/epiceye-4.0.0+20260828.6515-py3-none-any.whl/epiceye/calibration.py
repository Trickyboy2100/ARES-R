from typing import Any, Dict, Optional, Union

from .camera_parameters import CameraParametersConfig
from ._core import (
    CalculateHandEyeAccuracyParams,
    CalculateHandEyeCalibrationResultParams,
    CalculateRobotAccuracyParams,
    ConfigureHandEyeCalibrationParams,
    IntrinsicAddCalibImageRequest,
    IntrinsicRemoveCalibPairRequest,
    _parse_api_data_or_none,
    _parse_api_success,
    _request,
    _to_payload,
    exception_handler,
)


# ---------------- 内参标定 ----------------

@exception_handler
def identify_board(ip: str):
    """拍照并自动识别内参标定板类型。"""
    response = _request(ip, "identify_board")
    return _parse_api_data_or_none(response, "identify_board")


@exception_handler
def check_intrinsic_accuracy(ip: str) -> Optional[Dict[str, Any]]:
    """拍照并执行完整内参精度检查。"""
    response = _request(ip, "check_intrinsic_accuracy")
    return _parse_api_data_or_none(response, "check_intrinsic_accuracy")


@exception_handler
def add_calib_image(ip: str, board_type: int):
    """采集并追加一组内参标定图。"""
    response = _request(ip, "add_calib_image",
        content=_to_payload(IntrinsicAddCalibImageRequest(boardType=board_type)))
    return _parse_api_data_or_none(response, "add_calib_image")


@exception_handler
def remove_calib_image(ip: str, pair_index: int):
    """按索引删除一组内参标定图。"""
    response = _request(ip, "remove_calib_image",
        content=_to_payload(IntrinsicRemoveCalibPairRequest(pairIndex=pair_index)))
    return _parse_api_data_or_none(response, "remove_calib_image")


@exception_handler
def calculate(ip: str):
    """使用工作区内的标定图计算内参。"""
    response = _request(ip, "calculate_intrinsic")
    return _parse_api_data_or_none(response, "calculate")


@exception_handler
def set_intrinsic_parameters(ip: str, camera_parameters_config: CameraParametersConfig) -> bool:
    """写入与 CameraParameters.json 对应的完整相机内外参配置。"""
    if not isinstance(camera_parameters_config, CameraParametersConfig) or not camera_parameters_config.is_complete():
        return False
    response = _request(ip, "set_intrinsic_parameters", content=camera_parameters_config.to_dict())
    return _parse_api_data_or_none(response, "set_intrinsic_parameters") is True


@exception_handler
def restore_factory_intrinsic(ip: str) -> bool:
    """恢复出厂内参。"""
    response = _request(ip, "restore_factory_intrinsic")
    return _parse_api_success(response, "restore_factory_intrinsic")


# ---------------- 手眼标定 ----------------

@exception_handler
def get_calibration_board_pose(ip: str) -> Optional[Dict[str, Any]]:
    """获取标定板位姿。"""
    response = _request(ip, "get_calibration_board_pose")
    return _parse_api_data_or_none(response, "get_calibration_board_pose")


@exception_handler
def get_handeye_calibration_data(ip: str) -> Optional[Dict[str, Any]]:
    """获取相机保存的手眼标定上下文，包括机器人位姿表达规则。"""
    response = _request(ip, "get_handeye_calibration_data")
    return _parse_api_data_or_none(response, "get_handeye_calibration_data")


@exception_handler
def get_robot_library(ip: str) -> Optional[Dict[str, Any]]:
    """获取相机内置机器人库，返回按品牌分组的机器人型号。"""
    response = _request(ip, "get_robot_library")
    return _parse_api_data_or_none(response, "get_robot_library")


@exception_handler
def configure_handeye_calibration(ip: str, params: ConfigureHandEyeCalibrationParams) -> bool:
    """保存安装方式和机器人位姿表达规则，供后续手眼计算解释 robotPose。"""
    response = _request(ip, "update_handeye_calibration_data", content=_to_payload(params))
    return _parse_api_data_or_none(response, "configure_handeye_calibration") is True


@exception_handler
def calculate_handeye_calibration_result(
    ip: str,
    calculate_handeye_calibration_result_params: Union[Dict[str, Any], CalculateHandEyeCalibrationResultParams],
):
    """计算手眼标定结果。"""
    response = _request(ip, "calculate_calibration_result",
        content=_to_payload(calculate_handeye_calibration_result_params))
    return _parse_api_data_or_none(response, "calculate_handeye_calibration_result")


@exception_handler
def calculate_robot_accuracy(ip: str, params: CalculateRobotAccuracyParams) -> Optional[Dict[str, Any]]:
    """计算机器人在指定方向上的绝对位置与姿态精度。"""
    response = _request(ip, "calculate_robot_accuracy", content=_to_payload(params))
    return _parse_api_data_or_none(response, "calculate_robot_accuracy")


@exception_handler
def calculate_handeye_accuracy(ip: str, params: CalculateHandEyeAccuracyParams) -> Optional[Dict[str, Any]]:
    """使用已保存的手眼结果计算标定板在机器人坐标系下的位姿。"""
    response = _request(ip, "calculate_handeye_accuracy", content=_to_payload(params))
    return _parse_api_data_or_none(response, "calculate_handeye_accuracy")
