from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Type, TypeVar


class ReconstructorType(str, Enum):
    MONO = "Mono"
    BINO_WITHOUT_COLOR = "BinoWithoutColor"
    BINO_WITH_COLOR = "BinoWithColor"
    UNKNOWN = "Unknown"


class TransformationReference(str, Enum):
    DEPTH_SRC1 = "DepthSrc1"
    DEPTH_SRC2 = "DepthSrc2"
    TEXTURE_SRC = "TextureSrc"


@dataclass
class IntrinsicParams:
    width: int
    height: int
    camera_matrix: List[float]
    distortion: List[float]
    rotation: List[float]
    translation: List[float]

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "IntrinsicParams":
        return cls(
            width=int(value["width"]),
            height=int(value["height"]),
            camera_matrix=[float(item) for item in value["cameraMatrix"]],
            distortion=[float(item) for item in value["distortion"]],
            rotation=[float(item) for item in value["r"]],
            translation=[float(item) for item in value["t"]],
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "width": self.width,
            "height": self.height,
            "cameraMatrix": self.camera_matrix,
            "distortion": self.distortion,
            "r": self.rotation,
            "t": self.translation,
        }


@dataclass
class SwingLineScanLightPlaneParams:
    start_angle: float = 0.0
    end_angle: float = 0.0
    light_plane_params: List[List[float]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "SwingLineScanLightPlaneParams":
        return cls(
            start_angle=float(value.get("startAngle", 0.0)),
            end_angle=float(value.get("endAngle", 0.0)),
            light_plane_params=[[float(item) for item in plane] for plane in value.get("lightPlaneParams", [])],
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "startAngle": self.start_angle,
            "endAngle": self.end_angle,
            "lightPlaneParams": self.light_plane_params,
        }


@dataclass
class CameraParametersConfig:
    reconstructor_type: ReconstructorType
    transformation_reference: TransformationReference
    depth_src1: IntrinsicParams
    depth_src2: Optional[IntrinsicParams] = None
    texture_src: Optional[IntrinsicParams] = None
    swing_line_scan_light_plane_params: Optional[SwingLineScanLightPlaneParams] = None

    @classmethod
    def from_dict(cls, value: Dict[str, Any]) -> "CameraParametersConfig":
        return cls(
            reconstructor_type=_parse_reconstructor_type(value["reconstructorType"]),
            transformation_reference=_parse_enum(TransformationReference, value["transformationReference"]),
            depth_src1=IntrinsicParams.from_dict(value["depthSrc1"]),
            depth_src2=IntrinsicParams.from_dict(value["depthSrc2"]) if value.get("depthSrc2") is not None else None,
            texture_src=IntrinsicParams.from_dict(value["textureSrc"]) if value.get("textureSrc") is not None else None,
            swing_line_scan_light_plane_params=SwingLineScanLightPlaneParams.from_dict(value["swingLineScanLightPlaneParams"])
            if value.get("swingLineScanLightPlaneParams") is not None
            else None,
        )

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "reconstructorType": self.reconstructor_type.value,
            "transformationReference": self.transformation_reference.value,
            "depthSrc1": self.depth_src1.to_dict(),
        }
        if self.depth_src2 is not None:
            result["depthSrc2"] = self.depth_src2.to_dict()
        if self.texture_src is not None:
            result["textureSrc"] = self.texture_src.to_dict()
        if self.swing_line_scan_light_plane_params is not None:
            result["swingLineScanLightPlaneParams"] = self.swing_line_scan_light_plane_params.to_dict()
        return result

    def is_complete(self) -> bool:
        if self.reconstructor_type == ReconstructorType.UNKNOWN or self.depth_src2 is None:
            return False
        return self.reconstructor_type != ReconstructorType.BINO_WITH_COLOR or self.texture_src is not None


EnumType = TypeVar("EnumType", bound=Enum)


def _parse_enum(enum_type: Type[EnumType], value: Any) -> EnumType:
    if isinstance(value, enum_type):
        return value
    return enum_type(str(value))


def _parse_reconstructor_type(value: Any) -> ReconstructorType:
    if isinstance(value, ReconstructorType):
        return value
    if isinstance(value, int):
        return {
            0: ReconstructorType.MONO,
            1: ReconstructorType.BINO_WITHOUT_COLOR,
            2: ReconstructorType.BINO_WITH_COLOR,
        }.get(value, ReconstructorType.UNKNOWN)
    try:
        return ReconstructorType(str(value))
    except ValueError:
        return ReconstructorType.UNKNOWN
