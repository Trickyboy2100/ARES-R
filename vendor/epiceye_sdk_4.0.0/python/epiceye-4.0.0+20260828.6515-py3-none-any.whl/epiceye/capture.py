from ._core import (
    _get_or_detect_version,
    _is_v4,
    _parse_api_data_or_none,
    _request,
    exception_handler,
)


@exception_handler
def trigger_frame(ip: str, pointcloud: bool = True, passive_binocular: bool = False):
    """触发拍照并返回 frameId。"""
    if _is_v4(_get_or_detect_version(ip)):
        response = _request(
            ip,
            "trigger_capture",
            content={
                "PointCloud": pointcloud,
                "PassiveBinocular": passive_binocular,
            },
        )
        data = _parse_api_data_or_none(response, "trigger_frame")
        return None if data is None else str(data)

    response = _request(ip, "trigger_capture", str(pointcloud).lower())
    return None if response is None else response.text.strip()


@exception_handler
def get_frame_in_epicraw(ip: str, frame_id: str, aligned: bool = False):
    """根据 frameId 下载原始 EpicRaw 字节。"""
    response = _request(ip, "get_epicraw", frame_id, str(aligned).lower())
    return None if response is None else response.content
