import json
import logging
import struct
import time
from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, Dict, List, Optional

import numpy as np
import requests


def init_logger_handler(name):
    log = logging.getLogger(name)
    log.propagate = False
    log.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    handler.setLevel(logging.INFO)
    log.addHandler(handler)
    return log


logger = init_logger_handler("EPICEYE")
EMPTY_ARRAY = None

# 路由表与 C# 端 ApiPaths4V3 / ApiPaths4V4 完全对应。
# path 为 /api/ 之后的相对路径模板，{0}、{1} 为位置参数占位符。
# V3 仅覆盖旧版本一定存在的基础接口；V4 在此基础上新增标定/线扫/2D流等接口。
API_PATHS_V3: Dict[str, Dict[str, Any]] = {
    "get_info": {"path": "EpicEye/Info", "method": "GET", "timeout": 5.0},
    "get_config": {"path": "CameraConfig", "method": "GET", "timeout": 5.0},
    "set_config": {"path": "CameraConfig", "method": "PUT", "timeout": 5.0},
    "get_parameter_list": {"path": "CameraConfig/SimpleParams", "method": "GET", "timeout": 5.0},
    "set_parameter": {"path": "CameraConfig/SetByParamId/{0}", "method": "PUT", "timeout": 5.0},
    "get_config_style": {"path": "CameraConfig/Style", "method": "GET", "timeout": 5.0},
    "trigger_capture": {"path": "Frame?pointCloud={0}", "method": "POST", "timeout": 30.0},
    "get_epicraw": {"path": "Frame?frameId={0}", "method": "GET", "timeout": 30.0},
    "get_undistort_lut": {"path": "UndistortLut", "method": "GET", "timeout": 30.0},
    "get_camera_matrix": {"path": "CameraParameters/Intrinsic/CameraMatrix", "method": "GET", "timeout": 5.0},
    "get_distortion": {"path": "CameraParameters/Intrinsic/Distortion", "method": "GET", "timeout": 5.0},
    "get_camera_parameters": {"path": "CameraParameters/Intrinsic/CameraParameters", "method": "GET", "timeout": 5.0},

    "get_calibration_board_pose": {"path": "HandEyeCalibration/GetCalibrationBoardPose", "method": "GET", "timeout": 30.0},
    "get_handeye_calibration_data": {"path": "HandEyeCalibration/GetCalibrationData", "method": "GET", "timeout": 5.0},
    "update_handeye_calibration_data": {"path": "HandEyeCalibration/UpdateCalibrationData", "method": "POST", "timeout": 5.0},
    "calculate_calibration_result": {"path": "HandEyeCalibration/CalculateCalibrationResult", "method": "POST", "timeout": 60.0},
    "get_robot_library": {"path": "RobotLibrary/GetRobotLibrary", "method": "GET", "timeout": 5.0},
    "calculate_robot_accuracy": {"path": "HandEyeCalibration/CalculateRobotAccuracy", "method": "POST", "timeout": 30.0},
    "calculate_handeye_accuracy": {"path": "HandEyeCalibration/CalculateAccuracy", "method": "POST", "timeout": 30.0},
}

API_PATHS_V4: Dict[str, Dict[str, Any]] = {
    "get_info": {"path": "EpicEye/Info", "method": "GET", "timeout": 5.0},
    "get_config": {"path": "CameraConfig/GetSelectedCameraParams", "method": "GET", "timeout": 5.0},
    "set_config": {"path": "CameraConfig/UpdateCameraParams", "method": "POST", "timeout": 5.0},
    "get_parameter_list": {"path": "CameraConfig/GetCameraParamsList", "method": "GET", "timeout": 5.0},
    "set_parameter": {"path": "CameraConfig/SelectCameraParams", "method": "POST", "timeout": 5.0},
    "get_config_style": {"path": "CameraConfig/GetCameraParamsStyle", "method": "GET", "timeout": 5.0},
    # V4：pointCloud 改走 body（见 capture.trigger_frame），路由不再带 query 占位符
    "trigger_capture": {"path": "Frame/TriggerCapture", "method": "POST", "timeout": 30.0},
    "get_epicraw": {"path": "Frame/GetEpicRaw?frameId={0}&aligned={1}", "method": "GET", "timeout": 30.0},
    "get_undistort_lut": {"path": "UndistortLut?width={0}&height={1}&cameraMatrix={2}&distortion={3}", "method": "GET", "timeout": 30.0},
    "get_camera_matrix": {"path": "CameraParameters/Intrinsic/GetCameraMatrix", "method": "GET", "timeout": 5.0},
    "get_distortion": {"path": "CameraParameters/Intrinsic/GetDistortion", "method": "GET", "timeout": 5.0},
    "get_camera_parameters": {"path": "CameraParameters/Intrinsic/GetCameraParameters", "method": "GET", "timeout": 5.0},

    "get_reconstructor_type": {"path": "EpicEye/GetReconstructorType", "method": "GET", "timeout": 5.0},
    "get_temperature_info": {"path": "EpicEye/GetTemperatureInfo?useCache={0}", "method": "GET", "timeout": 5.0},
    "identify_board": {"path": "IntrinsicCalibration/IdentifyBoard", "method": "POST", "timeout": 30.0},
    "check_intrinsic_accuracy": {"path": "IntrinsicCalibration/CheckAccuracy", "method": "POST", "timeout": 120.0},
    "add_calib_image": {"path": "IntrinsicCalibration/AddCalibImage", "method": "POST", "timeout": 30.0},
    "remove_calib_image": {"path": "IntrinsicCalibration/RemoveCalibImage", "method": "POST", "timeout": 5.0},
    "calculate_intrinsic": {"path": "IntrinsicCalibration/Calculate", "method": "POST", "timeout": 60.0},
    "set_intrinsic_parameters": {"path": "CameraParameters/Intrinsic/SetCameraParameters", "method": "POST", "timeout": 5.0},
    "restore_factory_intrinsic": {"path": "IntrinsicCalibration/RestoreFactoryIntrinsic", "method": "POST", "timeout": 30.0},

    "get_calibration_board_pose": {"path": "HandEyeCalibration/GetCalibrationBoardPose", "method": "GET", "timeout": 30.0},
    "get_handeye_calibration_data": {"path": "HandEyeCalibration/GetCalibrationData", "method": "GET", "timeout": 5.0},
    "update_handeye_calibration_data": {"path": "HandEyeCalibration/UpdateCalibrationData", "method": "POST", "timeout": 5.0},
    "calculate_calibration_result": {"path": "HandEyeCalibration/CalculateCalibrationResult", "method": "POST", "timeout": 60.0},
    "get_robot_library": {"path": "RobotLibrary/GetRobotLibrary", "method": "GET", "timeout": 5.0},
    "calculate_robot_accuracy": {"path": "HandEyeCalibration/CalculateRobotAccuracy", "method": "POST", "timeout": 30.0},
    "calculate_handeye_accuracy": {"path": "HandEyeCalibration/CalculateAccuracy", "method": "POST", "timeout": 30.0},

    "line_scan_start": {"path": "LineScan/Start", "method": "POST", "timeout": 10.0},
    "line_scan_stop": {"path": "LineScan/Stop", "method": "POST", "timeout": 10.0},
    "line_scan_status": {"path": "LineScan/Status", "method": "GET", "timeout": 5.0},

    "stream2d_status": {"path": "Stream2D/Status", "method": "GET", "timeout": 5.0},
    "stream2d_webrtc_offer": {"path": "Stream2D/WebRtcOffer", "method": "POST", "timeout": 10.0},
    "stream2d_webrtc_stop": {"path": "Stream2D/WebRtcStop", "method": "POST", "timeout": 5.0},
    "stream2d_webrtc_stop_all": {"path": "Stream2D/StopAll", "method": "POST", "timeout": 5.0},
}

undistort_lut_dict: Dict[str, Any] = {}
_timeout_overrides: Dict[str, float] = {}
# 按 ip 缓存探测到的相机 EpicEye 版本号。
_epiceye_version_cache: Dict[str, str] = {}


def set_timeout(key: str, seconds: float):
    if key not in API_PATHS_V3 and key not in API_PATHS_V4:
        raise ValueError(f"未知接口名: {key}")
    if seconds <= 0:
        raise ValueError("seconds 必须大于 0")
    _timeout_overrides[key] = seconds


def reset_timeout(key: str):
    _timeout_overrides.pop(key, None)


def reset_all_timeouts():
    _timeout_overrides.clear()


def get_epiceye_version(ip: str) -> Optional[str]:
    """返回已缓存的相机版本号，未缓存则返回 None。"""
    return _epiceye_version_cache.get(ip)


def clear_epiceye_version_cache(ip: Optional[str] = None):
    """清除版本缓存，指定 ip 则只清除该 ip，否则清空全部。"""
    if ip is None:
        _epiceye_version_cache.clear()
        return
    _epiceye_version_cache.pop(ip, None)


def compute_array_hash(arr) -> str:
    """对浮点数组按 double 位模式计算稳定哈希，用作去畸变 LUT 缓存 key 的一部分。"""
    if arr is None:
        return "0"
    h = 17
    for x in arr:
        bits = struct.unpack("<q", struct.pack("<d", float(x)))[0]
        h = (h * 31 + bits) & 0xFFFFFFFFFFFFFFFF
    return format(h, "X")


def clear_undistort_lut_cache(ip: Optional[str] = None):
    """清除去畸变查找表缓存，指定 ip 则清除该 ip 的全部条目（含组合 key），否则清空全部。"""
    if ip is None:
        undistort_lut_dict.clear()
        return
    prefix = ip + "_"
    for key in list(undistort_lut_dict.keys()):
        if key == ip or key.startswith(prefix):
            undistort_lut_dict.pop(key, None)


def _is_v4(version: Optional[str]) -> bool:
    if not version:
        return False
    try:
        return int(version.split(".")[0]) >= 4
    except (ValueError, IndexError):
        return False


def _get_or_detect_version(ip: str, timeout: float = 5.0) -> Optional[str]:
    """
    首次调用某个 ip 时通过 EpicEye/Info 探测版本号并缓存。
    兼容两种返回：V4 包装为 {status, data:{version}}，V3 直接返回 {version}。
    """
    cached = _epiceye_version_cache.get(ip)
    if cached:
        return cached

    try:
        resp = requests.get(f"http://{ip}/api/EpicEye/Info",
                            headers={"accept": "*/*"}, timeout=timeout)
        if resp.status_code != 200:
            return None
        body = resp.json()
    except Exception as ex:
        logger.error(f"detect version {ip} error={repr(ex)}")
        return None

    version = ""
    if isinstance(body, dict):
        if "status" in body and "data" in body:
            data = body.get("data")
            if body.get("status") == 0 and isinstance(data, dict):
                version = data.get("version", "") or ""
        if not version:
            version = body.get("version", "") or ""

    if version:
        _epiceye_version_cache[ip] = version
        return version
    return None


@dataclass
class HandEyePointData:
    robotPose: List[float]
    boardPoseArray: List[float]
    id: int = 0


@dataclass
class SpecialParams:
    offset: List[float]
    boardPosition: List[float]


@dataclass
class CalculateHandEyeCalibrationResultParams:
    installationType: str
    handEyePoints: List[HandEyePointData]
    specialParams: Optional[SpecialParams] = None


@dataclass
class RobotParameters:
    brand: str
    model: str
    rotationType: str = "EulerPose"
    eulerType: str = "XYZ"
    angleUnit: str = "Degree"
    isCustomRobot: bool = False
    axisNumber: int = 6
    marks: str = "X,Y,Z,Rx,Ry,Rz"


@dataclass
class ConfigureHandEyeCalibrationParams:
    installationType: str
    robotParams: RobotParameters
    updateFields: List[str] = field(default_factory=lambda: ["installationType", "robotParams"])


@dataclass
class RobotAccuracyPoint:
    boardPoseArray: List[float]
    robotPose: List[float]
    cameraInternalAccuracy: float = 0.0


@dataclass
class RobotAccuracyDirectionData:
    startPoint: RobotAccuracyPoint
    endPoint: RobotAccuracyPoint


@dataclass
class CalculateRobotAccuracyParams:
    directionPoseData: RobotAccuracyDirectionData
    direction: str


@dataclass
class CalculateHandEyeAccuracyParams:
    boardPoseArray: List[float]
    robotPose: List[float]
    gridSize: int
    directionZ: str = "up"


@dataclass
class IntrinsicAddCalibImageRequest:
    boardType: int


@dataclass
class IntrinsicRemoveCalibPairRequest:
    pairIndex: int


@dataclass
class LineScanStartRequest:
    enableTexture: bool = True
    deferEpicRawSave: Optional[bool] = None


def exception_handler(func):
    def handler(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as ex:
            logger.error(f"{func.__name__}: {repr(ex)}")
            return None

    return handler


def _select_route(ip: str, key: str):
    """按 ip 当前版本选择路由表，返回 (spec, version)。"""
    version = _get_or_detect_version(ip)
    routes = API_PATHS_V4 if _is_v4(version) else API_PATHS_V3
    spec = routes.get(key)
    if spec is None:
        logger.warning(f"route '{key}' not found for version '{version}'")
    return spec, version


def _request(ip: str, key: str, *path_args, content=None, files=None):
    """版本感知的统一请求函数：先探测版本，再按对应路由表发起请求。"""
    spec, _ = _select_route(ip, key)
    if spec is None:
        return None
    path = spec["path"].format(*path_args) if path_args else spec["path"]
    url = f"http://{ip}/api/{path}"
    method = spec["method"]
    timeout = _timeout_overrides.get(key, spec["timeout"])
    try:
        t0 = time.monotonic()
        if method == "GET":
            if content is not None:
                resp = requests.get(url, json=content, headers={"accept": "*/*", "Content-Type": "application/json"}, timeout=timeout)
            else:
                resp = requests.get(url, headers={"accept": "*/*"}, timeout=timeout)
        elif method == "PUT":
            resp = requests.put(url, json=content, headers={"accept": "*/*", "Content-Type": "application/json"}, timeout=timeout)
        elif files is not None:
            resp = requests.post(url, files=files, headers={"accept": "*/*"}, timeout=timeout)
        elif isinstance(content, (dict, list)):
            resp = requests.post(url, json=content, headers={"accept": "*/*", "Content-Type": "application/json"}, timeout=timeout)
        else:
            resp = requests.post(url, data=content, timeout=timeout)
        if resp.status_code != 200:
            elapsed = (time.monotonic() - t0) * 1000
            logger.warning(f"{method} {url} status={resp.status_code} elapsed={elapsed:.1f}ms")
            return None
        return resp
    except Exception as ex:
        logger.error(f"request{method} {url} error={repr(ex)}")
        return None


def _to_payload(content: Any):
    if is_dataclass(content):
        return asdict(content)
    return content


def _nparray_from_buffer(buffer, width, height, raw_type):
    if raw_type == 0:
        result = np.frombuffer(buffer, dtype=np.uint8)
        return result.reshape(height, width, 3)
    if raw_type == 1:
        result = np.frombuffer(buffer, dtype=np.float32)
        return result.reshape(height, width)
    return None


def _decode_epic_raw(content):
    data_length = len(content) - 168
    format_str = f"<8sii72s68si8s{data_length}s"
    _, width, height, K_data, _, raw_type, _, data = struct.unpack(
        format_str, content)
    K = np.frombuffer(K_data, dtype=np.double)
    data_array = _nparray_from_buffer(data, width, height, raw_type)
    return data_array, K


def _parse_api_data_or_none(response, api_name: str):
    if response is None:
        return None
    body = json.loads(response.content)
    if body.get("status", -1) != 0:
        logger.warning(f"{api_name} failed: {body.get('errorMessage')}")
        return None
    return body.get("data")


def _parse_api_success(response, api_name: str, require_true_data: bool = False) -> bool:
    if response is None:
        return False
    try:
        body = json.loads(response.content)
    except (TypeError, ValueError) as ex:
        logger.warning(f"{api_name} failed: invalid response: {ex}")
        return False
    if not isinstance(body, dict) or body.get("status", -1) != 0:
        error_message = body.get("errorMessage") if isinstance(body, dict) else "invalid response"
        logger.warning(f"{api_name} failed: {error_message}")
        return False
    if require_true_data and body.get("data") is not True:
        logger.warning(f"{api_name} failed: response data is not true")
        return False
    return True
