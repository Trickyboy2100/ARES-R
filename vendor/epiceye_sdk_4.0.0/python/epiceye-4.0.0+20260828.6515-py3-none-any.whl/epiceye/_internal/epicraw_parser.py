import json
import struct

from enum import Enum

import numpy as np


class FileType(Enum):
    NotSupported = -1
    EpicRaw1 = 0
    EpicRaw2 = 1
    EpicRaw3 = 2


class DataType(Enum):
    Non = -1
    RGB24 = 0
    Depth32 = 1
    RGB48 = 2


class EpicRaw3DataType(Enum):
    DepthSrcImg1 = 0
    DepthSrcImg2 = 1
    TextureBGR = 2
    Depth = 3
    PointCloud = 4
    PointCloudNormal = 5


def _array_from_buffer(buffer: bytes, width: int, height: int, raw_type: DataType):
    if raw_type == DataType.RGB24:
        result = np.frombuffer(buffer, dtype=np.uint8)
        return result.reshape(height, width, 3)
    if raw_type == DataType.RGB48:
        result = np.frombuffer(buffer, dtype=np.uint16)
        return result.reshape(height, width, 3)
    if raw_type == DataType.Depth32:
        result = np.frombuffer(buffer, dtype=np.float32)
        return result.reshape(height, width)
    return None


def _meshgrid_lut(width: int, height: int):
    return np.stack(np.meshgrid(range(0, width), range(0, height)), axis=2).astype(np.float32)


def _decode_point_cloud_from_depth(depth: np.ndarray, matrix: np.ndarray, undistort_lut):
    if undistort_lut is None:
        undistort_lut = _meshgrid_lut(depth.shape[1], depth.shape[0])

    u = undistort_lut[:, :, 0]
    v = undistort_lut[:, :, 1]
    x = (u - matrix[0][2]) * depth / matrix[0][0]
    y = (v - matrix[1][2]) * depth / matrix[1][1]
    invalid = (depth < 0.1) | (depth > 6000)
    # 与 C#/真机 PointCloud(CV_32FC3)对齐：matrix 为 float64 会把运算结果提升到 float64，这里显式收回 float32。
    point_map = np.dstack((x, y, depth)).astype(np.float32, copy=False)
    point_map[invalid] = (np.nan, np.nan, np.nan)
    return point_map


def _parse_matrix_from_meta(meta_str: str):
    if not meta_str:
        return None
    try:
        meta_obj = json.loads(meta_str)
        matrix_data = meta_obj.get("CameraMatrix")
        if not isinstance(matrix_data, list) or len(matrix_data) < 9:
            return None
        return np.array(matrix_data[:9], dtype=np.float64).reshape(3, 3)
    except Exception:
        return None


def _parse_distortion_from_meta(meta_str: str):
    if not meta_str:
        return None
    try:
        meta_obj = json.loads(meta_str)
        # 与 C# EpicRawDataService.TryParseDistortionFromMeta 一致，meta key 为 "CameraDistortion"
        dist_data = meta_obj.get("CameraDistortion")
        if not isinstance(dist_data, list) or len(dist_data) == 0:
            return None
        return np.array(dist_data, dtype=np.float64)
    except Exception:
        return None


def _parse_epicraw3(data: bytes):
    if data is None or len(data) < 20 or data[:8] != b"EPICRAW3":
        return None
    try:
        offset = 8
        header_length = struct.unpack_from("<i", data, offset)[0]
        offset += 4
        elements_count = struct.unpack_from("<i", data, offset)[0]
        offset += 4
        if header_length < 0 or elements_count < 0 or elements_count > 128:
            return None
        element_lengths = []
        for _ in range(elements_count):
            if offset + 4 > len(data):
                return None
            element_lengths.append(struct.unpack_from("<i", data, offset)[0])
            offset += 4
        if any(length < 0 for length in element_lengths) or offset + 4 > len(data):
            return None
        metadata_len = struct.unpack_from("<i", data, offset)[0]
        offset += 4
        if metadata_len < 0 or metadata_len > len(data) - offset:
            return None
        header_meta = data[offset: offset + metadata_len].decode("utf-8") if metadata_len > 0 else ""
        offset += metadata_len
        if header_length != offset:
            return None

        elements = []
        for index in range(elements_count):
            element_start = offset
            if offset + 28 > len(data):
                return None
            element_header_len = struct.unpack_from("<i", data, offset)[0]
            offset += 4
            data_type = struct.unpack_from("<i", data, offset)[0]
            offset += 4
            data_len = struct.unpack_from("<i", data, offset)[0]
            offset += 4
            width = struct.unpack_from("<i", data, offset)[0]
            offset += 4
            height = struct.unpack_from("<i", data, offset)[0]
            offset += 4
            mat_type = struct.unpack_from("<i", data, offset)[0]
            offset += 4
            element_meta_len = struct.unpack_from("<i", data, offset)[0]
            offset += 4
            if (
                element_header_len < 28
                or data_len < 0
                or width < 0
                or height < 0
                or mat_type < 0
                or element_meta_len < 0
                or element_header_len != 28 + element_meta_len
                or element_lengths[index] != element_header_len + data_len
                or element_meta_len > len(data) - offset
            ):
                return None
            element_meta = data[offset: offset + element_meta_len].decode("utf-8") if element_meta_len > 0 else ""
            offset += element_meta_len
            if data_len > len(data) - offset:
                return None
            element_data = data[offset: offset + data_len]
            offset += data_len
            if offset - element_start != element_lengths[index]:
                return None
            elements.append({
                "header_length": element_header_len,
                "data_type": data_type,
                "data_length": data_len,
                "width": width,
                "height": height,
                "mat_type": mat_type,
                "meta_data_length": element_meta_len,
                "meta": element_meta,
                "data": element_data,
            })

        return {
            "header_length": header_length,
            "elements_count": elements_count,
            "element_lengths": element_lengths,
            "meta_data_length": metadata_len,
            "meta": header_meta,
            "elements": elements,
        }
    except Exception:
        return None


def _get_epicraw3_element(epicraw3_obj, data_type: EpicRaw3DataType):
    if epicraw3_obj is None:
        return None
    for item in epicraw3_obj["elements"]:
        if item["data_type"] == data_type.value:
            return item
    return None


def _decode_bgr_element(element):
    """将 EPICRAW3 BGR/灰度 element 解码为 numpy 数组。

    MatType 低 3 位为深度（0=8U, 2=16U），高位决定通道数。
    单通道返回 (H, W)，三通道返回 (H, W, 3)，保留原始 BGR 顺序和位深。
    """
    if element is None:
        return None
    width = element["width"]
    height = element["height"]
    mat_type = element["mat_type"]
    raw_data = element["data"]

    channels = ((mat_type >> 3) & 0xff) + 1
    is_16bit = (mat_type & 7) == 2
    dtype = np.uint16 if is_16bit else np.uint8
    expected_bytes = width * height * channels * (2 if is_16bit else 1)

    if width <= 0 or height <= 0 or len(raw_data) != expected_bytes:
        return None

    arr = np.frombuffer(raw_data, dtype=dtype)
    if channels == 1:
        return arr.reshape(height, width)
    return arr.reshape(height, width, channels)


def get_width_height_from_bytes(data: bytes):
    file_type = _get_file_type(data)
    if file_type in (FileType.EpicRaw1, FileType.EpicRaw2):
        if len(data) >= 16:
            _, width, height = struct.unpack("<8s2i", data[:16])
            return width, height
    if file_type == FileType.EpicRaw3:
        raw3 = _parse_epicraw3(data)
        tex = _get_epicraw3_element(raw3, EpicRaw3DataType.TextureBGR)
        if tex is not None:
            return tex["width"], tex["height"]
        dep = _get_epicraw3_element(raw3, EpicRaw3DataType.Depth)
        if dep is not None:
            return dep["width"], dep["height"]
    return -1, -1


def _decode_point_cloud_from_epicraw3(raw3, undistort_lut=None):
    """基于已经解析好的 EPICRAW3 对象解算点云。
    """
    if raw3 is None:
        return None

    point_el = _get_epicraw3_element(raw3, EpicRaw3DataType.PointCloud)
    if point_el is not None and len(point_el["data"]) > 0:
        width = point_el["width"]
        height = point_el["height"]
        point_arr = np.frombuffer(point_el["data"], dtype=np.float32)
        if width > 0 and height > 0 and point_arr.size == width * height * 3:
            return point_arr.reshape(height, width, 3)
        return point_arr

    depth_el = _get_epicraw3_element(raw3, EpicRaw3DataType.Depth)
    if depth_el is None:
        return None
    width = depth_el["width"]
    height = depth_el["height"]
    depth_arr = np.frombuffer(depth_el["data"], dtype=np.float32)
    if width <= 0 or height <= 0 or depth_arr.size != width * height:
        return None
    depth_arr = depth_arr.reshape(height, width)

    matrix = _parse_matrix_from_meta(depth_el["meta"])
    if matrix is None:
        matrix = _parse_matrix_from_meta(raw3["meta"])
    if matrix is None:
        return None

    return _decode_point_cloud_from_depth(depth_arr, matrix, undistort_lut)


def _decode_image_from_epicraw3(raw3):
    """基于已经解析好的 EPICRAW3 对象解算 TextureBGR 图像。"""
    if raw3 is None:
        return None
    texture_el = _get_epicraw3_element(raw3, EpicRaw3DataType.TextureBGR)
    if texture_el is None:
        return None
    width = texture_el["width"]
    height = texture_el["height"]
    texture_data = texture_el["data"]
    if width <= 0 or height <= 0:
        return None
    if len(texture_data) == width * height * 3:
        return np.frombuffer(texture_data, dtype=np.uint8).reshape(height, width, 3)
    if len(texture_data) == width * height * 3 * 2:
        return np.frombuffer(texture_data, dtype=np.uint16).reshape(height, width, 3)
    return None


def _get_file_type(data: bytes):
    if data is None or len(data) < 8:
        return FileType.NotSupported
    filetype_bytes = data[:8]
    filetype_str = struct.unpack("<8s", filetype_bytes)[0]
    if filetype_str == b"EPICRAW1":
        return FileType.EpicRaw1
    if filetype_str == b"EPICRAW2":
        return FileType.EpicRaw2
    if filetype_str == b"EPICRAW3":
        return FileType.EpicRaw3
    if filetype_str[7] == 0:
        return FileType.EpicRaw1
    return FileType.NotSupported


def get_distortion_from_epicraw_bytes(data: bytes):
    file_type = _get_file_type(data)
    if file_type == FileType.EpicRaw1:
        return EpicRaw1.get_distortion(data)
    if file_type == FileType.EpicRaw2:
        return EpicRaw2.get_distortion(data)
    if file_type == FileType.EpicRaw3:
        raw3 = _parse_epicraw3(data)
        if raw3 is None:
            return None
        depth_el = _get_epicraw3_element(raw3, EpicRaw3DataType.Depth)
        meta = depth_el["meta"] if depth_el and depth_el.get("meta") else raw3["meta"]
        return _parse_distortion_from_meta(meta)
    return None


def get_matrix_from_epicraw_bytes(data: bytes):
    file_type = _get_file_type(data)
    if file_type == FileType.EpicRaw1:
        return EpicRaw1.get_camera_matrix(data)
    if file_type == FileType.EpicRaw2:
        return EpicRaw2.get_camera_matrix(data)
    if file_type == FileType.EpicRaw3:
        raw3 = _parse_epicraw3(data)
        depth_el = _get_epicraw3_element(raw3, EpicRaw3DataType.Depth)
        if depth_el is not None:
            matrix = _parse_matrix_from_meta(depth_el["meta"])
            if matrix is not None:
                return matrix
        return _parse_matrix_from_meta(raw3["meta"]) if raw3 is not None else None
    return None


class EpicRaw1:
    HEADER_SIZE = 168

    parameters_keys = [
        "ProjectorBrightness", "ExpTime2D", "ExpTime3D", "UseHDR",
        "ExpTimeHDR", "UsePF", "UseSF"
    ]

    @staticmethod
    def load_from_bytes(data: bytes):
        if data is None or len(data) < EpicRaw1.HEADER_SIZE:
            return None
        filetype = struct.unpack("<8s", data[:8])[0]
        if filetype != b"EPICRAW1" and filetype[7] != 0:
            return None
        try:
            _, width, height = struct.unpack_from("<8sii", data, 0)
            camera_matrix = np.frombuffer(data[16:88], dtype=np.float64).reshape(3, 3)
            distortion = np.frombuffer(data[88:128], dtype=np.float64)
            config_data = data[128:156]
            config_values = struct.unpack("<I2fIf2I", config_data)
            data_type, depth_data_len, image_data_len = struct.unpack_from("<3i", data, 156)
        except (ValueError, struct.error):
            return None
        if depth_data_len < 0 or image_data_len < 0:
            return None
        offset = EpicRaw1.HEADER_SIZE
        if depth_data_len > len(data) - offset:
            return None
        depth_data = data[offset: offset + depth_data_len]
        offset += depth_data_len
        if image_data_len > len(data) - offset:
            return None
        image_data = data[offset: offset + image_data_len]
        camera_config = {
            key: (bool(value) if key in ("UseHDR", "UsePF", "UseSF") else value)
            for key, value in zip(EpicRaw1.parameters_keys, config_values)
        }
        return {
            "width": width,
            "height": height,
            "data_type": data_type,
            "camera_matrix": camera_matrix,
            "distortion": distortion,
            "config_data": config_data,
            "camera_config": camera_config,
            "depth_data_length": depth_data_len,
            "image_data_length": image_data_len,
            "depth_data": depth_data,
            "image_data": image_data,
        }

    @staticmethod
    def get_image(data):
        parsed = EpicRaw1.load_from_bytes(data)
        if parsed is None or not parsed["image_data"]:
            return None
        image_type = EpicRaw2.get_image_data_type(parsed["data_type"])
        if image_type is None:
            return None
        return _array_from_buffer(
            parsed["image_data"], parsed["width"], parsed["height"], image_type)

    @staticmethod
    def get_depth(data: bytes):
        parsed = EpicRaw1.load_from_bytes(data)
        if parsed is None or not parsed["depth_data"]:
            return None
        return _array_from_buffer(
            parsed["depth_data"], parsed["width"], parsed["height"], DataType.Depth32)

    @staticmethod
    def get_camera_matrix(data: bytes):
        parsed = EpicRaw1.load_from_bytes(data)
        return parsed["camera_matrix"] if parsed is not None else None

    @staticmethod
    def get_distortion(data: bytes):
        parsed = EpicRaw1.load_from_bytes(data)
        return parsed["distortion"] if parsed is not None else None

    @staticmethod
    def get_config_dict(data: bytes):
        parsed = EpicRaw1.load_from_bytes(data)
        return parsed["camera_config"] if parsed is not None else None


class EpicRaw2:
    HEADER_SIZE = 40

    @staticmethod
    def load_from_bytes(data: bytes):
        if data is None or len(data) < EpicRaw2.HEADER_SIZE:
            return None
        filetype = struct.unpack("<8s", data[:8])[0]
        if filetype != b"EPICRAW2":
            return None
        try:
            (
                _,
                width,
                height,
                data_type,
                camera_matrix_len,
                distortion_len,
                config_str_len,
                depth_data_len,
                image_data_len,
            ) = struct.unpack("<8s8i", data[:EpicRaw2.HEADER_SIZE])
        except struct.error:
            return None
        if (
            camera_matrix_len < 9 * np.dtype(np.float64).itemsize
            or camera_matrix_len % np.dtype(np.float64).itemsize != 0
            or distortion_len < 0
            or distortion_len % np.dtype(np.float64).itemsize != 0
            or config_str_len < 0
            or depth_data_len < 0
            or image_data_len < 0
        ):
            return None
        offset = EpicRaw2.HEADER_SIZE
        if camera_matrix_len > len(data) - offset:
            return None
        matrix_data = data[offset: offset + camera_matrix_len]
        camera_matrix = np.frombuffer(matrix_data, dtype=np.float64)[:9].reshape(3, 3)
        offset += camera_matrix_len
        if distortion_len > len(data) - offset:
            return None
        distortion_data = data[offset: offset + distortion_len]
        distortion = np.frombuffer(distortion_data, dtype=np.float64)
        offset += distortion_len
        if config_str_len > len(data) - offset:
            return None
        config_data = data[offset: offset + config_str_len]
        offset += config_str_len
        if depth_data_len > len(data) - offset:
            return None
        depth_data = data[offset: offset + depth_data_len]
        offset += depth_data_len
        if image_data_len > len(data) - offset:
            return None
        image_data = data[offset: offset + image_data_len]
        return {
            "width": width,
            "height": height,
            "data_type": data_type,
            "camera_matrix_length": camera_matrix_len,
            "distortion_length": distortion_len,
            "config_str_length": config_str_len,
            "depth_data_length": depth_data_len,
            "image_data_length": image_data_len,
            "camera_matrix": camera_matrix,
            "distortion": distortion,
            "config_data": config_data,
            "depth_data": depth_data,
            "image_data": image_data,
        }

    @staticmethod
    def get_image(data: bytes):
        parsed = EpicRaw2.load_from_bytes(data)
        if parsed is None or not parsed["image_data"]:
            return None
        image_type = EpicRaw2.get_image_data_type(parsed["data_type"])
        if image_type is None:
            return None
        return _array_from_buffer(
            parsed["image_data"], parsed["width"], parsed["height"], image_type)

    @staticmethod
    def get_depth(data: bytes):
        parsed = EpicRaw2.load_from_bytes(data)
        if parsed is None or not parsed["depth_data"]:
            return None
        return _array_from_buffer(
            parsed["depth_data"], parsed["width"], parsed["height"], DataType.Depth32)

    @staticmethod
    def get_camera_matrix(data: bytes):
        parsed = EpicRaw2.load_from_bytes(data)
        return parsed["camera_matrix"] if parsed is not None else None

    @staticmethod
    def get_distortion(data: bytes):
        parsed = EpicRaw2.load_from_bytes(data)
        return parsed["distortion"] if parsed is not None else None

    @staticmethod
    def get_config_dict(data: bytes):
        parsed = EpicRaw2.load_from_bytes(data)
        if parsed is None or not parsed["config_data"]:
            return None
        return json.loads(parsed["config_data"].decode("utf-8"))

    @staticmethod
    def get_image_data_type(data_type: int):
        if data_type in (0, 4):
            return DataType.RGB24
        if data_type in (2, 8):
            return DataType.RGB48
        return None
