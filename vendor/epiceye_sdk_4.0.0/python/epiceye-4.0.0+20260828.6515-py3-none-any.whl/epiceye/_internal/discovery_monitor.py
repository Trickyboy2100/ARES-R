import json
import socket
import struct
import threading
from typing import Callable, Dict, List, Optional

from .._core import logger

_IPV4_MULTICAST_ADDRESS = "224.0.0.251"
_PORT_CANDIDATES = (5665, 5666, 5667, 5668)


class DiscoveryMonitor:
    """后台监听相机广播并维护发现列表。"""

    _lock = threading.Lock()
    _started = False
    _stop_event = threading.Event()
    _socket_ipv4: Optional[socket.socket] = None
    _thread_ipv4: Optional[threading.Thread] = None
    _cameras: List[Dict] = []
    _callback: Optional[Callable[[], None]] = None

    @classmethod
    def start(cls) -> None:
        with cls._lock:
            if cls._started:
                return
            cls._started = True
            cls._stop_event.clear()
            cls._socket_ipv4 = cls._bind_ipv4_socket()
            if cls._socket_ipv4 is None:
                cls._started = False
                return
            cls._thread_ipv4 = threading.Thread(
                target=cls._listen_loop,
                args=(cls._socket_ipv4,),
                daemon=True,
            )
            cls._thread_ipv4.start()

    @classmethod
    def stop(cls) -> None:
        with cls._lock:
            if not cls._started:
                return
            cls._started = False
            cls._stop_event.set()
            sock = cls._socket_ipv4
            thread = cls._thread_ipv4
            cls._socket_ipv4 = None
            cls._thread_ipv4 = None

        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        if thread is not None:
            thread.join(timeout=3)

    @classmethod
    def get_epiceye_list(cls) -> List[Dict]:
        with cls._lock:
            return list(cls._cameras)

    @classmethod
    def clear_epiceye_list(cls) -> List[Dict]:
        with cls._lock:
            cls._cameras.clear()
            return []

    @classmethod
    def set_callback(cls, callback: Optional[Callable[[], None]]) -> None:
        with cls._lock:
            cls._callback = callback

    @classmethod
    def _bind_ipv4_socket(cls) -> Optional[socket.socket]:
        for port in _PORT_CANDIDATES:
            sock: Optional[socket.socket] = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.bind(("0.0.0.0", port))
                sock.settimeout(1.0)
                membership = struct.pack(
                    "4sI",
                    socket.inet_aton(_IPV4_MULTICAST_ADDRESS),
                    socket.INADDR_ANY,
                )
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, membership)
                logger.info(f"Discovery: bound to IPv4 port {port}")
                return sock
            except OSError as exception:
                logger.info(f"Discovery: failed to bind IPv4 port {port}: {exception}")
                if sock is not None:
                    sock.close()
        return None

    @classmethod
    def _listen_loop(cls, sock: socket.socket) -> None:
        while not cls._stop_event.is_set():
            try:
                data, address = sock.recvfrom(1024)
                if not data:
                    continue
                camera = json.loads(data.decode("utf-8"))
                cls._normalize_camera_ip(camera, address[0])

                with cls._lock:
                    exists = any(
                        item.get("sn") == camera.get("sn")
                        and item.get("ip") == camera.get("ip")
                        and item.get("ipv6") == camera.get("ipv6")
                        for item in cls._cameras
                    )
                    if exists:
                        continue
                    cls._cameras.append(camera)
                    callback = cls._callback

                if callback is not None:
                    try:
                        callback()
                    except Exception as exception:
                        logger.error(f"Discovery callback failed: {exception}")
            except socket.timeout:
                continue
            except (OSError, ValueError, UnicodeError, json.JSONDecodeError):
                if cls._stop_event.is_set():
                    break
                continue
        logger.info("Discovery: IPv4 listener stopped")

    @staticmethod
    def _normalize_camera_ip(camera: Dict, sender_ip: str) -> None:
        ip = camera.get("ip", "") or f"{sender_ip}:5000"
        if "127.0.0.1" in ip:
            ip = ip.replace("127.0.0.1", sender_ip)
        if ":" not in ip:
            ip += ":5000"
        camera["ip"] = ip
