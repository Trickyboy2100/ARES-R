"""
EpicRaw 解析与解码（SDK 内部）。

将 EpicRaw 字节加载为 EpicRawDocument，并从已加载文档原子化解码各类数据。
业务代码请通过 epiceye 包公开函数访问，勿直接引用本模块。
"""

import json
from typing import Optional, Union

import numpy as np

from ..epicraw_document import EpicRawDocument
from ..epicraw_image import EpicRawImage
from .epicraw_parser import (
    DataType,
    EpicRaw1,
    EpicRaw2,
    EpicRaw3DataType,
    FileType,
    _array_from_buffer,
    _decode_bgr_element,
    _decode_image_from_epicraw3,
    _decode_point_cloud_from_depth,
    _decode_point_cloud_from_epicraw3,
    _get_epicraw3_element,
    _get_file_type,
    _parse_distortion_from_meta,
    _parse_epicraw3,
    _parse_matrix_from_meta,
)


class EpicRawDecoder:
    @staticmethod
    def try_load_epic_raw_document_from_bytes(data: bytes):
        if data is None or len(data) < 8:
            return None
        file_type = _get_file_type(data)
        if file_type == FileType.EpicRaw1:
            raw1 = EpicRaw1.load_from_bytes(data)
            if raw1 is None:
                return None
            return EpicRawDocument(file_type, raw1=raw1)
        if file_type == FileType.EpicRaw2:
            raw2 = EpicRaw2.load_from_bytes(data)
            if raw2 is None:
                return None
            return EpicRawDocument(file_type, raw2=raw2)
        if file_type == FileType.EpicRaw3:
            raw3 = _parse_epicraw3(data)
            if raw3 is None:
                return None
            return EpicRawDocument(file_type, raw3=raw3)
        return None

    @staticmethod
    def _dims_from_hw_array(arr):
        if arr is None:
            return None, None, None
        if arr.ndim == 2:
            return arr, int(arr.shape[1]), int(arr.shape[0])
        if arr.ndim == 3:
            return arr, int(arr.shape[1]), int(arr.shape[0])
        return arr, None, None

    @staticmethod
    def decode_image(
        document: EpicRawDocument,
        data_type: Optional[EpicRaw3DataType] = None,
    ) -> Optional[Union[np.ndarray, EpicRawImage]]:
        if data_type is not None:
            return EpicRawDecoder._decode_image_by_type(document, data_type)
        return EpicRawDecoder._decode_image_from_document(document)

    @staticmethod
    def _decode_image_by_type(
        document: EpicRawDocument,
        data_type: EpicRaw3DataType,
    ) -> Optional[EpicRawImage]:
        if (
            document.file_type != FileType.EpicRaw3
            or document.raw3 is None
            or not isinstance(data_type, EpicRaw3DataType)
        ):
            return None

        element = _get_epicraw3_element(document.raw3, data_type)
        if element is None:
            return None

        width = element["width"]
        height = element["height"]
        mat_type = element["mat_type"]
        raw_data = element["data"]
        if (
            element["data_type"] != data_type.value
            or width <= 0
            or height <= 0
            or mat_type < 0
        ):
            return None

        depth_bytes = {0: 1, 2: 2}.get(mat_type & 7)
        if depth_bytes is None:
            return None

        channels = ((mat_type >> 3) & 0x1FF) + 1
        expected_length = width * height * channels * depth_bytes
        if (
            element.get("data_length") != expected_length
            or len(raw_data) != expected_length
        ):
            return None

        return EpicRawImage(
            data_type=data_type,
            width=width,
            height=height,
            mat_type=mat_type,
            data=memoryview(raw_data),
        )

    @staticmethod
    def _decode_image_from_document(doc: EpicRawDocument):
        if doc.file_type == FileType.EpicRaw1:
            if doc.raw1 is None or not doc.raw1["image_data"]:
                return None
            return _array_from_buffer(
                doc.raw1["image_data"], doc.raw1["width"], doc.raw1["height"], DataType.RGB24)
        if doc.file_type == FileType.EpicRaw2:
            if doc.raw2 is None or not doc.raw2["image_data"]:
                return None
            image_type = EpicRaw2.get_image_data_type(doc.raw2["data_type"])
            if image_type is None:
                return None
            return _array_from_buffer(
                doc.raw2["image_data"], doc.raw2["width"], doc.raw2["height"], image_type)
        if doc.file_type == FileType.EpicRaw3 and doc.raw3 is not None:
            return _decode_image_from_epicraw3(doc.raw3)
        return None

    @staticmethod
    def decode_depth(document: EpicRawDocument):
        return EpicRawDecoder._decode_depth_from_document(document)

    @staticmethod
    def _decode_depth_from_document(doc: EpicRawDocument):
        if doc.file_type == FileType.EpicRaw1:
            if doc.raw1 is None or not doc.raw1["depth_data"]:
                return None, None, None
            depth = _array_from_buffer(
                doc.raw1["depth_data"], doc.raw1["width"], doc.raw1["height"], DataType.Depth32)
            return depth, doc.raw1["width"], doc.raw1["height"]
        if doc.file_type == FileType.EpicRaw2:
            if doc.raw2 is None or not doc.raw2["depth_data"]:
                return None, None, None
            depth = _array_from_buffer(
                doc.raw2["depth_data"], doc.raw2["width"], doc.raw2["height"], DataType.Depth32)
            return depth, doc.raw2["width"], doc.raw2["height"]
        if doc.file_type == FileType.EpicRaw3 and doc.raw3 is not None:
            depth_el = _get_epicraw3_element(doc.raw3, EpicRaw3DataType.Depth)
            if depth_el is None:
                return None, None, None
            width = depth_el["width"]
            height = depth_el["height"]
            depth_arr = np.frombuffer(depth_el["data"], dtype=np.float32)
            if width <= 0 or height <= 0 or depth_arr.size != width * height:
                return None, None, None
            return depth_arr.reshape(height, width), width, height
        return None, None, None

    @staticmethod
    def decode_point_cloud(document: EpicRawDocument, undistort_lut=None):
        return EpicRawDecoder._decode_point_cloud_from_document(document, undistort_lut)

    @staticmethod
    def _decode_point_cloud_from_document(doc: EpicRawDocument, undistort_lut=None):
        if doc.file_type == FileType.EpicRaw1:
            if doc.raw1 is None or not doc.raw1["depth_data"]:
                return None, None, None
            width = doc.raw1["width"]
            height = doc.raw1["height"]
            depth = _array_from_buffer(
                doc.raw1["depth_data"], width, height, DataType.Depth32)
            pc = _decode_point_cloud_from_depth(depth, doc.raw1["camera_matrix"], undistort_lut)
            return pc, width, height
        if doc.file_type == FileType.EpicRaw2:
            if doc.raw2 is None or not doc.raw2["depth_data"]:
                return None, None, None
            width = doc.raw2["width"]
            height = doc.raw2["height"]
            depth = _array_from_buffer(
                doc.raw2["depth_data"], width, height, DataType.Depth32)
            pc = _decode_point_cloud_from_depth(depth, doc.raw2["camera_matrix"], undistort_lut)
            return pc, width, height
        if doc.file_type == FileType.EpicRaw3 and doc.raw3 is not None:
            point_el = _get_epicraw3_element(doc.raw3, EpicRaw3DataType.PointCloud)
            if point_el is not None and len(point_el["data"]) > 0:
                width = point_el["width"]
                height = point_el["height"]
                point_arr = np.frombuffer(point_el["data"], dtype=np.float32)
                if width > 0 and height > 0 and point_arr.size == width * height * 3:
                    return point_arr.reshape(height, width, 3), width, height
                return point_arr, width if width > 0 else None, height if height > 0 else None
            depth_el = _get_epicraw3_element(doc.raw3, EpicRaw3DataType.Depth)
            if depth_el is None:
                return None, None, None
            width = depth_el["width"]
            height = depth_el["height"]
            pc = _decode_point_cloud_from_epicraw3(doc.raw3, undistort_lut)
            return EpicRawDecoder._dims_from_hw_array(pc) if pc is not None else (None, None, None)
        return None, None, None

    @staticmethod
    def get_depth_intrinsics(document: EpicRawDocument):
        return EpicRawDecoder._get_depth_intrinsics_from_document(document)

    @staticmethod
    def decode_camera_config(document: EpicRawDocument):
        if document.file_type == FileType.EpicRaw1:
            if document.raw1 is None:
                return None
            return dict(document.raw1["camera_config"])
        if document.file_type == FileType.EpicRaw2:
            if document.raw2 is None:
                return None
            return EpicRawDecoder._parse_camera_config(document.raw2["config_data"])
        if document.file_type == FileType.EpicRaw3:
            if document.raw3 is None:
                return None
            return EpicRawDecoder._parse_camera_config(document.raw3["meta"])
        return None

    @staticmethod
    def _parse_camera_config(config_data):
        if not config_data:
            return None
        try:
            if isinstance(config_data, bytes):
                config_data = config_data.decode("utf-8")
            parsed = json.loads(config_data)
            if isinstance(parsed, str):
                parsed = json.loads(parsed)
            return parsed if isinstance(parsed, dict) else None
        except (UnicodeDecodeError, ValueError, TypeError):
            return None

    @staticmethod
    def _get_depth_intrinsics_from_document(doc: EpicRawDocument):
        if doc.file_type == FileType.EpicRaw1:
            if doc.raw1 is None:
                return None, None, 0, 0
            cm = doc.raw1["camera_matrix"].reshape(-1).tolist()
            # EPICRAW1/2 的畸变同样解析输出（全 0 也输出，不返回 None），与 C# GetDepthIntrinsics 对齐。
            dist = doc.raw1["distortion"].tolist() if doc.raw1.get("distortion") is not None else None
            return dist, cm, doc.raw1["width"], doc.raw1["height"]
        if doc.file_type == FileType.EpicRaw2:
            if doc.raw2 is None:
                return None, None, 0, 0
            cm = doc.raw2["camera_matrix"].reshape(-1).tolist()
            dist = doc.raw2["distortion"].tolist() if doc.raw2.get("distortion") is not None else None
            return dist, cm, doc.raw2["width"], doc.raw2["height"]
        if doc.file_type == FileType.EpicRaw3 and doc.raw3 is not None:
            depth_el = _get_epicraw3_element(doc.raw3, EpicRaw3DataType.Depth)
            width = depth_el["width"] if depth_el else 0
            height = depth_el["height"] if depth_el else 0
            meta = depth_el["meta"] if depth_el and depth_el.get("meta") else doc.raw3["meta"]
            matrix = _parse_matrix_from_meta(meta)
            distortion = _parse_distortion_from_meta(meta)
            cm = matrix.reshape(-1).tolist() if matrix is not None else None
            dist = distortion.tolist() if distortion is not None else None
            return dist, cm, width, height
        return None, None, 0, 0

    @staticmethod
    def decode_passive_binocular_images(document: EpicRawDocument):
        """从已解析文档解码被动双目图像。

        返回 (depth_src_img1, depth_src_img2, texture) 元组，缺失元素为 None。
        depth_src_img1/2 为 (H, W) 灰度图，texture 为 (H, W, 3) BGR 图。
        """
        return EpicRawDecoder._decode_passive_binocular_from_document(document)

    @staticmethod
    def _decode_passive_binocular_from_document(doc: EpicRawDocument):
        if doc.file_type != FileType.EpicRaw3 or doc.raw3 is None:
            return None, None, None
        raw3 = doc.raw3
        img1 = _decode_bgr_element(_get_epicraw3_element(raw3, EpicRaw3DataType.DepthSrcImg1))
        img2 = _decode_bgr_element(_get_epicraw3_element(raw3, EpicRaw3DataType.DepthSrcImg2))
        texture = _decode_bgr_element(_get_epicraw3_element(raw3, EpicRaw3DataType.TextureBGR))
        return img1, img2, texture

    @staticmethod
    def get_meta_data_str(document: EpicRawDocument, data_type: EpicRaw3DataType):
        return EpicRawDecoder._get_meta_data_str_from_document(document, data_type)

    @staticmethod
    def _get_meta_data_str_from_document(doc: EpicRawDocument, data_type: EpicRaw3DataType):
        if doc.file_type != FileType.EpicRaw3 or doc.raw3 is None:
            return None
        element = _get_epicraw3_element(doc.raw3, data_type)
        if element is None:
            return None
        meta = element.get("meta")
        return meta if isinstance(meta, str) else None
