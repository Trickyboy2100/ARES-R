"""EpicEye Python SDK 内部实现。"""
