from __future__ import annotations

from typing import Any

from ..core.point_cloud import ParsedPointCloud
from ..models import (
    ChangeSubGraphNodeIOParams,
    CreateDynamicSubGraphNodeParams,
    EditSubGraphNameParams,
    EditSubGraphNodeCommentParams,
    ExportSubGraphParams,
    SetSubgraphAsCustomSubgraphParams,
    SubGraphBindingUpdate,
    SubGraphConnectionParams,
    SubGraphCopyNodeParams,
    SubGraphCreateNodeParams,
    SubGraphNodeParamUpdate,
    SubGraphNodeRef,
    SubGraphPortRef,
    SubGraphRef,
)
from .base import BaseService


class GraphNodeService(BaseService):
    """子图节点服务。

    这组接口用于操作某个 graph node 内部的子图，包括子图节点的创建、
    复制、绑定、激活、设参和详情查询。
    """

    def open_graph(self, params: SubGraphRef) -> dict[str, Any]:
        """打开指定 graph node 对应的子图。

        Args:
            params: :class:`SubGraphRef`。包含 ``graph_name``（父图）和
                ``graph_node_id``（子图节点 ID）。

        Returns:
            `dict[str, Any]`：通常包含 `graph` 和 `timestamp`。
        """
        decoded = self._request(
            "GET",
            "/GraphNode/OpenGraph",
            params={"graphName": params.graph_name, "graphNodeId": params.graph_node_id},
            timestamp_graph_name=params.graph_name,
        )
        return self._data_with_request_status(decoded)

    def create_node(self, params: SubGraphCreateNodeParams) -> dict[str, Any]:
        """在子图中创建节点。

        Args:
            params: :class:`SubGraphCreateNodeParams`。包含 ``graph_name``、
                ``graph_node_id`` 和 ``node_name``。

        Returns:
            `dict[str, Any]`：通常包含 `nodeId`、`currentIndex`、`timestamp`。
        """
        payload = self._timestamp_payload(
            params.graph_name, graphNodeId=params.graph_node_id, nodeName=params.node_name
        )
        decoded = self._request(
            "POST",
            "/GraphNode/CreateNode",
            timestamp_graph_name=params.graph_name,
            json=payload,
        )
        return self._data_with_request_status(decoded)

    def create_dynamic_io_node(self, params: CreateDynamicSubGraphNodeParams) -> dict[str, Any]:
        """在子图中创建带动态输入输出定义的节点。

        Args:
            params: :class:`CreateDynamicSubGraphNodeParams`。包含父图名、子图节点 ID、节点名和 `node_data`。

        Returns:
            `dict[str, Any]`：通常包含 `nodeId`、`currentIndex`、`timestamp`。
        """
        payload = self._timestamp_payload(
            params.graph_name,
            graphNodeId=params.graph_node_id,
            nodeName=params.node_name,
            nodeData=params.node_data,
        )
        decoded = self._request(
            "POST",
            "/GraphNode/CreateDynamicIONode",
            timestamp_graph_name=params.graph_name,
            json=payload,
        )
        return self._data_with_request_status(decoded)

    def create_node_by_copy(self, params: SubGraphCopyNodeParams) -> dict[str, Any]:
        """复制子图中的一个节点。

        Args:
            params: :class:`SubGraphCopyNodeParams`。包含 ``graph_name``、
                ``graph_node_id``、``node_name``（新节点名）和
                ``node_id``（被复制节点 ID）。

        Returns:
            `dict[str, Any]`：通常包含新节点的 `nodeId`、`currentIndex`、`timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/CreateNodeByCopy",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name,
                graphNodeId=params.graph_node_id,
                nodeName=params.node_name,
                nodeId=params.node_id,
            ),
        )
        return self._data_with_request_status(decoded)

    def change_node_io(self, params: ChangeSubGraphNodeIOParams) -> dict[str, Any]:
        """修改子图内某个动态节点的输入输出定义。

        Args:
            params: :class:`ChangeSubGraphNodeIOParams`。包含父图名、子图节点 ID、子图内节点 ID 和新的 `node_data`。

        Returns:
            `dict[str, Any]`：通常包含 `nodeId`、`currentIndex`、`timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/ChangeNodeIO",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name,
                graphNodeId=params.graph_node_id,
                nodeId=params.node_id,
                nodeData=params.node_data,
            ),
        )
        return self._data_with_request_status(decoded)

    def delete_node(self, params: SubGraphNodeRef) -> dict[str, Any]:
        """删除子图中的节点。

        Args:
            params: :class:`SubGraphNodeRef`。包含 ``graph_name``、
                ``graph_node_id`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/DeleteNode",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name, graphNodeId=params.graph_node_id, nodeId=params.node_id
            ),
        )
        return self._data_with_request_status(decoded)

    def connect_nodes(self, params: SubGraphConnectionParams) -> dict[str, Any]:
        """连接子图中的两个节点。

        Args:
            params: :class:`SubGraphConnectionParams`。包含 ``graph_name``、
                ``graph_node_id``、``output``（源节点端点）和 ``input``（目标节点端点）。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        payload = self._timestamp_payload(
            params.graph_name,
            graphNodeId=params.graph_node_id,
            inputs={"nodeId": params.input_node_id, "portName": params.input_port_name},
            outputs={"nodeId": params.output_node_id, "portName": params.output_port_name},
        )
        decoded = self._request(
            "POST", "/GraphNode/ConnectNodes", timestamp_graph_name=params.graph_name, json=payload
        )
        return self._data_with_request_status(decoded)

    def disconnect_nodes(self, params: SubGraphConnectionParams) -> dict[str, Any]:
        """断开子图中的两个节点连接。

        Args:
            params: :class:`SubGraphConnectionParams`。包含 ``graph_name``、
                ``graph_node_id``、``output``（源节点端点）和 ``input``（目标节点端点）。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        payload = self._timestamp_payload(
            params.graph_name,
            graphNodeId=params.graph_node_id,
            inputs={"nodeId": params.input_node_id, "portName": params.input_port_name},
            outputs={"nodeId": params.output_node_id, "portName": params.output_port_name},
        )
        decoded = self._request(
            "POST", "/GraphNode/DisconnectNodes", timestamp_graph_name=params.graph_name, json=payload
        )
        return self._data_with_request_status(decoded)

    def get_node_params(self, params: SubGraphNodeRef) -> dict[str, Any]:
        """获取子图内节点参数快照。

        Args:
            params: :class:`SubGraphNodeRef`。包含 ``graph_name``、
                ``graph_node_id`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：通常包含 `init_params` 和 `run_params`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/GetNodeParams",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "nodeId": params.node_id,
            },
        )
        data = decoded.data or {}
        return data.get("data", data)

    def get_node_info_in_graph(self, params: SubGraphNodeRef) -> dict[str, Any]:
        """获取子图中某个节点的完整信息。

        Args:
            params: :class:`SubGraphNodeRef`。包含 ``graph_name``、
                ``graph_node_id`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：通常包含 `paramsData`、`nodeInfo`、`strategy`、
            `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/GetNodeInfoInGraph",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "nodeId": params.node_id,
            },
        )
        return self._data_with_request_status(decoded)

    def get_node_port_data(self, params: SubGraphPortRef) -> dict[str, Any]:
        """获取子图内节点端口数据。

        Args:
            params: :class:`SubGraphPortRef`。包含 ``graph_name``、
                ``graph_node_id``、``node_id``、``port_name`` 和 ``io_type``。

        Returns:
            `dict[str, Any]`：端口展示数据。若服务端返回了附件，SDK 会自动合并。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/GetNodePortData",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "nodeId": params.node_id,
                "portName": params.port_name,
                "IOtype": params.io_type,
            },
        )
        return self._merge_attachments(decoded)

    def get_points_data(self, params: SubGraphPortRef) -> bytes:
        """获取子图内节点端口的原始点云字节流。

        Args:
            params: :class:`SubGraphPortRef`。包含 ``graph_name``、
                ``graph_node_id``、``node_id``、``port_name`` 和 ``io_type``。

        Returns:
            `bytes`：服务端直接返回的原始字节。
        """
        return self._request_raw(
            "POST",
            "/GraphNode/GetPointsData",
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "nodeId": params.node_id,
                "portName": params.port_name,
                "IOtype": params.io_type,
            },
        )

    def get_points_data_parsed(self, params: SubGraphPortRef) -> list[ParsedPointCloud]:
        """获取子图内节点点云，并按服务端头信息解析成结构化结果。

        Args:
            params: :class:`SubGraphPortRef`。包含 ``graph_name``、
                ``graph_node_id``、``node_id``、``port_name`` 和 ``io_type``。
        """
        raw_payload = self.get_points_data(params)
        return self._decode_point_cloud_payload(raw_payload, has_dim_in_header=True)

    def download_data(self, params: SubGraphPortRef) -> dict[str, Any]:
        """为子图节点端口数据生成可下载 URL。

        Args:
            params: :class:`SubGraphPortRef`。包含父图名、子图节点 ID、节点 ID、端口名和端口方向。

        Returns:
            `dict[str, Any]`：通常包含 `url`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/DownloadData",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "nodeId": params.node_id,
                "portName": params.port_name,
                "IOtype": params.io_type,
            },
        )
        return self._data_with_request_status(decoded)

    def set_node_param_data(self, params: SubGraphNodeParamUpdate) -> dict[str, Any]:
        """设置子图内节点参数。

        Args:
            params: :class:`SubGraphNodeParamUpdate`。包含 ``graph_name``、
                ``graph_node_id``、``node_id``、``param_name``、``param_type``
                和 ``value``。若 ``value`` 为 ``PathLike``，SDK 会自动按文件上传。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        payload: dict[str, Any] = {
            "graphName": params.graph_name,
            "graphNodeId": params.graph_node_id,
            "nodeId": params.node_id,
            "portName": params.param_name,
            "IOtype": params.param_type,
        }
        timestamp = self.timestamps.get(params.graph_name)
        if timestamp is not None:
            payload["timestamp"] = timestamp
        decoded = self._request(
            "POST",
            "/GraphNode/SetNodeParamData",
            timestamp_graph_name=params.graph_name,
            **self._build_param_request_kwargs(payload, params.value),
        )
        return self._data_with_request_status(decoded)

    def set_binding_name(self, params: SubGraphBindingUpdate) -> dict[str, Any]:
        """设置子图节点的绑定名。

        Args:
            params: :class:`SubGraphBindingUpdate`。包含 ``graph_name``、
                ``graph_node_id``、``node_id``、``binding_type``、``origin_name``
                和 ``binding_name``。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/SetBindingName",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name,
                graphNodeId=params.graph_node_id,
                nodeId=params.node_id,
                bindingType=params.binding_type,
                originName=params.origin_name,
                bindingName=params.binding_name,
            ),
        )
        return self._data_with_request_status(decoded)

    def edit_node_comment(self, params: EditSubGraphNodeCommentParams) -> dict[str, Any]:
        """修改子图内节点备注。

        Args:
            params: :class:`EditSubGraphNodeCommentParams`。包含父图名、子图节点 ID、子图内节点 ID 和新备注。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/EditNodeComment",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name,
                graphNodeId=params.graph_node_id,
                nodeId=params.node_id,
                comment=params.comment,
            ),
        )
        return self._data_with_request_status(decoded)

    def get_graph_bindings(self, params: SubGraphRef) -> dict[str, Any]:
        """获取子图当前的绑定信息。

        Args:
            params: :class:`SubGraphRef`。包含父图名称和子图节点 ID。

        Returns:
            `dict[str, Any]`：当前子图绑定信息。
        """
        decoded = self._request(
            "GET",
            "/GraphNode/GetGraphBindings",
            timestamp_graph_name=params.graph_name,
            params={"graphName": params.graph_name, "graphNodeId": params.graph_node_id},
        )
        return self._data_with_request_status(decoded)

    def edit_graph_name(self, params: EditSubGraphNameParams) -> Any:
        """修改子图名称。

        Args:
            params: :class:`EditSubGraphNameParams`。包含父图名、子图节点 ID 和新子图名称。

        Returns:
            `Any`：服务端当前通常返回 `True`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/EditGraphName",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "newSubGraphName": params.new_sub_graph_name,
            },
        )
        return decoded.data

    def get_graph_dl_nodes_model_info(self, params: SubGraphRef) -> Any:
        """获取子图里深度学习节点相关模型信息。

        Args:
            params: :class:`SubGraphRef`。包含父图名称和子图节点 ID。

        Returns:
            `Any`：服务端返回的模型信息映射。
        """
        decoded = self._request(
            "GET",
            "/GraphNode/GetGraphDLNodesModelInfo",
            timestamp_graph_name=params.graph_name,
            params={"graphName": params.graph_name, "graphNodeId": params.graph_node_id},
        )
        return decoded.data

    def get_graph_custom_nodes(self, params: SubGraphRef) -> Any:
        """获取子图中使用到的自定义节点信息。

        Args:
            params: :class:`SubGraphRef`。包含父图名称和子图节点 ID。

        Returns:
            `Any`：服务端返回的自定义节点信息映射。
        """
        decoded = self._request(
            "GET",
            "/GraphNode/GetGraphCustomNodes",
            timestamp_graph_name=params.graph_name,
            params={"graphName": params.graph_name, "graphNodeId": params.graph_node_id},
        )
        return decoded.data

    def export_graph(self, params: ExportSubGraphParams) -> dict[str, Any]:
        """导出某个 graph node 内部子图。

        Args:
            params: :class:`ExportSubGraphParams`。包含父图名、子图节点 ID 以及可选模型/自定义节点信息。

        Returns:
            `dict[str, Any]`：通常包含 `percent` 和完成后的下载 `url`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/ExportGraph",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "DLModelsInfo": params.dl_models_info or {},
                "customNodes": params.custom_nodes or {},
            },
        )
        return self._data_with_request_status(decoded)

    def release_graph(self, params: SubGraphRef) -> Any:
        """释放指定 graph node 对应的子图。

        Args:
            params: :class:`SubGraphRef`。包含父图名称和子图节点 ID。

        Returns:
            `Any`：服务端当前通常返回 `True`。
        """
        decoded = self._request(
            "GET",
            "/GraphNode/ReleaseGraph",
            timestamp_graph_name=params.graph_name,
            params={"graphName": params.graph_name, "graphNodeId": params.graph_node_id},
        )
        self.timestamps.clear(params.graph_name)
        return decoded.data

    def clear_graph(self, params: SubGraphRef) -> dict[str, Any]:
        """清空子图运行残留数据。

        Args:
            params: :class:`SubGraphRef`。包含父图名称和子图节点 ID。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/ClearGraph",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, graphNodeId=params.graph_node_id),
        )
        return self._data_with_request_status(decoded)

    def get_all_nodes_info(self) -> dict[str, Any]:
        """获取子图编辑场景下可用的全部节点信息。

        Returns:
            `dict[str, Any]`：按节点类名组织的节点定义信息。
        """
        decoded = self._request("GET", "/GraphNode/GetAllNodesInfo")
        return decoded.data

    def set_subgraph_as_custom_subgraph(self, params: SetSubgraphAsCustomSubgraphParams) -> dict[str, Any]:
        """把 graph node 内部子图保存为可复用的自定义子图模板。

        Args:
            params: :class:`SetSubgraphAsCustomSubgraphParams`。包含父图名、子图节点 ID 和目标模板名。

        Returns:
            `dict[str, Any]`：通常包含 `customGraphName`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/SetSubgraphAsCustomSubgraph",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "graphNodeId": params.graph_node_id,
                "customSubGraphName": params.custom_subgraph_name,
            },
        )
        return self._data_with_request_status(decoded)

    def activate_node(self, params: SubGraphNodeRef, *, timeout_seconds: float | None = 30) -> dict[str, Any]:
        """激活子图中的某个节点及其后续节点。

        Args:
            params: :class:`SubGraphNodeRef`。包含 ``graph_name``、
                ``graph_node_id`` 和 ``node_id``。
            timeout_seconds: `float | None`。等待子图节点激活完成的最长秒数。
                传入 `None` 表示一直等待，直到完成或服务端返回错误。

        Returns:
            `dict[str, Any]`：激活状态信息，通常包含 `nodeActivated`、`finish`、
            `timestamp`。
        """
        decoded = self._request_until_finish(
            "POST",
            "/GraphNode/ActivateNode",
            json=self._timestamp_payload(
                params.graph_name, graphNodeId=params.graph_node_id, nodeId=params.node_id
            ),
            timeout_seconds=timeout_seconds,
            timestamp_graph_name=params.graph_name,
        )
        return self._data_with_request_status(decoded)

    def initial_node(self, params: SubGraphNodeRef) -> dict[str, Any]:
        """初始化子图中的某个节点。

        Args:
            params: :class:`SubGraphNodeRef`。包含 ``graph_name``、
                ``graph_node_id`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：通常包含 `success` 和 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/InitialNode",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name, graphNodeId=params.graph_node_id, nodeId=params.node_id
            ),
        )
        return self._data_with_request_status(decoded)

    def update_node(self, params: SubGraphNodeRef) -> dict[str, Any]:
        """更新子图中的单个节点。

        Args:
            params: :class:`SubGraphNodeRef`。包含 ``graph_name``、
                ``graph_node_id`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：更新状态信息，通常包含 `nodeActivated`、`finish`、
            `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/GraphNode/UpdateNode",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name, graphNodeId=params.graph_node_id, nodeId=params.node_id
            ),
        )
        return self._data_with_request_status(decoded)

    def run_graph(self, params: SubGraphRef, *, timeout_seconds: float | None = 30) -> dict[str, Any]:
        """运行子图。

        Args:
            params: :class:`SubGraphRef`。包含 ``graph_name``（父图）和
                ``graph_node_id``（子图节点 ID）。
            timeout_seconds: `float | None`。等待子图运行完成的最长秒数。
                传入 `None` 表示一直等待，直到完成或服务端返回错误。

        Returns:
            `dict[str, Any]`：运行状态信息，通常包含 `finish`、`nodeActivated`、
            `total_time`、`timestamp`。
        """
        decoded = self._request_until_finish(
            "POST",
            "/GraphNode/RunGraph",
            json=self._timestamp_payload(params.graph_name, graphNodeId=params.graph_node_id),
            timeout_seconds=timeout_seconds,
            timestamp_graph_name=params.graph_name,
        )
        return self._data_with_request_status(decoded)
