from __future__ import annotations

import functools
import inspect
import json
import os
import sys
import time


def _typed_param(func):
    """装饰器：在定义时解析参数类型注解并缓存，调用时校验实际类型，不符时抛出 TypeError。"""
    try:
        signature = inspect.signature(func)
        param = next(
            (
                parameter
                for parameter in signature.parameters.values()
                if parameter.name != "self"
                and parameter.kind
                in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
            ),
            None,
        )
        if param is None or param.annotation is inspect.Parameter.empty:
            check = None
        else:
            expected = param.annotation
            if isinstance(expected, str):
                # SDK 模块使用了延迟注解。只解析待校验的参数，避免 Python 3.8
                # 因为函数返回值里的 `dict[str, ...]` 等写法而整体解析失败。
                expected = eval(expected, vars(sys.modules[func.__module__]))
            check = (param.name, expected)
    except Exception:
        check = None

    @functools.wraps(func)
    def wrapper(self, param, *args, **kwargs):
        if check is not None:
            name, expected = check
            if not isinstance(param, expected):
                raise TypeError(
                    f"{type(self).__name__}.{func.__name__}(): "
                    f"'{name}' 须为 {expected.__name__}，"
                    f"实际传入了 {type(param).__name__}"
                )
        return func(self, param, *args, **kwargs)

    return wrapper


from ..core.codecs import decode_payload
from ..core.errors import AtomTimeoutError
from ..core.point_cloud import decode_point_cloud_payload
from ..core.single_node import prepare_single_node_inputs


class BaseService:
    """所有 Service 的公共基类。

    它负责统一请求发送、响应解码、timestamp 缓存更新，以及二进制附件合并。
    """

    def __init_subclass__(cls, **kwargs):
        """子类定义完成后，自动对所有公开的单业务参数方法应用类型校验装饰器。"""
        super().__init_subclass__(**kwargs)
        for attr_name, attr_value in vars(cls).items():
            if attr_name.startswith("_") or not callable(attr_value):
                continue
            sig = inspect.signature(attr_value)
            non_self = [p for name, p in sig.parameters.items() if name != "self"]
            positional_params = [
                p
                for p in non_self
                if p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
            ]
            has_only_optional_keywords = all(
                p in positional_params
                or (p.kind == inspect.Parameter.KEYWORD_ONLY and p.default is not inspect.Parameter.empty)
                for p in non_self
            )
            if len(positional_params) == 1 and has_only_optional_keywords:
                setattr(cls, attr_name, _typed_param(attr_value))

    def __init__(self, transport, timestamps):
        """初始化服务基类。

        Args:
            transport: 发送 HTTP 请求的传输对象。
            timestamps: 图级别 timestamp 存储对象。
        """
        self.transport = transport
        self.timestamps = timestamps

    def _request(self, method, path, *, timestamp_graph_name: str | None = None, **kwargs):
        """发送请求并按 Atom 协议解码，可选地同步图的最新时间戳。"""
        response = self.transport.request(method, path, **kwargs)
        decoded = decode_payload(response)
        if timestamp_graph_name is None:
            timestamp_graph_name = self._infer_timestamp_graph_name(kwargs)
        if timestamp_graph_name is not None:
            self._maybe_save_timestamp(timestamp_graph_name, decoded.data)
        return decoded

    @staticmethod
    def _infer_timestamp_graph_name(request_kwargs) -> str | None:
        """从请求关键字或常见请求体中推断时间戳所属的图名称。"""
        candidates = [request_kwargs]
        candidates.extend(
            request_kwargs.get(container_name)
            for container_name in ("params", "json", "data")
        )
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            for field_name in ("graphName", "graph_name"):
                graph_name = candidate.get(field_name)
                if isinstance(graph_name, str) and graph_name:
                    return graph_name
        return None

    def _data_with_request_status(self, decoded):
        """把服务端业务状态码补回业务数据，方便调用方记录请求结果。"""
        if isinstance(decoded.data, dict):
            data = dict(decoded.data)
            data.setdefault("status", decoded.status)
            return data
        return decoded.data

    def _request_raw(self, method, path, **kwargs):
        """发送请求并直接返回原始字节内容。"""
        response = self.transport.request(method, path, **kwargs)
        return response.content

    def _decode_point_cloud_payload(self, payload: bytes, *, has_dim_in_header: bool, point_dim: int | None = None):
        """解析 Atom 服务端返回的点云二进制流。"""
        return decode_point_cloud_payload(payload, has_dim_in_header=has_dim_in_header, point_dim=point_dim)

    def _request_until_finish(
        self,
        method,
        path,
        *,
        finish_key: str = "finish",
        timeout_seconds: float | None = 30,
        sleep_seconds: float = 1,
        timestamp_graph_name: str | None = None,
        **kwargs,
    ):
        """发送请求；若返回值包含 `finish=False`，则自动轮询直到完成或超时。

        这用于适配 Atom 编辑态接口的真实行为：像 `RunGraph`、`ActivateNode`
        这类接口通常需要反复请求，直到服务端返回 `finish=True`。
        """
        start_time = time.monotonic()
        last_decoded = None
        attempts = 0
        while True:
            attempts += 1
            request_kwargs = dict(kwargs)
            if isinstance(kwargs.get("json"), dict):
                request_kwargs["json"] = dict(kwargs["json"])
            last_decoded = self._request(
                method,
                path,
                timestamp_graph_name=timestamp_graph_name,
                **request_kwargs,
            )
            data = last_decoded.data
            if not isinstance(data, dict) or finish_key not in data or data.get(finish_key) is True:
                return last_decoded
            if timestamp_graph_name is not None and isinstance(kwargs.get("json"), dict):
                latest_timestamp = self.timestamps.get(timestamp_graph_name)
                if latest_timestamp is not None:
                    kwargs["json"] = {**kwargs["json"], "timestamp": latest_timestamp}
            elapsed_seconds = time.monotonic() - start_time
            if timeout_seconds is not None and elapsed_seconds >= timeout_seconds:
                raise AtomTimeoutError(
                    (
                        f"Timed out waiting for {path} to finish after "
                        f"{timeout_seconds:g}s; attempts={attempts}; last response={data!r}"
                    ),
                    path=path,
                    timeout_seconds=timeout_seconds,
                    attempts=attempts,
                    last_data=data,
                )
            if timeout_seconds is None:
                time.sleep(sleep_seconds)
            else:
                time.sleep(min(sleep_seconds, max(timeout_seconds - elapsed_seconds, 0)))

    def _maybe_save_timestamp(self, graph_name: str, data):
        """如果响应中包含 timestamp，则更新本地图缓存。"""
        if isinstance(data, dict) and "timestamp" in data and data["timestamp"] is not None:
            self.timestamps.set(graph_name, data["timestamp"])

    def _merge_attachments(self, decoded):
        """把二进制附件合并回解码后的字典结果。"""
        if not isinstance(decoded.data, dict):
            return decoded.data
        merged = self._data_with_request_status(decoded)
        import logging as logger
        if decoded.attachments:
            merged.setdefault("attachments", {})
            merged["attachments"].update(decoded.attachments)
            for name, data in decoded.attachments.items():
                if name not in merged or merged[name] in (None, "", [], {}):
                    merged[name] = data
        return merged

    def _timestamp_payload(self, graph_name: str, **extra):
        """构建自动带 timestamp 的请求体。"""
        payload = {"graphName": graph_name}
        timestamp = self.timestamps.get(graph_name)
        if timestamp is not None:
            payload["timestamp"] = timestamp
        payload.update(extra)
        return payload

    def _build_param_request_kwargs(self, payload, value):
        """为设置参数接口构建普通表单或文件上传请求。"""
        request_data = dict(payload)
        if value is None:
            request_data["data"] = "null"
            return {"data": request_data}

        if isinstance(value, os.PathLike):
            path = os.fspath(value)
            with open(path, "rb") as file_obj:
                file_bytes = file_obj.read()
            return {
                "data": request_data,
                "files": {"data": (os.path.basename(path), file_bytes)},
            }

        if isinstance(value, bool):
            request_data["data"] = json.dumps(value)
        elif isinstance(value, (dict, list, tuple)):
            request_data["data"] = json.dumps(value, ensure_ascii=False)
        else:
            request_data["data"] = value
        return {"data": request_data}

    def _build_single_node_request_kwargs(
        self,
        node_name: str,
        inputs=None,
        run_params=None,
        init_params=None,
        input_data_types=None,
        input_point_dims=None,
    ):
        """为 RunSingleNodeNoGraph 构建混合表单/文件上传请求。"""
        prepared_inputs = prepare_single_node_inputs(
            inputs,
            input_data_types=input_data_types,
            point_dims=input_point_dims,
        )
        payload = {
            "values": {
                "nodeName": node_name,
                "inputs": prepared_inputs.values,
                "runParams": run_params or {},
                "initParams": init_params or {},
            }
        }
        kwargs = {"data": {"payload": json.dumps(payload, ensure_ascii=False)}}
        if prepared_inputs.files:
            kwargs["files"] = prepared_inputs.files
        return kwargs
