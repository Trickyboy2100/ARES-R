from __future__ import annotations

from pathlib import Path
from typing import Any

from ..models import (
    CopyGraphParams,
    CreateGraphParams,
    EditGraphCommentParams,
    EditGraphNameParams,
    ExportGraphParams,
    ImportExtensionNodesByPathParams,
    LoadGraphParams,
)
from .base import BaseService

class GraphService(BaseService):
    """主图管理服务。

    这一组接口对应 `atom_vp_interface` 里的 `/Graph/*` 路由，主要用于
    主图的创建、打开、导入导出、运行和元信息读取。
    """

    def create_graph(self, params: CreateGraphParams) -> dict[str, Any]:
        """创建一个新的主图。

        Args:
            params: :class:`CreateGraphParams`。包含 ``graph_name`` 和可选的
                ``description``。

        Returns:
            `dict[str, Any]`：服务端返回的图结构数据。

        Notes:
            如果返回值里包含 `timestamp`，SDK 会自动同步到本地缓存。
        """
        payload: dict[str, Any] = {"graphName": params.graph_name}
        if params.description is not None:
            payload["description"] = params.description
        decoded = self._request(
            "POST", "/Graph/CreateGraph", timestamp_graph_name=params.graph_name, json=payload
        )
        return self._data_with_request_status(decoded)

    def list_graphs(self) -> Any:
        """获取所有主图概要信息列表。

        Returns:
            `Any`：通常是 `list[dict[str, Any]]`，每个元素包含图名称、状态、
            最近修改时间、是否模板图等摘要信息。
        """
        return self._request("GET", "/Graph/GetAllGraphsNoThumbnail").data

    def get_all_custom_subgraphs_no_thumbnail(self) -> Any:
        """获取所有已注册的自定义子图概要列表。

        Returns:
            `Any`：通常是 `list[dict[str, Any]]`，每项描述一个自定义子图。
        """
        return self._request("GET", "/Graph/GetAllCustomSubgraphsNoThumbnail").data

    def _graph_name_exists(self, graph_name: str) -> bool:
        """检查当前图列表里是否已经存在指定图名称。"""
        graphs = self.list_graphs()
        if not isinstance(graphs, list):
            return False
        for graph in graphs:
            if not isinstance(graph, dict):
                continue
            if graph.get("graphName") == graph_name:
                return True
            if graph.get("GraphName") == graph_name:
                return True
            if graph.get("name") == graph_name:
                return True
            if graph.get("NAME") == graph_name:
                return True
        return False

    def copy_graph(self, params: CopyGraphParams) -> dict[str, Any]:
        """复制一张图。

        Args:
            params: :class:`CopyGraphParams`。包含 ``graph_name``（源图）和
                ``new_graph_name``（新图）。

        Returns:
            `dict[str, Any]`：新图的结构信息。
        """
        decoded = self._request(
            "POST",
            "/Graph/CopyGraph",
            json={"graphName": params.graph_name, "newGraphName": params.new_graph_name},
            timestamp_graph_name=params.new_graph_name,
        )
        return self._data_with_request_status(decoded)

    def delete_graph(self, graph_name: str) -> Any:
        """删除一张图并清理本地 `timestamp` 缓存。

        Args:
            graph_name: `str`。要删除的图名称。

        Returns:
            `Any`：服务端通常返回 `True`。
        """
        decoded = self._request(
            "GET", "/Graph/DeleteGraph", timestamp_graph_name=graph_name,
            params={"graphName": graph_name}
        )
        self.timestamps.clear(graph_name)
        return decoded.data

    def get_all_nodes_info(self) -> dict[str, Any]:
        """获取所有可用节点信息。

        Returns:
            `dict[str, Any]`：按节点类名组织的节点定义信息，通常包含参数、输入、
            输出、标签、说明等内容。
        """
        decoded = self._request("GET", "/Graph/GetAllNodesInfo")
        return decoded.data

    def get_graph_dl_nodes_model_info(self, graph_name: str) -> Any:
        """获取图中深度学习节点相关模型信息。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `Any`：服务端返回的模型信息映射。
        """
        decoded = self._request("GET", "/Graph/GetGraphDLNodesModelInfo", timestamp_graph_name=graph_name, params={"graphName": graph_name})
        return decoded.data

    def get_graph_custom_nodes(self, graph_name: str) -> Any:
        """获取图中使用到的自定义节点信息。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `Any`：服务端返回的自定义节点信息映射。
        """
        decoded = self._request("GET", "/Graph/GetGraphCustomNodes", timestamp_graph_name=graph_name, params={"graphName": graph_name})
        return decoded.data

    def get_graph_workcell_models_info(self, graph_name: str, *, graph_node_id: str | None = None) -> Any:
        """获取图或指定子图节点关联的 workcell 模型信息。

        Args:
            graph_name: `str`。图名称。
            graph_node_id: `str | None`。可选，指定 graph node 时查询其内部子图。

        Returns:
            `Any`：服务端返回的 workcell 模型信息。
        """
        params: dict[str, Any] = {"graphName": graph_name}
        if graph_node_id is not None:
            params["graphNodeId"] = graph_node_id
        decoded = self._request("GET", "/Graph/GetGraphWorkcellModelsInfo", timestamp_graph_name=graph_name, params=params)
        return decoded.data

    def get_graph_bindings(self, graph_name: str) -> dict[str, Any]:
        """获取图当前的绑定信息。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：当前图上的绑定信息，通常按 `inputs`、`outputs`、
            `init_params`、`run_params` 分组。
        """
        decoded = self._request("GET", "/Graph/GetGraphBindings", timestamp_graph_name=graph_name, params={"graphName": graph_name})
        return self._data_with_request_status(decoded)

    def load_graph(self, params: LoadGraphParams) -> dict[str, Any]:
        """导入一张图文件。

        Args:
            params: :class:`LoadGraphParams`。包含 ``graph_name``（导入后的图名称）
                和 ``file_path``（本地 ``.atom`` 文件路径）。

        Returns:
            `dict[str, Any]`：导入进度和结果信息，通常包含 `percent`、
            `hasConflictNodes`、`extensionNodes`。

        Raises:
            ValueError: 目标图名称已经存在。此时不会上传文件。
        """
        if self._graph_name_exists(params.graph_name):
            raise ValueError(f"graph_name {params.graph_name!r} already exists, please try again after with a new graph_name.")
        path = Path(params.file_path)
        decoded = self._request(
            "POST",
            "/Graph/LoadGraph",
            timestamp_graph_name=params.graph_name,
            data={"graphName": params.graph_name},
            files={"data": (path.name, path.read_bytes())},
        )
        return self._data_with_request_status(decoded)

    def import_extension_nodes_by_path(self, params: ImportExtensionNodesByPathParams) -> Any:
        """导入 ``load_graph`` 解压出的扩展节点文件。

        Args:
            params: :class:`ImportExtensionNodesByPathParams`。其中
                ``extension_nodes`` 通常直接取自 ``load_graph`` 返回值里的
                ``extensionNodes`` 字段。

        Returns:
            `Any`：服务端返回的导入结果消息，通常是字符串。
        """
        decoded = self._request(
            "POST",
            "/Graph/ImportExtensionNodesByPath",
            json={"extensionNodes": params.extension_nodes},
        )
        return self._data_with_request_status(decoded)

    def export_graph(self, params: ExportGraphParams) -> dict[str, Any]:
        """导出图及相关模型、扩展节点信息。

        Args:
            params: :class:`ExportGraphParams`。包含 ``graph_name``、可选的
                ``dl_models_info`` 和 ``custom_nodes``。

        Returns:
            `dict[str, Any]`：导出进度与下载链接信息，通常包含 `percent` 和 `url`。
        """
        decoded = self._request(
            "POST",
            "/Graph/ExportGraph",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "DLModelsInfo": params.dl_models_info or {},
                "customNodes": params.custom_nodes or {},
            },
        )
        return self._data_with_request_status(decoded)

    def open_graph(self, graph_name: str) -> dict[str, Any]:
        """打开主图并缓存返回的 timestamp。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：打开结果，通常包含 `graph`、`firstOpen` 和 `timestamp`。
        """
        decoded = self._request("GET", "/Graph/OpenGraph", timestamp_graph_name=graph_name, params={"graphName": graph_name})
        return self._data_with_request_status(decoded)

    def edit_graph_name(self, params: EditGraphNameParams) -> Any:
        """修改图名称。

        Args:
            params: :class:`EditGraphNameParams`。包含旧图名和新图名。

        Returns:
            `Any`：服务端当前通常返回 `True`。
        """
        decoded = self._request(
            "POST",
            "/Graph/EditGraphName",
            json={"graphName": params.graph_name, "newGraphName": params.new_graph_name},
            timestamp_graph_name=params.new_graph_name,
        )
        self.timestamps.clear(params.graph_name)
        return decoded.data

    def release_graph(self, graph_name: str) -> Any:
        """释放主图并清理本地 `timestamp` 缓存。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `Any`：服务端通常返回 `True`。
        """
        decoded = self._request("GET", "/Graph/ReleaseGraph", timestamp_graph_name=graph_name, params={"graphName": graph_name})
        self.timestamps.clear(graph_name)
        return decoded.data

    def run_graph(self, graph_name: str, *, timeout_seconds: float | None = 30) -> dict[str, Any]:
        """运行主图。

        Args:
            graph_name: `str`。图名称。
            timeout_seconds: `float | None`。等待图运行完成的最长秒数。
                传入 `None` 表示一直等待，直到完成或服务端返回错误。

        Returns:
            `dict[str, Any]`：运行状态信息，通常包含 `nodeActivated`、
            `finish`、`total_time`、`timestamp`。

        Notes:
            该方法会自动把当前缓存的 `timestamp` 带给服务端。
        """
        decoded = self._request_until_finish(
            "POST",
            "/Graph/RunGraph",
            json=self._timestamp_payload(graph_name),
            timeout_seconds=timeout_seconds,
            timestamp_graph_name=graph_name,
        )
        return self._data_with_request_status(decoded)

    def clear_graph(self, graph_name: str) -> dict[str, Any]:
        """清空图内运行残留数据。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request("POST", "/Graph/ClearGraph", timestamp_graph_name=graph_name, json=self._timestamp_payload(graph_name))
        return self._data_with_request_status(decoded)

    def edit_graph_comment(self, params: EditGraphCommentParams) -> Any:
        """修改图备注。

        Args:
            params: :class:`EditGraphCommentParams`。包含图名称和新备注。

        Returns:
            `Any`：服务端当前通常返回 `True`。
        """
        decoded = self._request(
            "POST",
            "/Graph/EditGraphComment",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, comment=params.comment),
        )
        return decoded.data

    def get_graph_json_data(self, graph_name: str) -> dict[str, Any]:
        """获取图的原始 JSON 结构数据。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：通常包含 `graph_data`。
        """
        decoded = self._request("GET", "/Graph/GetGraphJsonData", timestamp_graph_name=graph_name, params={"graphName": graph_name})
        return self._data_with_request_status(decoded)

    def get_timestamp(self, graph_name: str) -> dict[str, Any]:
        """获取服务端当前图时间戳并同步到本地缓存。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：通常为 `{"timestamp": ...}`。
        """
        decoded = self._request("GET", "/Graph/GetTimestamp", timestamp_graph_name=graph_name, params={"graphName": graph_name})
        return self._data_with_request_status(decoded)
