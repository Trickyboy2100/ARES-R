from __future__ import annotations

from typing import Any
from ..core.point_cloud import ParsedPointCloud
from ..models import (
    ChangeNodeIOParams,
    CopyNodeParams,
    CreateDynamicNodeParams,
    CreateGraphNodeParams,
    CreateNodeParams,
    EditNodeCommentParams,
    GenerateGraphNodeByNodesParams,
    NodeBindingUpdate,
    NodeConnectionParams,
    NodeParamUpdate,
    NodeRef,
    PortRef,
)
from .base import BaseService



class NodeService(BaseService):
    """主图节点服务。

    这一组接口用于操作主图中的节点，包括创建、复制、连线、设参、设绑定、
    单节点激活和节点详情查询。
    """

    def create_node(self, params: CreateNodeParams) -> dict[str, Any]:
        """在主图中创建节点。

        Args:
            params: :class:`CreateNodeParams`。包含 ``graph_name`` 和 ``node_name``。

        Returns:
            `dict[str, Any]`：通常包含 `status`、`nodeId`、`currentIndex`、`timestamp`。
        """
        payload = self._timestamp_payload(params.graph_name, nodeName=params.node_name)
        decoded = self._request("POST", "/Node/CreateNode", timestamp_graph_name=params.graph_name, json=payload)
        return self._data_with_request_status(decoded)

    def create_dynamic_io_node(self, params: CreateDynamicNodeParams) -> dict[str, Any]:
        """在主图中创建带动态输入输出定义的节点。

        Args:
            params: :class:`CreateDynamicNodeParams`。包含图名、节点名和 `node_data`。

        Returns:
            `dict[str, Any]`：通常包含 `nodeId`、`currentIndex`、`timestamp`。
        """
        payload = self._timestamp_payload(params.graph_name, nodeName=params.node_name, nodeData=params.node_data)
        decoded = self._request("POST", "/Node/CreateDynamicIONode", timestamp_graph_name=params.graph_name, json=payload)
        return self._data_with_request_status(decoded)

    def create_node_by_copy(self, params: CopyNodeParams) -> dict[str, Any]:
        """复制当前图中的一个节点。

        Args:
            params: :class:`CopyNodeParams`。包含 ``graph_name``、``node_name``
                （新节点名）和 ``node_id``（被复制节点 ID）。

        Returns:
            `dict[str, Any]`：通常包含新节点的 `nodeId`、`currentIndex`、`timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/CreateNodeByCopy",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, nodeName=params.node_name, nodeId=params.node_id),
        )
        return self._data_with_request_status(decoded)

    def change_node_io(self, params: ChangeNodeIOParams) -> dict[str, Any]:
        """修改主图中某个动态节点的输入输出定义。

        Args:
            params: :class:`ChangeNodeIOParams`。包含图名、节点 ID 和新的 `node_data`。

        Returns:
            `dict[str, Any]`：通常包含 `nodeId`、`currentIndex`、`timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/ChangeNodeIO",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, nodeId=params.node_id, nodeData=params.node_data),
        )
        return self._data_with_request_status(decoded)

    def create_graph_node(self, params: CreateGraphNodeParams) -> dict[str, Any]:
        """基于现有子图创建一个 graph node。

        Args:
            params: :class:`CreateGraphNodeParams`。包含父图名、新 graph node 名称和子图名。

        Returns:
            `dict[str, Any]`：通常包含 `nodeId`、`currentIndex`、`timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/CreateGraphNode",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name,
                nodeName=params.node_name,
                subGraphName=params.sub_graph_name,
            ),
        )
        return self._data_with_request_status(decoded)

    def generate_graph_node_by_nodes(self, params: GenerateGraphNodeByNodesParams) -> dict[str, Any]:
        """把主图中的多个节点打包生成一个新的 graph node。

        Args:
            params: :class:`GenerateGraphNodeByNodesParams`。包含父图名、新 graph node 名称和节点 ID 列表。

        Returns:
            `dict[str, Any]`：通常包含 `nodeId`、`currentIndex`、`timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/GenerateGraphNodeByNodes",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name,
                nodeIds=params.node_ids,
                graphNodeName=params.graph_node_name,
            ),
        )
        return self._data_with_request_status(decoded)

    def delete_node(self, params: NodeRef) -> dict[str, Any]:
        """删除主图中的节点。

        Args:
            params: :class:`NodeRef`。包含 ``graph_name`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/DeleteNode",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, nodeId=params.node_id),
        )
        return self._data_with_request_status(decoded)

    def connect_nodes(self, params: NodeConnectionParams) -> dict[str, Any]:
        """连接两个主图节点。

        Args:
            params: :class:`NodeConnectionParams`。包含 ``graph_name``、``output``
                （源节点端点）和 ``input``（目标节点端点）。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        payload = self._timestamp_payload(
            params.graph_name,
            inputs={"nodeId": params.input_node_id, "portName": params.input_port_name},
            outputs={"nodeId": params.output_node_id, "portName": params.output_port_name},
        )
        decoded = self._request("POST", "/Node/ConnectNodes", timestamp_graph_name=params.graph_name, json=payload)
        return self._data_with_request_status(decoded)

    def disconnect_nodes(self, params: NodeConnectionParams) -> dict[str, Any]:
        """断开两个主图节点之间的连接。

        Args:
            params: :class:`NodeConnectionParams`。包含 ``graph_name``、``output``
                （源节点端点）和 ``input``（目标节点端点）。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        payload = self._timestamp_payload(
            params.graph_name,
            inputs={"nodeId": params.input_node_id, "portName": params.input_port_name},
            outputs={"nodeId": params.output_node_id, "portName": params.output_port_name},
        )
        decoded = self._request("POST", "/Node/DisconnectNodes", timestamp_graph_name=params.graph_name, json=payload)
        return self._data_with_request_status(decoded)

    def get_node_params(self, params: NodeRef) -> dict[str, Any]:
        """获取节点参数快照。

        Args:
            params: :class:`NodeRef`。包含 ``graph_name`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：节点参数数据，通常包含 `init_params` 和 `run_params`。
        """
        decoded = self._request(
            "POST", "/Node/GetNodeParams", timestamp_graph_name=params.graph_name,
            json={"graphName": params.graph_name, "nodeId": params.node_id}
        )
        data = decoded.data or {}
        return data.get("data", data)

    def get_node_info_in_graph(self, params: NodeRef) -> dict[str, Any]:
        """获取图中某个节点的完整信息。

        Args:
            params: :class:`NodeRef`。包含 ``graph_name`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：节点完整信息，通常包含 `paramsData`、`nodeInfo`、
            `strategy`、`timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/GetNodeInfoInGraph",
            timestamp_graph_name=params.graph_name,
            json={"graphName": params.graph_name, "nodeId": params.node_id},
        )
        return self._data_with_request_status(decoded)

    def get_node_port_data(self, params: PortRef) -> dict[str, Any]:
        """获取节点端口数据。

        Args:
            params: :class:`PortRef`。包含 ``graph_name``、``node_id``、
                ``port_name`` 和 ``io_type``。

        Returns:
            `dict[str, Any]`：端口展示数据。若服务端返回了附件，SDK 会自动把
            二进制附件合并到结果字典中。
        """
        decoded = self._request(
            "POST",
            "/Node/GetNodePortData",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "nodeId": params.node_id,
                "portName": params.port_name,
                "IOtype": params.io_type,
            },
        )
        return self._merge_attachments(decoded)

    def get_points_data(self, params: PortRef) -> bytes:
        """获取端口的原始点云字节流。

        Args:
            params: :class:`PortRef`。包含 ``graph_name``、``node_id``、
                ``port_name`` 和 ``io_type``。

        Returns:
            `bytes`：服务端直接返回的原始字节，SDK 不做二次解码。
        """
        return self._request_raw(
            "POST",
            "/Node/GetPointsData",
            json={
                "graphName": params.graph_name,
                "nodeId": params.node_id,
                "portName": params.port_name,
                "IOtype": params.io_type,
            },
        )

    def get_points_data_parsed(self, params: PortRef) -> list[ParsedPointCloud]:
        """获取端口点云，并按服务端头信息解析成结构化结果。

        Args:
            params: :class:`PortRef`。包含 ``graph_name``、``node_id``、
                ``port_name`` 和 ``io_type``。

        服务端 `Node/GetPointsData` 的响应头里会附带每份点云的最后一维尺寸，
        SDK 会据此把原始 `float32` 数据还原成二维点表。
        """
        raw_payload = self.get_points_data(params)
        return self._decode_point_cloud_payload(raw_payload, has_dim_in_header=True)

    def download_data(self, params: PortRef) -> dict[str, Any]:
        """为节点端口数据生成可下载 URL。

        Args:
            params: :class:`PortRef`。包含图名、节点 ID、端口名和端口方向。

        Returns:
            `dict[str, Any]`：通常包含 `url`。
        """
        decoded = self._request(
            "POST",
            "/Node/DownloadData",
            timestamp_graph_name=params.graph_name,
            json={
                "graphName": params.graph_name,
                "nodeId": params.node_id,
                "portName": params.port_name,
                "IOtype": params.io_type,
            },
        )
        return self._data_with_request_status(decoded)

    def set_node_param_data(self, params: NodeParamUpdate) -> dict[str, Any]:
        """设置节点参数。

        Args:
            params: :class:`NodeParamUpdate`。包含 ``graph_name``、``node_id``、
                ``param_name``、``param_type`` 和 ``value``。若 ``value`` 为
                ``PathLike``，SDK 会自动按文件上传。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        payload: dict[str, Any] = {
            "graphName": params.graph_name,
            "nodeId": params.node_id,
            "portName": params.param_name,
            "IOtype": params.param_type,
        }
        timestamp = self.timestamps.get(params.graph_name)
        if timestamp is not None:
            payload["timestamp"] = timestamp
        decoded = self._request(
            "POST", "/Node/SetNodeParamData", timestamp_graph_name=params.graph_name,
            **self._build_param_request_kwargs(payload, params.value)
        )
        return self._data_with_request_status(decoded)

    def set_binding_name(self, params: NodeBindingUpdate) -> dict[str, Any]:
        """设置节点某个端口或参数的绑定名。

        Args:
            params: :class:`NodeBindingUpdate`。包含 ``graph_name``、``node_id``、
                ``binding_type``、``origin_name`` 和 ``binding_name``。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/SetBindingName",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(
                params.graph_name,
                nodeId=params.node_id,
                bindingType=params.binding_type,
                originName=params.origin_name,
                bindingName=params.binding_name,
            ),
        )
        return self._data_with_request_status(decoded)

    def edit_node_comment(self, params: EditNodeCommentParams) -> dict[str, Any]:
        """修改节点备注。

        Args:
            params: :class:`EditNodeCommentParams`。包含图名、节点 ID 和新备注。

        Returns:
            `dict[str, Any]`：通常仅包含更新后的 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/EditNodeComment",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, nodeId=params.node_id, comment=params.comment),
        )
        return self._data_with_request_status(decoded)

    def activate_node(self, params: NodeRef, *, timeout_seconds: float | None = 30) -> dict[str, Any]:
        """激活某个节点及其后续节点。

        Args:
            params: :class:`NodeRef`。包含 ``graph_name`` 和 ``node_id``。
            timeout_seconds: `float | None`。等待节点激活完成的最长秒数。
                传入 `None` 表示一直等待，直到完成或服务端返回错误。

        Returns:
            `dict[str, Any]`：激活状态信息，通常包含 `nodeActivated`、`finish`、
            `timestamp`。
        """
        decoded = self._request_until_finish(
            "POST",
            "/Node/ActivateNode",
            json=self._timestamp_payload(params.graph_name, nodeId=params.node_id),
            timeout_seconds=timeout_seconds,
            timestamp_graph_name=params.graph_name,
        )
        return self._data_with_request_status(decoded)

    def initial_node(self, params: NodeRef) -> dict[str, Any]:
        """初始化某个节点。

        Args:
            params: :class:`NodeRef`。包含 ``graph_name`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：通常包含 `success` 和 `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/InitialNode",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, nodeId=params.node_id),
        )
        return self._data_with_request_status(decoded)

    def update_node(self, params: NodeRef) -> dict[str, Any]:
        """更新单个节点。

        Args:
            params: :class:`NodeRef`。包含 ``graph_name`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：更新状态信息，通常包含 `nodeActivated`、`finish`、
            `timestamp`。
        """
        decoded = self._request(
            "POST",
            "/Node/UpdateNode",
            timestamp_graph_name=params.graph_name,
            json=self._timestamp_payload(params.graph_name, nodeId=params.node_id),
        )
        return self._data_with_request_status(decoded)
