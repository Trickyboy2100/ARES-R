from __future__ import annotations

import json
import os
import struct
from typing import Any

from ..core.codecs import decode_payload
from ..core.errors import AtomApiError, AtomProtocolError
from ..core.point_cloud import ParsedPointCloud
from ..core.single_node import get_node_info_single_node_types, parse_single_node_result
from ..models import (
    BindingRef,
    FileParamRef,
    NodeRef,
    PointCloudRef,
    RuntimePassiveBinoFrame,
    RuntimeRunParams,
    RuntimeBindingDataUpdate,
    RuntimeParamsUpdate,
    RuntimeStrategyParamsUpdate,
    SingleNodeParams,
)
from .base import BaseService


class RuntimeService(BaseService):
    """运行时调用服务。

    这组接口更适合外部程序把 Atom 当成执行引擎来用，而不是做图编辑。
    """

    def __init__(self, transport, timestamps):
        super().__init__(transport, timestamps)
        self._single_node_schema_cache: dict[str, dict[str, dict[str, Any]]] = {}

    def load_graph(self, graph_name: str) -> dict[str, Any]:
        """按运行时方式加载图。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：通常为 `{"GraphName": ...}`。
        """
        decoded = self._request("GET", "/Runtime/LoadGraph", params={"GraphName": graph_name})
        return self._data_with_request_status(decoded)

    def _build_runtime_frame_payload(self, params: RuntimeRunParams) -> bytes:
        """把运行时输入帧打包成服务端要求的 `octet-stream` 协议。"""
        if params.run_mode == "passive_bino":
            return self._build_passive_bino_payload(params.frames[0])

        metadata_frames = []
        binary_parts = []

        for frame in params.frames:
            epicraw_bytes = bytes(frame.epicraw)
            metadata_frame = {
                "cam2Base": frame.cam2_base,
                "roi": frame.roi,
            }
            metadata_frames.append(metadata_frame)
            binary_parts.append(epicraw_bytes)

        metadata_bytes = json.dumps(
            {"runMode": params.run_mode, "inputData": metadata_frames},
            ensure_ascii=False,
        ).encode("utf-8")
        header = struct.pack("<II", len(metadata_bytes), len(binary_parts))
        lengths = b"".join(struct.pack("<II", len(epicraw), 0) for epicraw in binary_parts)
        payload = header + lengths + metadata_bytes
        for epicraw_bytes in binary_parts:
            payload += epicraw_bytes
        return payload

    def _build_passive_bino_payload(self, frame: RuntimePassiveBinoFrame) -> bytes:
        """把一份 EPICRAW3 数据打包成服务端 passive_bino 运行协议。"""
        epicraw_bytes = bytes(frame.epicraw3)
        if not epicraw_bytes:
            raise ValueError("passive_bino frame is missing EPICRAW3 bytes")
        metadata_bytes = json.dumps(
            {
                "runMode": "passive_bino",
                "inputData": [{"cam2Base": frame.cam2_base, "roi": frame.roi}],
            },
            ensure_ascii=False,
        ).encode("utf-8")
        return (
            struct.pack("<II", len(metadata_bytes), 1)
            + struct.pack("<II", len(epicraw_bytes), 0)
            + metadata_bytes
            + epicraw_bytes
        )

    def list_graphs(self) -> Any:
        """获取运行时可见的图列表。

        Returns:
            `Any`：通常是 `list[dict[str, Any]]`，每项包含运行时可用图的摘要信息。
        """
        decoded = self._request("GET", "/Runtime/GetAllGraphsNoThumbnail")
        return decoded.data

    def get_all_nodes_info(self) -> dict[str, Any]:
        """获取运行时可见的节点信息。

        Returns:
            `dict[str, Any]`：运行时节点信息映射。
        """
        decoded = self._request("GET", "/Runtime/GetAllNodesInfo")
        return decoded.data

    def release_graph(self, graph_name: str) -> dict[str, Any]:
        """按运行时方式释放图。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：通常为 `{"GraphName": ...}`。
        """
        decoded = self._request("GET", "/Runtime/ReleaseGraph", params={"GraphName": graph_name})
        return self._data_with_request_status(decoded)

    def get_meta_info(self, graph_name: str) -> dict[str, Any]:
        """获取图绑定参数与运行时元信息。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：通常包含 `sharedParams` 和 `runtimeParams`。
        """
        decoded = self._request("GET", "/Runtime/GetMetaInfo", params={"GraphName": graph_name})
        return self._data_with_request_status(decoded)

    def get_binded_output_value(self, params: BindingRef) -> Any:
        """读取某个输出绑定当前值。

        Args:
            params: :class:`BindingRef`。包含 ``graph_name`` 和 ``binding_name``。

        Returns:
            `Any`：该绑定当前值，具体类型取决于端口数据类型。
        """
        decoded = self._request(
            "GET",
            "/Runtime/GetBindedOutputValue",
            params={"GraphName": params.graph_name, "BindingName": params.binding_name},
        )
        return decoded.data

    def get_binded_outputs_info(self, graph_name: str) -> dict[str, Any]:
        """读取图上所有输出绑定的描述信息。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `dict[str, Any]`：通常包含 `outputs` 列表。
        """
        decoded = self._request("GET", "/Runtime/GetBindedOutputsInfo", params={"GraphName": graph_name})
        return self._data_with_request_status(decoded)

    def get_binded_point_cloud(self, params: BindingRef) -> bytes:
        """读取某个输出绑定的原始点云字节流。

        Args:
            params: :class:`BindingRef`。包含 ``graph_name`` 和 ``binding_name``。

        Returns:
            `bytes`：服务端返回的原始点云字节流。
        """
        return self._request_raw(
            "GET",
            "/Runtime/GetBindedPointCloud",
            params={"GraphName": params.graph_name, "BindingName": params.binding_name},
        )

    def get_binded_point_cloud_parsed(self, params: PointCloudRef) -> list[ParsedPointCloud]:
        """读取某个输出绑定点云，并解析成结构化结果。

        Args:
            params: :class:`PointCloudRef`。包含 ``graph_name``、``binding_name``
                和可选的 ``point_dim``。

        注意：运行时接口的响应头里不包含每个点的维度，若希望结果直接还原成
        二维点表，建议在 ``params.point_dim`` 中显式传入，例如 ``3``。
        """
        raw_payload = self.get_binded_point_cloud(BindingRef(params.graph_name, params.binding_name))
        return self._decode_point_cloud_payload(raw_payload, has_dim_in_header=False, point_dim=params.point_dim)

    def set_shared_params(self, params: RuntimeParamsUpdate) -> Any:
        """设置图的共享参数。

        Args:
            params: :class:`RuntimeParamsUpdate`。包含 ``graph_name`` 和
                ``params_data``（以绑定名为 key 的共享参数字典）。

        Returns:
            `Any`：服务端当前通常返回 `None`。
        """
        decoded = self._request(
            "POST",
            "/Runtime/SetSharedParams",
            params={"GraphName": params.graph_name},
            json=params.params_data,
        )
        return self._data_with_request_status(decoded)

    def set_run_params(self, params: RuntimeParamsUpdate) -> Any:
        """设置图的运行参数。

        Args:
            params: :class:`RuntimeParamsUpdate`。包含 ``graph_name`` 和
                ``params_data``（以绑定名为 key 的运行参数字典）。

        Returns:
            `Any`：服务端当前通常返回 `None`。
        """
        decoded = self._request(
            "POST",
            "/Runtime/SetRunParams",
            params={"GraphName": params.graph_name},
            json=params.params_data,
        )
        return decoded.data

    def run_graph(self, params: RuntimeRunParams) -> dict[str, Any]:
        """按运行时协议执行图。

        Args:
            params: :class:`RuntimeRunParams`。包含 ``graph_name`` 和
                ``frames``（输入帧列表）。普通模式每帧包含 ``epicraw``、
                ``cam2_base`` 和可选 ``roi``；被动双目模式包含一份 EPICRAW3。

        Returns:
            `dict[str, Any]`：运行结果，通常包含 `instanceList`、`pickPointList`、
            `proStatus`、`detectResultList`。
        """
        payload = self._build_runtime_frame_payload(params)
        decoded = self._request(
            "POST",
            "/Runtime/RunGraph",
            params={"GraphName": params.graph_name},
            data=payload,
            headers={"content-type": "application/octet-stream"},
        )
        return self._data_with_request_status(decoded)

    def set_graph_binding_data(self, params: RuntimeBindingDataUpdate) -> Any:
        """直接按 binding 名设置图上的绑定数据。

        Args:
            params: :class:`RuntimeBindingDataUpdate`。包含 ``graph_name`` 和
                ``binding_data``（以绑定名为 key 的绑定数据字典）。

        Returns:
            `Any`：服务端当前通常返回空字典。
        """
        payload: dict[str, Any] = {"graphName": params.graph_name}
        payload.update(params.binding_data)
        decoded = self._request("POST", "/Runtime/SetGraphBindingData", json=payload)
        return self._data_with_request_status(decoded)

    def get_node_params_info_with_strategy(self, params: NodeRef) -> dict[str, Any]:
        """获取节点参数信息以及策略参数描述。

        当前仅支持以下策略节点：``PoseListFilter``、``PickPointFilter``、
        ``PoseListSorterInXOY``、``PickPointSorterInXOY``、
        ``PickPointSorterNew``、``PoseListSorter``。

        返回值里的 ``paramsData`` 通常作为 ``set_params_in_strategy`` 的输入模板：
        先复制或直接修改其中需要调整的字段，再把完整 ``paramsData`` 传回。

        Args:
            params: :class:`NodeRef`。包含 ``graph_name`` 和 ``node_id``。

        Returns:
            `dict[str, Any]`：通常包含 `paramsData`、`nodeInfo`、`strategy`。
        """
        decoded = self._request(
            "POST",
            "/Runtime/GetNodeParamsInfoWithStrategy",
            json={"graphName": params.graph_name, "nodeId": params.node_id},
        )
        return self._data_with_request_status(decoded)

    def set_params_in_strategy(self, params: RuntimeStrategyParamsUpdate) -> Any:
        """设置节点策略中的参数值。

        当前仅支持以下策略节点：``PoseListFilter``、``PickPointFilter``、
        ``PoseListSorterInXOY``、``PickPointSorterInXOY``、
        ``PickPointSorterNew``、``PoseListSorter``。

        ``params.params_data`` 一般来自
        ``get_node_params_info_with_strategy(...)[\"paramsData\"]``，调用方只修改其中
        需要更新的字段，然后把完整结构传入本接口。

        Args:
            params: :class:`RuntimeStrategyParamsUpdate`。包含 ``graph_name``、``node_id``
                和 ``params_data``。

        Returns:
            `Any`：服务端通常返回成功提示字符串。
        """
        decoded = self._request(
            "POST",
            "/Runtime/SetParamsInStrategy",
            json={"graphName": params.graph_name, "nodeId": params.node_id, "paramsData": params.params_data},
        )
        return self._data_with_request_status(decoded)

    def get_file_param_md5(self, params: FileParamRef) -> dict[str, Any]:
        """获取文件型绑定参数当前引用文件的 md5，这个节点主要是用于判断节点的文件数据是否有更新，如果更新再设置参数和初始化，以避免多余时间消耗。

        Args:
            params: :class:`FileParamRef`。包含 ``graph_name``、``param_name``
                和 ``param_type``（默认 ``"init_params"``）。

        Returns:
            `dict[str, Any]`：通常为 `{"md5": ...}`。
        """
        decoded = self._request(
            "GET",
            "/Runtime/getFileParamMd5",
            params={
                "graphName": params.graph_name,
                "paramName": params.param_name,
                "paramType": params.param_type,
            },
        )
        return self._data_with_request_status(decoded)

    def run_single_node_no_graph(self, params: SingleNodeParams) -> Any:
        """不创建图，直接按运行时方式执行单个节点。

        Args:
            params: :class:`SingleNodeParams`。包含 ``node_name``、可选的
                ``inputs``、``run_params``、``init_params``。SDK 会在需要时按
                节点输入端口类型自动处理图片、点云和文件路径。

        Returns:
            `Any`：普通节点通常返回 `dict`，特殊点云类节点可能直接返回原始 `bytes`。
        """
        schema = self._resolve_single_node_schema(
            params,
            need_input_schema=self._needs_single_node_input_schema(params),
        )
        return self._run_single_node_no_graph_with_schema(params, schema)

    def _run_single_node_no_graph_with_schema(
        self,
        params: SingleNodeParams,
        schema: dict[str, dict[str, Any]],
    ) -> Any:
        response = self.transport.request(
            "POST",
            "/Runtime/RunSingleNodeNoGraph",
            **self._build_single_node_request_kwargs(
                params.node_name,
                inputs=params.inputs,
                run_params=params.run_params,
                init_params=params.init_params,
                input_data_types=schema["input_data_types"],
                input_point_dims=schema["input_point_dims"],
            ),
        )
        try:
            decoded = decode_payload(response)
        except AtomApiError as exc:
            self._raise_single_node_api_error(params, schema, exc)
        except AtomProtocolError:
            return response.content
        result = self._data_with_request_status(decoded)
        self._raise_for_single_node_status_queue(params, schema, result)
        return result

    def run_single_node_no_graph_parsed(
        self,
        params: SingleNodeParams,
        *,
        output_data_types: dict[str, str] | None = None,
        point_dims: dict[str, int] | None = None,
    ) -> Any:
        """不创建图运行单节点，并自动解析 ``outputs`` 里的点云和图像值。

        返回结构与 :meth:`run_single_node_no_graph` 对齐，尤其是
        ``result["outputs"]`` 的 key 不会变化；SDK 只会把对应 value 从传输格式
        解析成结构化对象。
        """
        schema = self._resolve_single_node_schema(
            params,
            need_input_schema=self._needs_single_node_input_schema(params),
            need_output_schema=output_data_types is None,
        )
        result = self._run_single_node_no_graph_with_schema(params, schema)
        return parse_single_node_result(
            result,
            output_data_types or schema["output_data_types"],
            point_dims=point_dims or schema["output_point_dims"],
        )

    def _resolve_single_node_schema(
        self,
        params: SingleNodeParams,
        *,
        need_input_schema: bool = False,
        need_output_schema: bool = False,
    ) -> dict[str, dict[str, Any]]:
        input_data_types = dict(params.input_data_types or {})
        output_data_types = dict(params.output_data_types or {})
        input_point_dims = dict(params.input_point_dims or {})
        output_point_dims = dict(params.output_point_dims or {})

        if need_input_schema or (need_output_schema and not output_data_types):
            inferred = self._get_single_node_schema(params.node_name)
            input_data_types = {**inferred["input_data_types"], **input_data_types}
            output_data_types = {**inferred["output_data_types"], **output_data_types}
            input_point_dims = {**inferred["input_point_dims"], **input_point_dims}
            output_point_dims = {**inferred["output_point_dims"], **output_point_dims}

        return {
            "input_data_types": input_data_types,
            "output_data_types": output_data_types,
            "input_point_dims": input_point_dims,
            "output_point_dims": output_point_dims,
        }

    def _raise_single_node_api_error(
        self,
        params: SingleNodeParams,
        schema: dict[str, dict[str, Any]],
        exc: AtomApiError,
    ) -> None:
        context = [
            f"Runtime/RunSingleNodeNoGraph failed for node {params.node_name!r}",
            f"server_error={exc}",
        ]
        input_data_types = schema.get("input_data_types") or {}
        output_data_types = schema.get("output_data_types") or {}
        if input_data_types:
            context.append(f"input_data_types={self._format_single_node_dtype_map(input_data_types)}")
        if output_data_types:
            context.append(f"output_data_types={self._format_single_node_dtype_map(output_data_types)}")
        if params.inputs:
            context.append(f"input_keys={list(params.inputs)}")
        raise AtomApiError("; ".join(context), status=exc.status, payload=exc.payload) from exc

    def _raise_for_single_node_status_queue(
        self,
        params: SingleNodeParams,
        schema: dict[str, dict[str, Any]],
        result: Any,
    ) -> None:
        if not isinstance(result, dict):
            return
        error_detail = self._extract_single_node_status_queue_error(result.get("status_queue"))
        if not error_detail:
            return

        context = [
            f"Runtime/RunSingleNodeNoGraph failed for node {params.node_name!r}",
            f"status_queue_error={error_detail}",
        ]
        input_data_types = schema.get("input_data_types") or {}
        output_data_types = schema.get("output_data_types") or {}
        if input_data_types:
            context.append(f"input_data_types={self._format_single_node_dtype_map(input_data_types)}")
        if output_data_types:
            context.append(f"output_data_types={self._format_single_node_dtype_map(output_data_types)}")
        if params.inputs:
            context.append(f"input_keys={list(params.inputs)}")
        raise AtomApiError("; ".join(context), status=result.get("status"), payload=result)

    @classmethod
    def _extract_single_node_status_queue_error(cls, status_queue: Any) -> str | None:
        if isinstance(status_queue, dict):
            return cls._extract_status_dict_error(status_queue)
        if isinstance(status_queue, (list, tuple)):
            for item in status_queue:
                if isinstance(item, dict):
                    error = cls._extract_status_dict_error(item)
                    if error:
                        return error
            for item in status_queue:
                if isinstance(item, str) and cls._looks_like_error_key(item):
                    return item
            for item in status_queue:
                if isinstance(item, (int, float)) and not isinstance(item, bool) and item < 0:
                    return repr(status_queue)
        return None

    @classmethod
    def _extract_status_dict_error(cls, status_info: dict[str, Any]) -> str | None:
        if status_info.get("success") is False:
            message = status_info.get("errorMessage") or status_info.get("message") or status_info
            return str(message)
        for key, value in status_info.items():
            if cls._looks_like_error_key(str(key)):
                return f"{key}: {value}"
        return None

    @staticmethod
    def _looks_like_error_key(value: str) -> bool:
        lowered = value.lower()
        return "fail" in lowered or "error" in lowered

    @staticmethod
    def _format_single_node_dtype_map(data_types: dict[str, Any]) -> str:
        return "{" + ", ".join(f"{key}:{data_types[key]}" for key in sorted(data_types)) + "}"

    def _get_single_node_schema(self, node_name: str) -> dict[str, dict[str, Any]]:
        if node_name in self._single_node_schema_cache:
            return self._single_node_schema_cache[node_name]

        nodes_info = self.get_all_nodes_info()
        node_info = self._find_single_node_info(nodes_info, node_name)
        schema = get_node_info_single_node_types(node_info or {})
        self._single_node_schema_cache[node_name] = schema
        return schema

    def _find_single_node_info(self, nodes_info: Any, node_name: str) -> dict[str, Any] | None:
        if isinstance(nodes_info, dict):
            direct = nodes_info.get(node_name)
            if isinstance(direct, dict):
                return direct
            for value in nodes_info.values():
                if isinstance(value, dict) and value.get("nodeName") == node_name:
                    return value
        if isinstance(nodes_info, list):
            for value in nodes_info:
                if isinstance(value, dict) and value.get("nodeName") == node_name:
                    return value
        return None

    def _needs_single_node_input_schema(self, params: SingleNodeParams) -> bool:
        input_data_types = params.input_data_types or {}
        for input_name, input_value in (params.inputs or {}).items():
            if input_name in input_data_types:
                continue
            if isinstance(input_value, (os.PathLike, bytes, bytearray)):
                return True
            if isinstance(input_value, str) and os.path.exists(input_value):
                return True
        return False
