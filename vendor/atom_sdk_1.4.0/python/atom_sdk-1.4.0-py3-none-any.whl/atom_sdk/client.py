from __future__ import annotations

from .core.models import RequestOptions
from .core.state import TimestampStore
from .core.transport import BaseTransport, RequestsTransport
from .services import GraphNodeService, GraphService, NodeService, RuntimeService


class AtomClient:
    """Atom SDK 的统一入口。

    这个对象会聚合所有高层服务，适合业务代码直接使用。

    通常你只需要实例化一次 `AtomClient`，后续再通过它挂载的
    `graph`、`node`、`graph_node`、`runtime`
    进入不同能力域。

    Attributes:
        graph: `GraphService`。主图管理接口。
        graph_node: `GraphNodeService`。子图内部节点接口。
        node: `NodeService`。主图节点接口。
        runtime: `RuntimeService`。运行时执行接口。
    """

    def __init__(
        self,
        base_url: str,
        transport: BaseTransport | None = None,
        options: RequestOptions | None = None,
    ) -> None:
        """初始化 SDK 客户端。

        Args:
            base_url: `str`。`atom_vp_interface` 服务地址，例如
                `http://127.0.0.1:10026`。
            transport: `BaseTransport | None`。可选的自定义传输层，常用于测试
                或特殊网络控制。
            options: `RequestOptions | None`。默认请求配置，例如超时和公共请求头。

        Notes:
            如果没有显式传入 `transport`，SDK 会默认使用 `RequestsTransport`。
        """
        self.base_url = base_url.rstrip("/")
        self.timestamps = TimestampStore()
        self.transport = transport or RequestsTransport(self.base_url, options=options)
        self.graph = GraphService(self.transport, self.timestamps)
        self.graph_node = GraphNodeService(self.transport, self.timestamps)
        self.node = NodeService(self.transport, self.timestamps)
        self.runtime = RuntimeService(self.transport, self.timestamps)
