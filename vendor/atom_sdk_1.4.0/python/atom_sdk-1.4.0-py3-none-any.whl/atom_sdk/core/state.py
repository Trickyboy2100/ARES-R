from __future__ import annotations


class TimestampStore:
    """图级别 `timestamp` 本地缓存。

    主要用于图编辑相关接口，避免调用方手动管理服务端返回的时间戳。
    """

    def __init__(self):
        """初始化空的时间戳缓存。"""
        self._values: dict[str, float] = {}

    def get(self, graph_name: str):
        """读取某张图当前缓存的时间戳。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `float | None`：如果缓存存在则返回时间戳，否则返回 `None`。
        """
        return self._values.get(graph_name)

    def set(self, graph_name: str, timestamp):
        """写入某张图的时间戳。

        Args:
            graph_name: `str`。图名称。
            timestamp: `float`。新的时间戳值。

        Returns:
            `None`。
        """
        self._values[graph_name] = timestamp

    def clear(self, graph_name: str):
        """清除某张图的时间戳缓存。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `None`。
        """
        self._values.pop(graph_name, None)

    def require(self, graph_name: str):
        """强制读取某张图的时间戳。

        Args:
            graph_name: `str`。图名称。

        Returns:
            `float`：已缓存的时间戳。

        Raises:
            KeyError: 当本地还没有该图的时间戳缓存时抛出。
        """
        if graph_name not in self._values:
            raise KeyError(f"Graph timestamp not found: {graph_name}")
        return self._values[graph_name]
