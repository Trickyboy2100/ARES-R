from __future__ import annotations

import base64
import mimetypes
import os
from dataclasses import dataclass
from typing import Any

from .errors import AtomProtocolError
from .ply import load_ply_points
from .point_cloud import decode_point_cloud_payload, encode_point_cloud_payload


POINT_DATA_TYPES = {"Points", "XYZPoints", "NormalPoints", "RGBPoints"}
IMAGE_DATA_TYPES = {"Image", "MonoImage", "ColorImage", "BinaryImage"}


@dataclass
class ParsedImage:
    """Image bytes decoded from a RunSingleNodeNoGraph output value."""

    data: bytes
    format: str
    data_type: str


@dataclass
class PreparedSingleNodeInputs:
    """Request-ready single-node inputs split into JSON values and file fields."""

    values: dict[str, Any]
    files: dict[str, tuple[str, bytes]]


def parse_single_node_output(
    data_type: str,
    value: Any,
    *,
    point_dim: int | None = None,
    has_dim_in_header: bool = True,
) -> Any:
    """Parse one value encoded by the server-side convertResponse helper.

    Args:
        data_type: Atom output port data type.
        value: The value from ``result["outputs"][output_name]``.
        point_dim: Point dimension hint when the point-cloud header has no dimension.
        has_dim_in_header: Whether the encoded point-cloud payload includes dimensions.

    Returns:
        Parsed value for point-cloud and image outputs; other values are returned unchanged.
    """
    if data_type in POINT_DATA_TYPES:
        if value in (None, ""):
            return []
        payload = _decode_base64_value(value, label=f"{data_type} output")
        return decode_point_cloud_payload(
            payload,
            has_dim_in_header=has_dim_in_header,
            point_dim=point_dim,
        )
    if data_type in IMAGE_DATA_TYPES:
        if value in (None, ""):
            return []
        if not isinstance(value, list):
            raise AtomProtocolError(f"{data_type} output must be a list of base64 images")
        image_format = "png" if data_type == "BinaryImage" else "jpg"
        return [
            ParsedImage(
                data=_decode_base64_value(image_value, label=f"{data_type} image output"),
                format=image_format,
                data_type=data_type,
            )
            for image_value in value
        ]
    return value


def parse_single_node_outputs(
    outputs: dict[str, Any],
    output_data_types: dict[str, str] | None,
    *,
    point_dims: dict[str, int] | None = None,
) -> dict[str, Any]:
    """Parse a RunSingleNodeNoGraph ``outputs`` dict while keeping the same keys."""
    if output_data_types is None:
        return dict(outputs)
    point_dims = point_dims or {}
    return {
        output_name: parse_single_node_output(
            output_data_types.get(output_name, ""),
            output_value,
            point_dim=point_dims.get(output_name),
        )
        for output_name, output_value in outputs.items()
    }


def get_node_info_output_types(node_info):
    output_data_types = _extract_port_data_types(node_info.get("outputs", {}))
    return output_data_types, infer_point_dims(output_data_types)


def get_node_info_single_node_types(node_info):
    """Extract input/output dtype maps from a runtime node-info entry."""
    input_data_types = _extract_port_data_types(
        node_info.get("inputs", node_info.get("inputs_info", {}))
    )
    output_data_types = _extract_port_data_types(
        node_info.get("outputs", node_info.get("outputs_info", {}))
    )
    return {
        "input_data_types": input_data_types,
        "output_data_types": output_data_types,
        "input_point_dims": infer_point_dims(input_data_types),
        "output_point_dims": infer_point_dims(output_data_types),
    }


def infer_point_dims(data_types: dict[str, str]) -> dict[str, int]:
    """Infer point dimensions for dtypes with a stable channel count."""
    point_dims = {}
    for name, dtype in data_types.items():
        if dtype in {"XYZPoints", "Points"}:
            point_dims[name] = 3
        elif dtype in {"NormalPoints", "RGBPoints"}:
            point_dims[name] = 6
    return point_dims


def prepare_single_node_inputs(
    inputs: dict[str, Any] | None,
    input_data_types: dict[str, str] | None = None,
    *,
    point_dims: dict[str, int] | None = None,
) -> PreparedSingleNodeInputs:
    """Prepare single-node input values according to their Atom port dtypes."""
    values: dict[str, Any] = {}
    files: dict[str, tuple[str, bytes]] = {}
    input_data_types = input_data_types or {}
    point_dims = point_dims or {}

    for input_name, input_value in (inputs or {}).items():
        data_type = input_data_types.get(input_name, "")
        if data_type == "File":
            values[input_name] = _prepare_file_path_value(input_name, input_value)
        elif data_type in POINT_DATA_TYPES:
            files[input_name] = (
                input_name,
                _prepare_point_input(input_name, input_value, data_type, point_dims.get(input_name)),
            )
        elif data_type in IMAGE_DATA_TYPES:
            values[input_name] = _prepare_image_input(input_value, data_type)
        elif isinstance(input_value, os.PathLike):
            path = os.fspath(input_value)
            with open(path, "rb") as file_obj:
                files[input_name] = (os.path.basename(path), file_obj.read())
        elif isinstance(input_value, (bytes, bytearray)):
            files[input_name] = (input_name, bytes(input_value))
        else:
            values[input_name] = input_value

    return PreparedSingleNodeInputs(values=values, files=files)


def parse_single_node_result(
    result: Any,
    output_data_types: dict[str, str] | None = None,
    *,
    point_dims: dict[str, int] | None = None,
) -> Any:
    """Parse the ``outputs`` field of a RunSingleNodeNoGraph result."""
    if isinstance(result, (bytes, bytearray)):
        return _parse_raw_single_node_result(bytes(result), output_data_types, point_dims=point_dims)
    if not isinstance(result, dict) or not isinstance(result.get("outputs"), dict):
        return result
    parsed = dict(result)
    parsed["outputs"] = parse_single_node_outputs(
        result["outputs"],
        output_data_types,
        point_dims=point_dims,
    )
    return parsed


def _parse_raw_single_node_result(
    payload: bytes,
    output_data_types: dict[str, str] | None,
    *,
    point_dims: dict[str, int] | None = None,
) -> Any:
    if not output_data_types:
        return payload
    if len(output_data_types) != 1:
        raise AtomProtocolError("Raw RunSingleNodeNoGraph result requires exactly one output data type")

    point_dims = point_dims or {}
    output_name, data_type = next(iter(output_data_types.items()))
    parsed_value = parse_single_node_output(
        data_type,
        payload,
        point_dim=point_dims.get(output_name),
        has_dim_in_header=False,
    )
    return {"outputs": {output_name: parsed_value}}


def _decode_base64_value(value: Any, *, label: str) -> bytes:
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    if not isinstance(value, str):
        raise AtomProtocolError(f"{label} must be base64 text")
    base64_text = value.split(",", 1)[1] if value.startswith("data:") and "," in value else value
    try:
        return base64.b64decode(base64_text, validate=True)
    except Exception as exc:
        raise AtomProtocolError(f"{label} is not valid base64") from exc


def _extract_port_data_types(ports: Any) -> dict[str, str]:
    if not ports:
        return {}
    if isinstance(ports, dict):
        result = {}
        for port_name, port_info in ports.items():
            dtype = _extract_dtype(port_info)
            if dtype:
                result[str(port_name)] = dtype
        return result
    if isinstance(ports, list):
        result = {}
        for port_info in ports:
            if not isinstance(port_info, dict):
                continue
            port_name = (
                port_info.get("name")
                or port_info.get("portName")
                or port_info.get("port_name")
                or port_info.get("key")
            )
            dtype = _extract_dtype(port_info)
            if port_name and dtype:
                result[str(port_name)] = dtype
        return result
    return {}


def _extract_dtype(port_info: Any) -> str | None:
    if isinstance(port_info, str):
        return port_info
    if not isinstance(port_info, dict):
        return None
    dtype = port_info.get("dtype") or port_info.get("data_type") or port_info.get("dataType")
    return str(dtype) if dtype else None


def _prepare_file_path_value(input_name: str, value: Any) -> str:
    if isinstance(value, (bytes, bytearray)):
        try:
            return bytes(value).decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AtomProtocolError(
                f"File input {input_name!r} expects a file path string, not file content bytes"
            ) from exc
    if isinstance(value, os.PathLike):
        return os.fspath(value)
    if isinstance(value, str):
        return value
    raise AtomProtocolError(f"File input {input_name!r} expects a file path string")


def _prepare_point_input(input_name: str, value: Any, data_type: str, point_dim: int | None) -> bytes:
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)

    point_dim = point_dim or (6 if data_type in {"NormalPoints", "RGBPoints"} else 3)
    if isinstance(value, os.PathLike) or _is_existing_local_path(value):
        path = os.fspath(value)
        if path.lower().endswith(".ply"):
            return encode_point_cloud_payload(
                load_ply_points(path, properties=_point_properties_for_type(data_type)),
                point_dim=point_dim,
            )
        with open(path, "rb") as file_obj:
            return file_obj.read()

    if isinstance(value, str):
        raise AtomProtocolError(
            f"Point input {input_name!r} expects encoded bytes, a PLY path, or point values"
        )
    return encode_point_cloud_payload(value, point_dim=point_dim)


def _prepare_image_input(value: Any, data_type: str) -> list[str]:
    if value is None or (isinstance(value, str) and value == ""):
        return []
    if isinstance(value, list):
        return [_prepare_image_item(item, data_type) for item in value]
    return [_prepare_image_item(value, data_type)]


def _prepare_image_item(value: Any, data_type: str) -> str:
    if isinstance(value, os.PathLike) or _is_existing_local_path(value):
        path = os.fspath(value)
        with open(path, "rb") as file_obj:
            image_bytes = file_obj.read()
        mime_type = mimetypes.guess_type(path)[0] or _default_image_mime_type(data_type)
        return f"data:{mime_type};base64,{base64.b64encode(image_bytes).decode('ascii')}"
    if isinstance(value, (bytes, bytearray)):
        return (
            f"data:{_default_image_mime_type(data_type)};base64,"
            f"{base64.b64encode(bytes(value)).decode('ascii')}"
        )
    if isinstance(value, str):
        if value.startswith("data:"):
            return value
        return f"data:{_default_image_mime_type(data_type)};base64,{value}"
    raise AtomProtocolError(f"{data_type} input expects a path, bytes, or base64 text")


def _default_image_mime_type(data_type: str) -> str:
    return "image/png" if data_type == "BinaryImage" else "image/jpeg"


def _point_properties_for_type(data_type: str) -> tuple[str, ...]:
    if data_type == "NormalPoints":
        return ("x", "y", "z", "nx", "ny", "nz")
    if data_type == "RGBPoints":
        return ("x", "y", "z", "red", "green", "blue")
    return ("x", "y", "z")


def _is_existing_local_path(value: Any) -> bool:
    return isinstance(value, str) and os.path.exists(value)
