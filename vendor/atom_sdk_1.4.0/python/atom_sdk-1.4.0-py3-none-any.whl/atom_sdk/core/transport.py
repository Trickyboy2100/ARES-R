from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any
from urllib.parse import urljoin

import requests

from .errors import AtomHttpError
from .models import HttpResponse, RequestOptions


class BaseTransport(ABC):
    """传输层抽象基类。

    SDK 的所有服务最终都依赖这个接口发送请求。
    如果你需要替换默认的 `requests` 实现，或在测试中注入假对象，
    只需要实现这个基类即可。
    """

    @abstractmethod
    def request(self, method: str, path: str, **kwargs: Any) -> HttpResponse:
        """发送一次 HTTP 请求并返回统一的响应对象。

        Args:
            method: `str`。HTTP 方法，例如 `GET`、`POST`。
            path: `str`。相对路径，例如 `/Graph/OpenGraph`。
            **kwargs: `Any`。额外请求参数，会原样传给具体实现。

        Returns:
            `HttpResponse`：统一的响应对象。
        """
        raise NotImplementedError


class RequestsTransport(BaseTransport):
    """基于 `requests` 的默认传输实现。

    这是 `AtomClient` 默认使用的传输层。
    """

    def __init__(self, base_url: str, options: RequestOptions | None = None, session: requests.Session | None = None):
        """初始化默认传输层。

        Args:
            base_url: `str`。Atom 服务根地址。
            options: `RequestOptions | None`。默认请求选项，例如超时和公共请求头。
            session: `requests.Session | None`。可选会话对象，便于复用连接或自定义行为。
        """
        self.base_url = base_url.rstrip("/") + "/"
        self.options = options or RequestOptions()
        self.session = session or requests.Session()

    def request(self, method: str, path: str, **kwargs: Any) -> HttpResponse:
        """发送请求并统一包装 HTTP 响应。

        该方法会自动拼接 `base_url`、合并默认请求头，并在网络异常或
        4xx/5xx 状态码时抛出 `AtomHttpError`。

        Args:
            method: `str`。HTTP 方法。
            path: `str`。相对路径。
            **kwargs: `Any`。透传给 `requests.Session.request()` 的参数。

        Returns:
            `HttpResponse`：统一包装后的响应对象。
        """
        url = urljoin(self.base_url, path.lstrip("/"))
        headers = dict(self.options.headers)
        headers.update(kwargs.pop("headers", {}) or {})
        timeout = kwargs.pop("timeout", self.options.timeout)
        try:
            response = self.session.request(method=method, url=url, headers=headers, timeout=timeout, **kwargs)
        except requests.RequestException as exc:
            raise AtomHttpError(str(exc)) from exc

        if response.status_code >= 400:
            raise AtomHttpError(
                f"Atom service request failed: {response.status_code} {response.text}",
                status_code=response.status_code,
            )
        return HttpResponse(
            status_code=response.status_code,
            # HTTP 响应头名称不区分大小写。统一转成小写，避免从 requests 的
            # CaseInsensitiveDict 转为普通 dict 后丢失大小写不敏感的查询语义。
            headers={name.lower(): value for name, value in response.headers.items()},
            content=response.content,
        )
