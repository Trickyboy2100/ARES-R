from __future__ import annotations

from dataclasses import dataclass
import json
import struct
from typing import Any, Iterable


_PASSIVE_BINO_SOURCE_KEYS = ("DepthSrc1", "DepthSrc2", "TextureSrc")
_PASSIVE_BINO_CAMERA_FIELDS = (
    "CameraMatrix",
    "CameraDistortion",
    "CameraRotation",
    "CameraTranslation",
)


@dataclass(frozen=True)
class _ImagePayload:
    data: bytes
    width: int
    height: int
    mat_type: int


def make_epicraw(
    points: Any,
    image: Any,
    intrinsic: Any = None,
    distortion: Any = None,
    version: int | None = None,
    camera_params: dict[str, Any] | None = None,
) -> bytes:
    """Build an EPICRAW2 or EPICRAW3 standard depth and texture frame.

    When ``version`` is omitted, standard top-level camera parameters select
    EPICRAW2, while extended source parameters select EPICRAW3.
    """

    if camera_params is None:
        camera_params = {}
    elif not isinstance(camera_params, dict):
        raise ValueError("camera_params must be a dictionary")

    if camera_params:
        if intrinsic is None:
            intrinsic = camera_params.get("intrinsic")
        if distortion is None:
            distortion = camera_params.get("distortion")
        has_extended_params = any(
            camera_params.get(key) is not None
            for key in _PASSIVE_BINO_SOURCE_KEYS
        )
        if version is None:
            version = 3 if has_extended_params else 2
    if version is None:
        version = 2

    if version == 2:
        if intrinsic is None or distortion is None:
            raise ValueError("intrinsic and distortion are required for EPICRAW2")
        return _make_epicraw2(points, image, intrinsic, distortion)
    if version == 3:
        return _make_standard_epicraw3(
            points,
            image,
            intrinsic,
            distortion,
            camera_params,
        )
    raise ValueError(f"Unsupported EpicRaw version: {version}")


def _make_standard_epicraw3(
    points: Any,
    image: Any,
    intrinsic: Any,
    distortion: Any,
    camera_params: dict[str, Any],
) -> bytes:
    """Encode the standard EPICRAW3 depth and TextureBGR element layout."""

    np = _require_numpy()
    point_array = np.asarray(points)
    if (
        point_array.ndim != 3
        or point_array.shape[2] < 3
        or point_array.shape[0] <= 0
        or point_array.shape[1] <= 0
    ):
        raise ValueError(
            "EPICRAW3 points require a non-empty HxWx3 or more shape, "
            f"got shape {point_array.shape}"
        )

    depth_array = np.ascontiguousarray(point_array[:, :, 2], dtype=np.float32)
    height, width = depth_array.shape
    depth = _ImagePayload(depth_array.tobytes(), width, height, 5)
    texture = _normalize_image_element(image, "TextureBGR", texture=True)
    if (texture.height, texture.width) != (height, width):
        raise ValueError(
            "EPICRAW3 image shape and points shape must share height and width, "
            f"got image shape {(texture.height, texture.width)} and points shape {(height, width)}"
        )

    if intrinsic is not None and distortion is not None:
        depth_meta = _normalize_camera_metadata(
            intrinsic,
            distortion,
            matrix_name="intrinsic",
            distortion_name="distortion",
        )
    else:
        depth_source = camera_params.get("DepthSrc1")
        if not isinstance(depth_source, dict):
            raise ValueError(
                "EPICRAW3 DepthSrc1 CameraMatrix and CameraDistortion are required "
                "when top-level intrinsic and distortion are absent"
            )
        depth_meta = _normalize_camera_metadata(
            depth_source.get("CameraMatrix"),
            depth_source.get("CameraDistortion"),
            matrix_name="DepthSrc1 CameraMatrix",
            distortion_name="DepthSrc1 CameraDistortion",
            metadata=depth_source,
        )

    texture_source = camera_params.get("TextureSrc")
    if texture_source is None:
        texture_meta = depth_meta
    elif not isinstance(texture_source, dict):
        raise ValueError("EPICRAW3 TextureSrc metadata must be a dictionary")
    else:
        texture_meta = _normalize_camera_metadata(
            texture_source.get("CameraMatrix"),
            texture_source.get("CameraDistortion"),
            matrix_name="TextureSrc CameraMatrix",
            distortion_name="TextureSrc CameraDistortion",
            metadata=texture_source,
        )
    elements = [
        _make_epicraw3_element(3, depth, _metadata_to_bytes(depth_meta)),
        _make_epicraw3_element(2, texture, _metadata_to_bytes(texture_meta)),
    ]
    return _pack_epicraw3(elements)


def _normalize_camera_metadata(
    matrix: Any,
    distortion: Any,
    *,
    matrix_name: str,
    distortion_name: str,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate and normalize EPICRAW3 camera metadata to float64 lists."""

    np = _require_numpy()
    if matrix is None:
        raise ValueError(f"EPICRAW3 {matrix_name} is required")
    if distortion is None:
        raise ValueError(f"EPICRAW3 {distortion_name} is required")
    try:
        matrix_array = np.asarray(matrix, dtype=np.float64).reshape(-1)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"EPICRAW3 {matrix_name} must contain 9 numeric elements") from exc
    if matrix_array.size != 9:
        raise ValueError(
            f"EPICRAW3 {matrix_name} must contain exactly 9 elements, "
            f"got {matrix_array.size}"
        )
    try:
        distortion_array = np.asarray(distortion, dtype=np.float64).reshape(-1)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"EPICRAW3 {distortion_name} must contain numeric elements"
        ) from exc
    if distortion_array.size == 0:
        raise ValueError(f"EPICRAW3 {distortion_name} must not be empty")
    normalized = dict(metadata) if metadata is not None else {}
    normalized["CameraMatrix"] = matrix_array.tolist()
    normalized["CameraDistortion"] = distortion_array.tolist()
    return normalized


def _make_epicraw2(points: Any, image: Any, intrinsic: Any, distortion: Any) -> bytes:
    """Encode the legacy EPICRAW2 binary layout used by Atom runtimes."""

    np = _require_numpy()

    image_array = np.asarray(image)
    if image_array.ndim != 3 or image_array.shape[2] != 3:
        raise ValueError(
            f"EPICRAW2 image requires HxWx3 shape, got shape {image_array.shape}"
        )
    if image_array.shape[0] <= 0 or image_array.shape[1] <= 0:
        raise ValueError(
            f"EPICRAW2 image must have positive dimensions, got shape {image_array.shape}"
        )
    if image_array.dtype != np.uint8:
        raise ValueError(
            f"EPICRAW2 image dtype must be uint8, got dtype {image_array.dtype}"
        )

    point_array = np.asarray(points, dtype=np.float32)
    if point_array.ndim != 3 or point_array.shape[2] < 3:
        raise ValueError(
            f"EPICRAW2 points require HxWx3 or more channels, got shape {point_array.shape}"
        )
    if image_array.shape[:2] != point_array.shape[:2]:
        raise ValueError(
            "EPICRAW2 image shape and points shape must share height and width, "
            f"got image shape {image_array.shape} and points shape {point_array.shape}"
        )

    height, width = image_array.shape[:2]
    image_array = image_array.astype(np.int16) * 4

    matrix_data = np.asarray(intrinsic, dtype=np.float64).flatten().tobytes()
    distortion_data = np.asarray(distortion, dtype=np.float64).tobytes()
    depth_data = point_array[:, :, 2].copy().tobytes()
    image_data = image_array.tobytes()
    config_data = json.dumps(
        {
            "SmoothLevel": 0,
            "ProjectorBrightness": 0,
            "PatternMode": 4,
            "Gain2D": 1,
            "ExpTime2D": 100,
            "FlashLightOn": False,
            "ParamsBatch3D": [{"ExpTime3D": 20, "Gain3D": 1}],
        }
    ).encode("utf-8")

    header = struct.pack(
        "<8siiiiiiii",
        b"EPICRAW2",
        width,
        height,
        8,
        len(matrix_data),
        len(distortion_data),
        len(config_data),
        len(depth_data),
        len(image_data),
    )
    return header + matrix_data + distortion_data + config_data + depth_data + image_data


def _require_numpy() -> Any:
    try:
        import numpy
    except ModuleNotFoundError:
        raise ImportError("make_epicraw requires numpy") from None
    return numpy


def make_passive_bino_epicraw3(
    depth_src_img1: Any,
    depth_src_img2: Any,
    texture_bgr: Any,
    passive_bino_params: dict[str, Any],
) -> bytes:
    """Build a passive-bino EPICRAW3 container from three images.

    The generated file contains three EPICRAW3 elements:
    DepthSrcImg1, DepthSrcImg2, and TextureBGR. Metadata is stored on the
    corresponding element, matching the runtime server parser.
    """

    params = _validate_passive_bino_params(passive_bino_params)
    depth1 = _normalize_image_element(depth_src_img1, "DepthSrcImg1", texture=False)
    depth2 = _normalize_image_element(depth_src_img2, "DepthSrcImg2", texture=False)
    texture = _normalize_image_element(texture_bgr, "TextureBGR", texture=True)

    elements = [
        _make_epicraw3_element(0, depth1, _metadata_to_bytes(params["DepthSrc1"])),
        _make_epicraw3_element(1, depth2, _metadata_to_bytes(params["DepthSrc2"])),
        _make_epicraw3_element(2, texture, _metadata_to_bytes(params["TextureSrc"])),
    ]
    return _pack_epicraw3(elements)


def make_passive_bino_epicraw3_from_images(
    image_list: Iterable[Any],
    passive_bino_params: dict[str, Any],
) -> bytes:
    images = list(image_list)
    if len(images) != 3:
        raise ValueError("passive_bino from_images requires exactly three images")
    return make_passive_bino_epicraw3(images[0], images[1], images[2], passive_bino_params)


def _validate_passive_bino_params(passive_bino_params: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(passive_bino_params, dict):
        raise TypeError("passive_bino params must be a dict")

    missing = [key for key in _PASSIVE_BINO_SOURCE_KEYS if key not in passive_bino_params]
    if missing:
        raise ValueError(f"passive_bino params missing keys: {missing}")

    for source_key in _PASSIVE_BINO_SOURCE_KEYS:
        source_params = passive_bino_params[source_key]
        if not isinstance(source_params, dict):
            raise TypeError(f"{source_key} params must be a dict")
        source_missing = [key for key in _PASSIVE_BINO_CAMERA_FIELDS if key not in source_params]
        if source_missing:
            raise ValueError(f"{source_key} params missing keys: {source_missing}")

    return passive_bino_params


def _normalize_image_element(image: Any, element_name: str, *, texture: bool) -> _ImagePayload:
    numpy_payload = _try_normalize_numpy_image(image, element_name, texture=texture)
    if numpy_payload is not None:
        return numpy_payload
    return _normalize_sequence_image(image, element_name, texture=texture)


def _try_normalize_numpy_image(image: Any, element_name: str, *, texture: bool) -> _ImagePayload | None:
    try:
        import numpy as np
    except ImportError:
        return None

    if isinstance(image, (bytes, bytearray, memoryview)):
        return None

    array = np.asarray(image)
    if texture:
        if array.ndim == 2:
            array = np.repeat(array[:, :, None], 3, axis=2)
        elif array.ndim == 3 and array.shape[2] == 1:
            array = np.repeat(array, 3, axis=2)
        elif array.ndim == 3 and array.shape[2] > 3:
            array = array[:, :, :3]
        if array.ndim != 3 or array.shape[2] != 3:
            raise ValueError(f"EPICRAW3 {element_name} requires HxWx3 image, got shape {array.shape}")
    else:
        if array.ndim == 3 and array.shape[2] > 3:
            array = array[:, :, :3]
        if array.ndim != 2 and not (array.ndim == 3 and array.shape[2] in (1, 3)):
            raise ValueError(
                f"EPICRAW3 {element_name} requires HxW, HxWx1 or HxWx3 image, got shape {array.shape}"
            )

    if array.dtype not in (np.uint8, np.uint16):
        array = np.clip(array, 0, 255).astype(np.uint8)
    array = np.ascontiguousarray(array)
    channels = 1 if array.ndim == 2 else int(array.shape[2])
    return _ImagePayload(
        data=array.tobytes(),
        width=int(array.shape[1]),
        height=int(array.shape[0]),
        mat_type=_opencv_mat_type(str(array.dtype), channels),
    )


def _normalize_sequence_image(image: Any, element_name: str, *, texture: bool) -> _ImagePayload:
    if isinstance(image, (bytes, bytearray, memoryview)):
        raise TypeError(f"EPICRAW3 {element_name} requires image shape information, got raw bytes")

    rows = [list(row) for row in image]
    if not rows or not rows[0]:
        raise ValueError(f"EPICRAW3 {element_name} image must not be empty")

    width = len(rows[0])
    flattened: list[int] = []
    inferred_channels: int | None = None

    for row in rows:
        if len(row) != width:
            raise ValueError(f"EPICRAW3 {element_name} image rows must have equal width")
        for pixel in row:
            values = _pixel_values(pixel)
            if texture:
                if len(values) == 1:
                    values = values * 3
                elif len(values) > 3:
                    values = values[:3]
                if len(values) != 3:
                    raise ValueError(f"EPICRAW3 {element_name} requires 1 or 3 channels")
            else:
                if len(values) > 3:
                    values = values[:3]
                if len(values) not in (1, 3):
                    raise ValueError(f"EPICRAW3 {element_name} requires 1 or 3 channels")

            inferred_channels = inferred_channels or len(values)
            if len(values) != inferred_channels:
                raise ValueError(f"EPICRAW3 {element_name} image channels must be consistent")
            flattened.extend(values)

    channels = inferred_channels or 1
    dtype = "uint16" if any(value > 255 for value in flattened) else "uint8"
    data = _pack_numeric_values(flattened, dtype)
    return _ImagePayload(
        data=data,
        width=width,
        height=len(rows),
        mat_type=_opencv_mat_type(dtype, channels),
    )


def _pixel_values(pixel: Any) -> list[int]:
    if isinstance(pixel, (list, tuple)):
        return [int(value) for value in pixel]
    return [int(pixel)]


def _pack_numeric_values(values: list[int], dtype: str) -> bytes:
    if dtype == "uint16":
        return b"".join(struct.pack("<H", min(max(value, 0), 65535)) for value in values)
    return bytes(min(max(value, 0), 255) for value in values)


def _opencv_mat_type(dtype: str, channels: int) -> int:
    if dtype == "uint8":
        depth = 0
    elif dtype == "uint16":
        depth = 2
    elif dtype == "float32":
        depth = 5
    else:
        raise ValueError(f"Unsupported EPICRAW3 array dtype: {dtype}")
    return depth + ((channels - 1) << 3)


def _metadata_to_bytes(meta: Any) -> bytes:
    if meta is None:
        return b""
    if isinstance(meta, bytes):
        return meta
    if isinstance(meta, (bytearray, memoryview)):
        return bytes(meta)
    if isinstance(meta, str):
        return meta.encode("utf-8")
    return json.dumps(
        meta,
        ensure_ascii=False,
        separators=(",", ":"),
        default=_json_numpy_default,
    ).encode("utf-8")


def _json_numpy_default(value: Any) -> Any:
    """Convert NumPy arrays and scalar values to JSON-compatible Python data."""

    if hasattr(value, "tolist"):
        return value.tolist()
    if hasattr(value, "item"):
        return value.item()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def _make_epicraw3_element(data_type: int, image: _ImagePayload, meta: bytes) -> tuple[int, bytes]:
    header_length = 7 * 4 + len(meta)
    element = (
        struct.pack(
            "<7i",
            header_length,
            data_type,
            len(image.data),
            image.width,
            image.height,
            image.mat_type,
            len(meta),
        )
        + meta
        + image.data
    )
    return len(element), element


def _pack_epicraw3(elements: list[tuple[int, bytes]], header_meta: bytes = b"") -> bytes:
    element_lengths = [length for length, _ in elements]
    header_length = 8 + 4 + 4 + 4 * len(elements) + 4 + len(header_meta)
    header = (
        b"EPICRAW3"
        + struct.pack("<ii", header_length, len(elements))
        + struct.pack(f"<{len(element_lengths)}i", *element_lengths)
        + struct.pack("<i", len(header_meta))
        + header_meta
    )
    return header + b"".join(element for _, element in elements)
