from __future__ import annotations


from dataclasses import dataclass, field
from typing import Any


@dataclass
class HttpResponse:
    """SDK 内部统一使用的 HTTP 响应模型。

    Attributes:
        status_code: `int`。HTTP 状态码。
        headers: `dict[str, Any]`。响应头字典。
        content: `bytes`。原始响应字节内容。
    """

    status_code: int
    headers: dict[str, Any]
    content: bytes

    @property
    def text(self) -> str:
        """把原始字节按 UTF-8 尽量解码成字符串。

        Returns:
            `str`：尽量可读的文本内容。
        """
        return self.content.decode("utf-8", errors="replace")


@dataclass
class DecodedResponse:
    """协议解码后的统一结果模型。

    Attributes:
        status: `int`。服务端业务状态码。
        data: `Any`。已经解析出的主要业务数据。
        raw: `dict[str, Any]`。原始 JSON 头字典。
        attachments: `dict[str, bytes]`。命名二进制附件集合。
    """

    status: int
    data: Any
    raw: dict[str, Any]
    attachments: dict[str, bytes] = field(default_factory=dict)


@dataclass
class RequestOptions:
    """默认请求配置。

    Attributes:
        timeout: `float`。默认超时时间，单位为秒。
        headers: `dict[str, str]`。每次请求都会附带的公共请求头。
    """

    timeout: float = 30.0
    headers: dict[str, str] = field(default_factory=dict)
