from __future__ import annotations

import struct

_HEADER_TERMINATOR = b"end_header\n"

_TYPE_STRUCT_CODES = {
    "char": "b", "int8": "b",
    "uchar": "B", "uint8": "B",
    "short": "h", "int16": "h",
    "ushort": "H", "uint16": "H",
    "int": "i", "int32": "i",
    "uint": "I", "uint32": "I",
    "float": "f", "float32": "f",
    "double": "d", "float64": "d",
}


def load_ply_points(path, *, properties: tuple[str, ...] = ("x", "y", "z")) -> list[float]:
    """读取 PLY 文件里 ``vertex`` 元素的指定属性列，展平成一维浮点列表。

    自动识别文件头声明的 ``format``（``ascii``/``binary_little_endian``/
    ``binary_big_endian``），调用方不需要关心具体是哪种编码。返回的浮点列表
    可以直接传给 :func:`encode_point_cloud_payload`。

    Args:
        path: PLY 文件路径。
        properties: 要提取的顶点属性名，按给定顺序展平，默认取 ``x``/``y``/``z``。
            如果节点需要法向量或颜色，可以传比如
            ``("x", "y", "z", "nx", "ny", "nz")``。

    Returns:
        `list[float]`：按 ``顶点数 * len(properties)`` 展平的浮点列表。

    Raises:
        ValueError: 当文件不是合法 PLY、缺少 ``vertex`` 元素、缺少所需属性，
            或顶点数据被截断时抛出。
    """
    with open(path, "rb") as file_obj:
        raw = file_obj.read()

    header_end = raw.find(_HEADER_TERMINATOR)
    if header_end == -1:
        raise ValueError(f"PLY file is missing 'end_header': {path}")
    data_start = header_end + len(_HEADER_TERMINATOR)
    header_lines = raw[:header_end].decode("ascii", errors="strict").splitlines()

    if not header_lines or header_lines[0].strip() != "ply":
        raise ValueError(f"Not a valid PLY file (missing 'ply' magic): {path}")

    file_format = None
    vertex_count = None
    vertex_properties: list[tuple[str, str]] = []
    in_vertex_element = False
    for line in header_lines[1:]:
        line = line.strip()
        if not line or line.startswith("comment"):
            continue
        if line.startswith("format "):
            file_format = line.split()[1]
        elif line.startswith("element "):
            _, element_name, count = line.split()
            in_vertex_element = element_name == "vertex"
            if in_vertex_element:
                vertex_count = int(count)
        elif in_vertex_element and line.startswith("property "):
            parts = line.split()
            if parts[1] == "list":
                raise ValueError(f"List properties inside 'vertex' element are not supported: {path}")
            vertex_properties.append((parts[1], parts[2]))

    if file_format is None or vertex_count is None:
        raise ValueError(f"PLY header is missing 'format' or a 'vertex' element: {path}")

    prop_index = {name: index for index, (_, name) in enumerate(vertex_properties)}
    missing = [name for name in properties if name not in prop_index]
    if missing:
        raise ValueError(f"PLY file is missing properties {missing}: {path}")
    selected_indices = [prop_index[name] for name in properties]

    if file_format == "ascii":
        return _load_ascii_rows(raw[data_start:], vertex_count, selected_indices, path)
    if file_format in ("binary_little_endian", "binary_big_endian"):
        endian = "<" if file_format == "binary_little_endian" else ">"
        return _load_binary_rows(raw, data_start, vertex_count, vertex_properties, selected_indices, endian, path)
    raise ValueError(f"Unsupported PLY format {file_format!r}: {path}")


def _load_ascii_rows(data: bytes, vertex_count: int, selected_indices: list[int], path) -> list[float]:
    row_lines = data.decode("ascii", errors="strict").splitlines()
    values: list[float] = []
    for row_index in range(vertex_count):
        if row_index >= len(row_lines):
            raise ValueError(f"PLY vertex row {row_index + 1} is missing: {path}")
        parts = row_lines[row_index].split()
        values.extend(float(parts[index]) for index in selected_indices)
    return values


def _load_binary_rows(
    raw: bytes,
    data_start: int,
    vertex_count: int,
    vertex_properties: list[tuple[str, str]],
    selected_indices: list[int],
    endian: str,
    path,
) -> list[float]:
    struct_format = endian + "".join(_TYPE_STRUCT_CODES[type_name] for type_name, _ in vertex_properties)
    row_size = struct.calcsize(struct_format)
    values: list[float] = []
    offset = data_start
    for row_index in range(vertex_count):
        row_bytes = raw[offset:offset + row_size]
        if len(row_bytes) < row_size:
            raise ValueError(f"PLY vertex row {row_index + 1} is truncated: {path}")
        row_values = struct.unpack(struct_format, row_bytes)
        values.extend(float(row_values[index]) for index in selected_indices)
        offset += row_size
    return values
