from __future__ import annotations

import json

from .errors import AtomApiError, AtomProtocolError
from .models import DecodedResponse, HttpResponse


def _read_int64(payload: bytes, offset: int) -> tuple[int, int]:
    """从字节流中读取一个 little-endian int64。

    Args:
        payload: 原始字节流。
        offset: 当前读取偏移量。

    Returns:
        一个二元组，包含读取出的整数值和新的偏移量。
    """
    next_offset = offset + 8
    if next_offset > len(payload):
        raise AtomProtocolError("Binary payload is truncated while reading int64")
    return int.from_bytes(payload[offset:next_offset], "little", signed=True), next_offset


def _extract_result_map(raw: dict) -> tuple[int, object]:
    """从服务端响应字典中提取统一的 `status` 和业务数据。"""
    status = raw.get("status")
    if "message" in raw:
        data = raw.get("message")
    elif "data" in raw:
        data = raw.get("data")
    else:
        data = raw
    return status, data


def _raise_for_status(status: int, raw: dict):
    """检查服务端业务状态码，并在非成功时抛出异常。"""
    if status == 0:
        return
    message = raw.get("errorMessage") or raw.get("message") or raw.get("data") or "Atom API request failed"
    raise AtomApiError(str(message), status=status, payload=raw)


class AtomBinaryCodec:
    """Atom 自定义二进制响应解码器。

    该协议通常以一段 JSON 头开始，后面跟随若干命名的二进制附件，
    适合传输点云、图像或其他较大的端口数据。
    """

    @staticmethod
    def decode(response: HttpResponse) -> DecodedResponse:
        """解码 Atom 自定义二进制响应。

        Args:
            response: 统一包装后的 HTTP 响应。

        Returns:
            一个 `DecodedResponse`，其中 `data` 为 JSON 里的业务数据，
            `attachments` 为命名二进制块。
        """
        payload = response.content
        offset = 0
        json_length, offset = _read_int64(payload, offset)
        json_end = offset + json_length
        if json_end > len(payload):
            raise AtomProtocolError("Binary payload JSON segment is truncated")
        try:
            raw = json.loads(payload[offset:json_end].decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise AtomProtocolError("Binary payload JSON segment is invalid") from exc
        offset = json_end
        attachments: dict[str, bytes] = {}
        while offset < len(payload):
            name_length, offset = _read_int64(payload, offset)
            name_end = offset + name_length
            if name_end > len(payload):
                raise AtomProtocolError("Binary payload attachment name is truncated")
            try:
                name = payload[offset:name_end].decode("utf-8")
            except UnicodeDecodeError as exc:
                raise AtomProtocolError("Binary payload attachment name is invalid") from exc
            offset = name_end
            data_length, offset = _read_int64(payload, offset)
            data_end = offset + data_length
            if data_end > len(payload):
                raise AtomProtocolError("Binary payload attachment data is truncated")
            attachments[name] = payload[offset:data_end]
            offset = data_end
        status, data = _extract_result_map(raw)
        _raise_for_status(status, raw)
        return DecodedResponse(status=status, data=data, raw=raw, attachments=attachments)


def decode_json_response(response: HttpResponse) -> DecodedResponse:
    """解码普通 JSON 响应。"""
    try:
        raw = json.loads(response.content.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise AtomProtocolError("JSON payload is invalid") from exc
    status, data = _extract_result_map(raw)
    _raise_for_status(status, raw)
    return DecodedResponse(status=status, data=data, raw=raw, attachments={})


def decode_payload(response: HttpResponse) -> DecodedResponse:
    """根据 `content-type` 自动选择合适的解码方式。

    对 `application/octet-stream` 使用自定义二进制协议解码，
    其它内容类型默认按 JSON 处理。
    """
    content_type = (response.headers.get("content-type") or "").lower()
    if "application/octet-stream" in content_type:
        return AtomBinaryCodec.decode(response)
    return decode_json_response(response)
