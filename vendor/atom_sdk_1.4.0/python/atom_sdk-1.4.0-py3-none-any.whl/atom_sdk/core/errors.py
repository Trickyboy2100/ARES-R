from __future__ import annotations


class AtomSdkError(Exception):
    """Atom SDK 的基础异常类型。

    业务层代码如果只想捕获所有 SDK 相关错误，可以直接捕获这个基类。
    """


class AtomHttpError(AtomSdkError):
    """HTTP 请求层异常。

    这类异常通常表示网络错误、连接失败，或者服务端返回了 4xx/5xx 状态码。
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        """初始化 HTTP 异常。

        Args:
            message: 错误消息。
            status_code: 可选的 HTTP 状态码。
        """
        super().__init__(message)
        self.status_code = status_code


class AtomProtocolError(AtomSdkError):
    """协议解析异常。

    当响应内容不符合预期格式，例如 JSON 损坏或二进制结构被截断时抛出。
    """


class AtomTimeoutError(AtomSdkError):
    """轮询等待超时异常。

    当编辑态接口持续返回 ``finish=False``，并超过 SDK 允许等待的时间时抛出。
    """

    def __init__(
        self,
        message: str,
        *,
        path: str | None = None,
        timeout_seconds: float | None = None,
        attempts: int | None = None,
        last_data: object | None = None,
    ) -> None:
        """初始化轮询超时异常。

        Args:
            message: 错误消息。
            path: 超时的接口路径。
            timeout_seconds: 已等待的超时时间，单位为秒。
            attempts: 实际请求次数。
            last_data: 最后一次服务端返回的业务数据。
        """
        super().__init__(message)
        self.path = path
        self.timeout_seconds = timeout_seconds
        self.attempts = attempts
        self.last_data = last_data


class AtomApiError(AtomSdkError):
    """服务端业务异常。

    这类异常说明 HTTP 请求本身成功了，但 Atom 服务返回了非成功业务状态。
    """

    def __init__(self, message: str, status: int | None = None, payload: object | None = None) -> None:
        """初始化服务端业务异常。

        Args:
            message: 错误消息。
            status: 服务端返回的业务状态码。
            payload: 服务端原始响应数据，便于上层排查问题。
        """
        super().__init__(message)
        self.status = status
        self.payload = payload
