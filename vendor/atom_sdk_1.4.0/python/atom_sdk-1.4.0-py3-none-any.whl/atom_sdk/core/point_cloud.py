from __future__ import annotations

import sys
from array import array
from dataclasses import dataclass

from .errors import AtomProtocolError


@dataclass
class ParsedPointCloud:
    """一份已经按服务端头信息切分好的点云数据。

    Attributes:
        values: `array`。点云原始 `float32` 数据。
        shape: `tuple[int, ...]`。推荐使用的形状；若无法确定维度，则只返回一维长度。
    """

    values: array
    shape: tuple[int, ...]

    def tolist(self):
        """按 `shape` 把点云转换成 Python 列表。"""
        flat_values = self.values.tolist()
        if len(self.shape) != 2:
            return flat_values
        row_count, row_width = self.shape
        return [flat_values[index * row_width:(index + 1) * row_width] for index in range(row_count)]


def decode_point_cloud_payload(
    payload: bytes,
    *,
    has_dim_in_header: bool,
    point_dim: int | None = None,
) -> list[ParsedPointCloud]:
    """解析 Atom 服务端点云二进制流。

    Args:
        payload: `bytes`。服务端返回的原始二进制内容。
        has_dim_in_header: `bool`。头信息里是否自带每份点云最后一维的维度。
        point_dim: `int | None`。当头里不带维度时，调用方可手动指定每个点的维度。

    Returns:
        `list[ParsedPointCloud]`：按响应里每份点云拆分后的结果。
    """
    if payload == b"":
        return []
    if len(payload) % 4 != 0:
        raise AtomProtocolError("Point cloud payload byte length must be a multiple of 4")
    if point_dim is not None and point_dim <= 0:
        raise AtomProtocolError("point_dim must be a positive integer")

    float_values = array("f")
    float_values.frombytes(payload)
    if sys.byteorder != "little":
        float_values.byteswap()
    if not float_values:
        return []

    cloud_count = _float_to_int(float_values[0], "point cloud count")
    header_length = 1 + cloud_count + (cloud_count if has_dim_in_header else 0)
    if len(float_values) < header_length:
        raise AtomProtocolError("Point cloud payload header is truncated")

    sizes = [_float_to_int(value, "point cloud size") for value in float_values[1:1 + cloud_count]]
    dims = None
    if has_dim_in_header:
        dims = [_float_to_int(value, "point cloud dimension") for value in float_values[1 + cloud_count:header_length]]

    expected_total = header_length + sum(sizes)
    if len(float_values) != expected_total:
        raise AtomProtocolError(
            f"Point cloud payload length mismatch: expected {expected_total} float32 values, got {len(float_values)}"
        )

    clouds: list[ParsedPointCloud] = []
    offset = header_length
    for index, size in enumerate(sizes):
        end = offset + size
        cloud_values = array("f", float_values[offset:end])
        cloud_dim = dims[index] if dims is not None else point_dim
        clouds.append(ParsedPointCloud(values=cloud_values, shape=_build_shape(size, cloud_dim)))
        offset = end
    return clouds


def encode_point_cloud_payload(points, *, point_dim: int = 3) -> bytes:
    """把一份点云数据编码成 Atom 点云类型输入（``Points``/``XYZPoints``/
    ``NormalPoints``/``RGBPoints``）所需的原始二进制格式。

    服务端解析这类输入时，期望的二进制内容是一个自定义的 ``float32`` 结构：
    ``[点云个数, 该点云的浮点总数, 点云原始数据...]``；直接把逐点的 xyz（或
    xyz+normal/rgb）数据不加这层头信息传上去，会导致服务端解析失败并报出类似
    ``buffer size must be a multiple of element size`` 的错误。这个函数把头信息
    的拼接细节封装起来，调用方只需要提供点数据本身。

    Args:
        points: 点云数据，支持两种写法：
            - 逐点的行列表，例如 ``[(x0, y0, z0), (x1, y1, z1), ...]``；
            - 或已经展平的浮点序列，例如 ``[x0, y0, z0, x1, y1, z1, ...]``。
            两种写法效果等价，函数会自动展平。
        point_dim: 每个点的通道数。xyz 点云用默认值 ``3``；带法向量的
            ``NormalPoints`` 或带颜色的 ``RGBPoints`` 用 ``6``。

    Returns:
        `bytes`：可以直接作为 ``SingleNodeParams.inputs`` 等点云类型输入值使用
        的原始字节。

    Raises:
        AtomProtocolError: 当 ``point_dim`` 不是正整数，或展平后的浮点总数不能
            被 ``point_dim`` 整除时抛出。
    """
    if point_dim <= 0:
        raise AtomProtocolError(f"point_dim must be a positive integer, got {point_dim}")

    values = _flatten_point_values(points)
    if len(values) % point_dim != 0:
        raise AtomProtocolError(
            f"Point cloud value count {len(values)} is not divisible by point_dim {point_dim}"
        )

    header = array("f", [1.0, float(len(values))])
    body = array("f", values)
    if sys.byteorder != "little":
        header.byteswap()
        body.byteswap()
    return header.tobytes() + body.tobytes()


def _flatten_point_values(points) -> list[float]:
    values: list[float] = []
    for item in points:
        try:
            values.append(float(item))
        except TypeError:
            values.extend(float(component) for component in item)
    return values


def _float_to_int(value: float, label: str) -> int:
    integer = int(value)
    if integer != value:
        raise AtomProtocolError(f"Point cloud payload {label} must be an integer, got {value!r}")
    if integer < 0:
        raise AtomProtocolError(f"Point cloud payload {label} must be non-negative, got {integer}")
    return integer


def _build_shape(size: int, point_dim: int | None) -> tuple[int, ...]:
    if point_dim is None:
        return (size,)
    if size == 0:
        return (0, point_dim)
    if size % point_dim != 0:
        raise AtomProtocolError(
            f"Point cloud payload size {size} is not divisible by point_dim {point_dim}"
        )
    return (size // point_dim, point_dim)
