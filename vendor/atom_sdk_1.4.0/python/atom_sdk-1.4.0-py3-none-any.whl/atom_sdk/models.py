from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# 基础构建块
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# GraphService 参数结构体
# ---------------------------------------------------------------------------


@dataclass
class CreateGraphParams:
    """``graph.create_graph`` 参数。

    Attributes:
        graph_name: 新图名称。
        description: 图备注，可选。
    """

    graph_name: str
    description: str | None = None


@dataclass
class CopyGraphParams:
    """``graph.copy_graph`` 参数。

    Attributes:
        graph_name: 源图名称。
        new_graph_name: 复制后新图名称。
    """

    graph_name: str
    new_graph_name: str


@dataclass
class LoadGraphParams:
    """``graph.load_graph`` 参数（从本地文件导入图）。

    Attributes:
        graph_name: 导入后在 Atom 中使用的图名称。
        file_path: 本地 ``.atom`` 图文件路径。
    """

    graph_name: str
    file_path: str | Path


@dataclass
class ImportExtensionNodesByPathParams:
    """``graph.import_extension_nodes_by_path`` 参数。

    Attributes:
        extension_nodes: ``graph.load_graph`` 返回值里的 ``extensionNodes`` 字段。
            key 是解压后的扩展节点文件路径，value 包含 ``existedNodes``、
            ``newNodes`` 和 ``forceCover`` 等服务端导入所需信息。
    """

    extension_nodes: dict[str, Any]


@dataclass
class ExportGraphParams:
    """``graph.export_graph`` 参数。

    Attributes:
        graph_name: 要导出的图名称。
        dl_models_info: 导出时需要打包的模型信息，可选。
        custom_nodes: 导出时需要打包的自定义节点信息，可选。
    """

    graph_name: str
    dl_models_info: dict[str, Any] | None = None
    custom_nodes: dict[str, Any] | None = None


@dataclass
class EditGraphNameParams:
    """``graph.edit_graph_name`` 参数。

    Attributes:
        graph_name: 当前图名称。
        new_graph_name: 修改后的图名称。
    """

    graph_name: str
    new_graph_name: str


@dataclass
class EditGraphCommentParams:
    """``graph.edit_graph_comment`` 参数。

    Attributes:
        graph_name: 图名称。
        comment: 新的图备注。
    """

    graph_name: str
    comment: str


# ---------------------------------------------------------------------------
# NodeService + RuntimeService 共用结构体
# ---------------------------------------------------------------------------


@dataclass
class NodeRef:
    """主图中的节点引用（图名称 + 节点 ID）。

    在 ``NodeService`` 中用于 ``delete_node`` / ``get_node_params`` /
    ``get_node_info_in_graph`` / ``activate_node`` / ``initial_node`` /
    ``update_node``。

    在 ``RuntimeService`` 中用于 ``get_node_params_info_with_strategy``。

    Attributes:
        graph_name: 图名称。
        node_id: 节点 ID。
    """

    graph_name: str
    node_id: str


@dataclass
class SingleNodeParams:
    """不创建图、直接执行单个节点所需的全部参数。

    Attributes:
        node_name: 节点类名。
        inputs: 输入端口值；SDK 会结合端口类型自动编码常见图像、点云和文件路径。
        run_params: 运行参数。
        init_params: 初始化参数。
        input_data_types: 输入端口类型映射。未提供时，SDK 会在需要时按节点名查询。
        input_point_dims: 点云输入维度提示；通常可由输入类型自动推断。
        output_data_types: 输出端口类型映射。供 parsed 接口按输出名解析 value。
        output_point_dims: 点云输出维度提示。仅当点云响应头没有维度信息时需要。
    """

    node_name: str
    inputs: dict[str, Any] | None = None
    run_params: dict[str, Any] | None = None
    init_params: dict[str, Any] | None = None
    output_data_types: dict[str, str] | None = None
    output_point_dims: dict[str, int] | None = None
    input_data_types: dict[str, str] | None = None
    input_point_dims: dict[str, int] | None = None


# ---------------------------------------------------------------------------
# NodeService 参数结构体
# ---------------------------------------------------------------------------


@dataclass
class CreateNodeParams:
    """``node.create_node`` 参数。

    Attributes:
        graph_name: 主图名称。
        node_name: 节点类名或服务端可识别的节点名称。
    """

    graph_name: str
    node_name: str


@dataclass
class CreateDynamicNodeParams:
    """``node.create_dynamic_io_node`` 参数。

    Attributes:
        graph_name: 主图名称。
        node_name: 节点类名。
        node_data: 动态输入输出定义。
    """

    graph_name: str
    node_name: str
    node_data: Any


@dataclass
class CopyNodeParams:
    """``node.create_node_by_copy`` 参数。

    Attributes:
        graph_name: 主图名称。
        node_name: 复制后新节点名称。
        node_id: 被复制的目标节点 ID。
    """

    graph_name: str
    node_name: str
    node_id: str


@dataclass
class ChangeNodeIOParams:
    """``node.change_node_io`` 参数。

    Attributes:
        graph_name: 图名称。
        node_id: 要修改的节点 ID。
        node_data: 修改后的动态输入输出定义。
    """

    graph_name: str
    node_id: str
    node_data: Any


@dataclass
class CreateGraphNodeParams:
    """``node.create_graph_node`` 参数。

    Attributes:
        graph_name: 父图名称。
        node_name: 新 graph node 的显示名称或节点名称。
        sub_graph_name: 要包装成 graph node 的子图名称。
    """

    graph_name: str
    node_name: str
    sub_graph_name: str


@dataclass
class GenerateGraphNodeByNodesParams:
    """``node.generate_graph_node_by_nodes`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_name: 新 graph node 名称。
        node_ids: 要打包进 graph node 的节点 ID 列表。
    """

    graph_name: str
    graph_node_name: str
    node_ids: list[str]


@dataclass
class NodeConnectionParams:
    """``node.connect_nodes`` / ``node.disconnect_nodes`` 参数。

    Attributes:
        graph_name: 图名称。
        output_node_id: 源节点（输出侧）节点 ID。
        output_port_name: 源节点输出端口名。
        input_node_id: 目标节点（输入侧）节点 ID。
        input_port_name: 目标节点输入端口名。
    """

    graph_name: str
    output_node_id: str
    output_port_name: str
    input_node_id: str
    input_port_name: str


@dataclass
class PortRef:
    """主图节点端口引用，唯一标识某个节点的某个端口。

    用于 ``node.get_node_port_data`` / ``node.get_points_data`` /
    ``node.get_points_data_parsed``。

    Attributes:
        graph_name: 图名称。
        node_id: 节点 ID。
        port_name: 端口名。
        io_type: 端口方向，通常为 ``"inputs"`` 或 ``"outputs"``。
    """

    graph_name: str
    node_id: str
    port_name: str
    io_type: str


@dataclass
class NodeParamUpdate:
    """``node.set_node_param_data`` 参数。

    Attributes:
        graph_name: 图名称。
        node_id: 节点 ID。
        param_name: 参数名。
        param_type: 参数类型，通常为 ``"init_params"`` 或 ``"run_params"``。
        value: 参数值；若为 ``PathLike``，SDK 会自动按文件上传。
    """

    graph_name: str
    node_id: str
    param_name: str
    param_type: str
    value: Any


@dataclass
class NodeBindingUpdate:
    """``node.set_binding_name`` 参数。

    Attributes:
        graph_name: 图名称。
        node_id: 节点 ID。
        binding_type: 绑定类型，如 ``"inputs"``、``"outputs"``、
            ``"init_params"``、``"run_params"``。
        origin_name: 原始端口名或参数名。
        binding_name: 新的绑定名；传空字符串通常表示取消绑定。
    """

    graph_name: str
    node_id: str
    binding_type: str
    origin_name: str
    binding_name: str


@dataclass
class EditNodeCommentParams:
    """``node.edit_node_comment`` 参数。

    Attributes:
        graph_name: 图名称。
        node_id: 节点 ID。
        comment: 新备注内容。
    """

    graph_name: str
    node_id: str
    comment: str


# ---------------------------------------------------------------------------
# GraphNodeService 参数结构体
# ---------------------------------------------------------------------------


@dataclass
class SubGraphRef:
    """子图引用（父图名称 + 子图节点 ID）。

    用于 ``graph_node.open_graph`` / ``graph_node.run_graph``。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
    """

    graph_name: str
    graph_node_id: str


@dataclass
class SubGraphCreateNodeParams:
    """``graph_node.create_node`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_name: 要创建的节点类名。
    """

    graph_name: str
    graph_node_id: str
    node_name: str


@dataclass
class CreateDynamicSubGraphNodeParams:
    """``graph_node.create_dynamic_io_node`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_name: 要创建的节点类名。
        node_data: 动态输入输出定义。
    """

    graph_name: str
    graph_node_id: str
    node_name: str
    node_data: Any


@dataclass
class SubGraphCopyNodeParams:
    """``graph_node.create_node_by_copy`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_name: 复制后新节点名称。
        node_id: 被复制的目标节点 ID。
    """

    graph_name: str
    graph_node_id: str
    node_name: str
    node_id: str


@dataclass
class ChangeSubGraphNodeIOParams:
    """``graph_node.change_node_io`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_id: 子图内节点 ID。
        node_data: 修改后的动态输入输出定义。
    """

    graph_name: str
    graph_node_id: str
    node_id: str
    node_data: Any


@dataclass
class SubGraphNodeRef:
    """子图内的节点引用。

    用于 ``graph_node.delete_node`` / ``graph_node.get_node_params`` /
    ``graph_node.get_node_info_in_graph`` / ``graph_node.activate_node`` /
    ``graph_node.initial_node`` / ``graph_node.update_node``。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_id: 子图内节点 ID。
    """

    graph_name: str
    graph_node_id: str
    node_id: str


@dataclass
class SubGraphConnectionParams:
    """``graph_node.connect_nodes`` / ``graph_node.disconnect_nodes`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        output_node_id: 源节点（输出侧）节点 ID。
        output_port_name: 源节点输出端口名。
        input_node_id: 目标节点（输入侧）节点 ID。
        input_port_name: 目标节点输入端口名。
    """

    graph_name: str
    graph_node_id: str
    output_node_id: str
    output_port_name: str
    input_node_id: str
    input_port_name: str


@dataclass
class SubGraphPortRef:
    """子图内节点端口引用。

    用于 ``graph_node.get_node_port_data`` / ``graph_node.get_points_data`` /
    ``graph_node.get_points_data_parsed``。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_id: 子图内节点 ID。
        port_name: 端口名。
        io_type: 端口方向，通常为 ``"inputs"`` 或 ``"outputs"``。
    """

    graph_name: str
    graph_node_id: str
    node_id: str
    port_name: str
    io_type: str


@dataclass
class SubGraphNodeParamUpdate:
    """``graph_node.set_node_param_data`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_id: 子图内节点 ID。
        param_name: 参数名。
        param_type: 参数类型，通常为 ``"init_params"`` 或 ``"run_params"``。
        value: 参数值；若为 ``PathLike``，SDK 会自动按文件上传。
    """

    graph_name: str
    graph_node_id: str
    node_id: str
    param_name: str
    param_type: str
    value: Any


@dataclass
class SubGraphBindingUpdate:
    """``graph_node.set_binding_name`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_id: 子图内节点 ID。
        binding_type: 绑定类型。
        origin_name: 原始端口名或参数名。
        binding_name: 新的绑定名；传空字符串通常表示取消绑定。
    """

    graph_name: str
    graph_node_id: str
    node_id: str
    binding_type: str
    origin_name: str
    binding_name: str


@dataclass
class EditSubGraphNameParams:
    """``graph_node.edit_graph_name`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        new_sub_graph_name: 修改后的子图名称。
    """

    graph_name: str
    graph_node_id: str
    new_sub_graph_name: str


@dataclass
class ExportSubGraphParams:
    """``graph_node.export_graph`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        dl_models_info: 导出时需要打包的模型信息，可选。
        custom_nodes: 导出时需要打包的自定义节点信息，可选。
    """

    graph_name: str
    graph_node_id: str
    dl_models_info: dict[str, Any] | None = None
    custom_nodes: dict[str, Any] | None = None


@dataclass
class SetSubgraphAsCustomSubgraphParams:
    """``graph_node.set_subgraph_as_custom_subgraph`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        custom_subgraph_name: 导出后的自定义子图名称。
    """

    graph_name: str
    graph_node_id: str
    custom_subgraph_name: str


@dataclass
class EditSubGraphNodeCommentParams:
    """``graph_node.edit_node_comment`` 参数。

    Attributes:
        graph_name: 父图名称。
        graph_node_id: 子图节点 ID。
        node_id: 子图内节点 ID。
        comment: 新备注内容。
    """

    graph_name: str
    graph_node_id: str
    node_id: str
    comment: str


# ---------------------------------------------------------------------------
# RuntimeService 参数结构体
# ---------------------------------------------------------------------------


@dataclass
class BindingRef:
    """运行时输出绑定引用。

    用于 ``runtime.get_binded_output_value`` / ``runtime.get_binded_point_cloud``。

    Attributes:
        graph_name: 图名称。
        binding_name: 输出绑定名。
    """

    graph_name: str
    binding_name: str


@dataclass
class PointCloudRef:
    """运行时点云输出绑定引用（含可选维度提示）。

    用于 ``runtime.get_binded_point_cloud_parsed``。

    Attributes:
        graph_name: 图名称。
        binding_name: 输出绑定名。
        point_dim: 每个点的维度，如 ``3``；不传则由 SDK 从响应推断。
    """

    graph_name: str
    binding_name: str
    point_dim: int | None = None


@dataclass
class RuntimeParamsUpdate:
    """运行时共享参数或运行参数更新。

    用于 ``runtime.set_shared_params`` / ``runtime.set_run_params``。

    Attributes:
        graph_name: 图名称。
        params_data: 以绑定名为 key 的参数字典。
    """

    graph_name: str
    params_data: dict[str, Any]


@dataclass
class RuntimeFrame:
    """普通运行模式的单帧输入，封装一份 EPICRAW 原始数据。

    用于 ``RuntimeRunParams.frames`` 列表。

    Attributes:
        epicraw: 完整 EPICRAW 原始字节（或可被 ``bytes()`` 转换的对象）。
        cam2_base: 相机到基坐标系的变换矩阵，服务端目前只支持旋转矢量形式：
            长度为 6 的 ``[x, y, z, rx, ry, rz]``（平移 + Rodrigues 旋转向量），
            不支持 4x4/3x4 矩阵形式。
        roi: 感兴趣区域，可选。推荐格式：
            ``{"min": {"x": ..., "y": ..., "z": ...}, "max": {...}, "cam2ROIFrame": [x, y, z, rx, ry, rz]}``。
            ``cam2ROIFrame`` 同样只支持长度为 6 的旋转矢量形式。
    """

    epicraw: Any
    cam2_base: Any
    roi: Any = None

    def __post_init__(self):
        self.epicraw = bytes(self.epicraw)
        if not self.epicraw:
            raise ValueError("runtime frame is missing EPICRAW bytes")
        self.cam2_base = _require_cam2_base(self.cam2_base)
        self.roi = _validate_roi(self.roi)

    @classmethod
    def from_bytes(cls, epicraw: Any, cam2_base: Any, roi: Any = None):
        """使用已有 EPICRAW bytes 构造普通模式输入帧。"""
        return cls(epicraw=epicraw, cam2_base=cam2_base, roi=roi)

    @classmethod
    def from_data(
        cls,
        points: Any,
        image: Any,
        cam2_base: Any,
        intrinsic: Any = None,
        distortion: Any = None,
        version: int | None = None,
        camera_params: dict[str, Any] | None = None,
        roi: Any = None,
    ):
        """把点云和图像编码为 EPICRAW，并构造普通模式输入帧。"""
        from .core.epicraw import make_epicraw

        epicraw = make_epicraw(
            points,
            image,
            intrinsic=intrinsic,
            distortion=distortion,
            version=version,
            camera_params=camera_params,
        )
        return cls.from_bytes(epicraw, cam2_base=cam2_base, roi=roi)

    @classmethod
    def from_file(cls, epicraw_path: str | Path, cam2_base: Any, roi: Any = None):
        """读取 EPICRAW 文件并构造普通模式输入帧。"""
        return cls.from_bytes(Path(epicraw_path).read_bytes(), cam2_base=cam2_base, roi=roi)


@dataclass
class RuntimePassiveBinoFrame:
    """被动双目运行模式输入，封装一份 EPICRAW3 原始数据。

    用于 ``RuntimeRunParams(..., run_mode="passive_bino")``。服务端会从
    EPICRAW3 中解析三张图和统一的 ``camera_params``；SDK metadata 只额外
    传入 ``cam2_base`` 和可选 ``roi``。

    Attributes:
        epicraw3: 完整 EPICRAW3 原始字节（或可被 ``bytes()`` 转换的对象）。
        cam2_base: 相机到基坐标系的变换矩阵，服务端目前只支持旋转矢量形式：
            长度为 6 的 ``[x, y, z, rx, ry, rz]``（平移 + Rodrigues 旋转向量），
            不支持 4x4/3x4 矩阵形式。
        roi: 感兴趣区域，可选。推荐格式：
            ``{"min": {"x": ..., "y": ..., "z": ...}, "max": {...}, "cam2ROIFrame": [x, y, z, rx, ry, rz]}``。
            ``cam2ROIFrame`` 同样只支持长度为 6 的旋转矢量形式。
    """

    epicraw3: Any
    cam2_base: Any
    roi: Any = None

    def __post_init__(self):
        self.epicraw3 = bytes(self.epicraw3)
        if not self.epicraw3:
            raise ValueError("passive_bino frame is missing EPICRAW3 bytes")
        self.cam2_base = _require_cam2_base(self.cam2_base)
        self.roi = _validate_roi(self.roi)

    @classmethod
    def from_bytes(cls, epicraw3: Any, cam2_base: Any, roi: Any = None):
        """使用已有 EPICRAW3 bytes 构造 passive_bino 输入帧。"""
        return cls(epicraw3=epicraw3, cam2_base=cam2_base, roi=roi)

    @classmethod
    def from_file(cls, epicraw3_path: str | Path, cam2_base: Any, roi: Any = None):
        """读取 EPICRAW3 文件并构造 passive_bino 输入帧。"""
        path = Path(epicraw3_path)
        return cls.from_bytes(path.read_bytes(), cam2_base=cam2_base, roi=roi)

    @classmethod
    def from_images(
        cls,
        image_list: list[Any],
        params: dict[str, Any],
        cam2_base: Any,
        roi: Any = None,
    ):
        """把三张被动双目图像编码为 EPICRAW3 并构造输入帧。

        ``image_list`` 顺序固定为 ``DepthSrc1``、``DepthSrc2``、``TextureSrc``。
        ``params`` 需包含 ``DepthSrc1``、``DepthSrc2``、``TextureSrc`` 三份 metadata，每份里面结构是
        {
            "CameraMatrix": [ 2113.997971632298, 0, 1956.222038925553, 0, 2113.7299751270057, 1505.0473199581195, 0, 0, 1],
            "CameraDistortion": [ 0.049901632334, -0.037810281265, -0.00048319461, -0.000276258172, -0.026886293015],
            "CameraRotation": [ 0.9995132330503337, -0.005059159488191983, -0.030784766728731865, 0.004951704878090689, 0.9999813828533568, -0.003565748937897527, 0.030802233296787017, 0.003411576169582241, 0.999519676430619],
            "CameraTranslation": [ -25.837377992238334, -0.6852264771262435, -4.372034519324568]
        }
        """
        from .core.epicraw import make_passive_bino_epicraw3_from_images

        return cls.from_bytes(
            make_passive_bino_epicraw3_from_images(image_list, params),
            cam2_base=cam2_base,
            roi=roi,
        )


@dataclass
class RuntimeRunParams:
    """``runtime.run_graph`` 参数。

    Attributes:
        graph_name: 图名称。
        frames: 输入帧列表。普通模式下每个元素须为 :class:`RuntimeFrame`；
            ``passive_bino`` 模式下必须只传一个 :class:`RuntimePassiveBinoFrame`。
        run_mode: 运行模式。默认 ``"others"``；被动双目传 ``"passive_bino"``。
    """

    graph_name: str
    frames: list[RuntimeFrame | RuntimePassiveBinoFrame]
    run_mode: str = "others"

    @classmethod
    def passive_bino_from_bytes(
        cls,
        graph_name: str,
        epicraw3: Any,
        cam2_base: Any,
        roi: Any = None,
    ):
        """使用已有 EPICRAW3 bytes 构造 ``passive_bino`` RunGraph 参数。"""
        return cls(
            graph_name=graph_name,
            frames=[RuntimePassiveBinoFrame.from_bytes(epicraw3, cam2_base=cam2_base, roi=roi)],
            run_mode="passive_bino",
        )

    @classmethod
    def passive_bino_from_file(
        cls,
        graph_name: str,
        epicraw3_path: str | Path,
        cam2_base: Any,
        roi: Any = None,
    ):
        """读取 EPICRAW3 文件并构造 ``passive_bino`` RunGraph 参数。"""
        return cls(
            graph_name=graph_name,
            frames=[RuntimePassiveBinoFrame.from_file(epicraw3_path, cam2_base=cam2_base, roi=roi)],
            run_mode="passive_bino",
        )

    @classmethod
    def passive_bino_from_images(
        cls,
        graph_name: str,
        image_list: list[Any],
        params: dict[str, Any],
        cam2_base: Any,
        roi: Any = None,
    ):
        """把三张图编码为 EPICRAW3，并构造 ``passive_bino`` RunGraph 参数。"""
        return cls(
            graph_name=graph_name,
            frames=[
                RuntimePassiveBinoFrame.from_images(
                    image_list,
                    params,
                    cam2_base=cam2_base,
                    roi=roi,
                )
            ],
            run_mode="passive_bino",
        )

    @classmethod
    def passive_bino_from_image(
        cls,
        graph_name: str,
        image_list: list[Any],
        params: dict[str, Any],
        cam2_base: Any,
        roi: Any = None,
    ):
        """``passive_bino_from_images`` 的兼容别名。"""
        return cls.passive_bino_from_images(
            graph_name,
            image_list,
            params,
            cam2_base=cam2_base,
            roi=roi,
        )

    def __post_init__(self):
        if self.run_mode not in {"others", "passive_bino"}:
            raise ValueError("run_mode 仅支持 'others' 或 'passive_bino'")
        if self.run_mode == "passive_bino":
            if len(self.frames) != 1 or not isinstance(self.frames[0], RuntimePassiveBinoFrame):
                raise TypeError("passive_bino 模式必须传入且只传入一个 RuntimePassiveBinoFrame")
            return
        for i, frame in enumerate(self.frames):
            if not isinstance(frame, RuntimeFrame):
                raise TypeError(
                    f"frames[{i}] 须为 RuntimeFrame，实际传入了 {type(frame).__name__}"
                )


def _require_cam2_base(cam2_base: Any):
    """校验 ``cam2_base`` 是服务端目前唯一支持的旋转矢量形式。

    服务端（``EpicProInput``/``EpicProDataInput``）按 ``len(cam2Base) == 6``
    过滤输入，非 6 长度的值会被直接丢弃而不报错，因此这里提前拦截，
    避免用户传入 4x4/3x4 矩阵后请求被静默丢弃。
    """
    if cam2_base is None:
        raise TypeError("cam2_base 不能为空")
    if isinstance(cam2_base, (str, bytes)) or not hasattr(cam2_base, "__len__") or len(cam2_base) != 6:
        raise ValueError(
            "cam2_base 服务端目前只支持旋转矢量形式：长度为 6 的 [x, y, z, rx, ry, rz]"
            f"（平移 + Rodrigues 旋转向量），不支持矩阵形式，实际传入了 {cam2_base!r}"
        )
    return cam2_base


def _validate_roi(roi: Any):
    """校验 ``roi["cam2ROIFrame"]``（若提供）同样是长度为 6 的旋转矢量形式。"""
    if roi is None:
        return roi
    if not isinstance(roi, dict):
        raise TypeError(
            "roi 必须是 dict，格式为 "
            "{'min': {'x':...,'y':...,'z':...}, 'max': {...}, 'cam2ROIFrame': [x, y, z, rx, ry, rz]}"
        )
    cam2roi_frame = roi.get("cam2ROIFrame")
    if cam2roi_frame is not None and (
        isinstance(cam2roi_frame, (str, bytes))
        or not hasattr(cam2roi_frame, "__len__")
        or len(cam2roi_frame) != 6
    ):
        raise ValueError(
            "roi['cam2ROIFrame'] 服务端目前只支持旋转矢量形式：长度为 6 的 [x, y, z, rx, ry, rz]"
            f"（平移 + Rodrigues 旋转向量），不支持矩阵形式，实际传入了 {cam2roi_frame!r}"
        )
    return roi


@dataclass
class RuntimeBindingDataUpdate:
    """``runtime.set_graph_binding_data`` 参数。

    Attributes:
        graph_name: 图名称。
        binding_data: 以绑定名为 key 的绑定数据字典。
    """

    graph_name: str
    binding_data: dict[str, Any]


@dataclass
class RuntimeStrategyParamsUpdate:
    """``runtime.set_params_in_strategy`` 参数。

    当前仅适用于 ``PoseListFilter``、``PickPointFilter``、
    ``PoseListSorterInXOY``、``PickPointSorterInXOY``、
    ``PickPointSorterNew``、``PoseListSorter`` 这些策略节点。

    ``params_data`` 一般来自 ``runtime.get_node_params_info_with_strategy(...)``
    返回值中的 ``paramsData``。调用方修改需要调整的字段后，把完整
    ``paramsData`` 传回。

    Attributes:
        graph_name: 图名称。
        node_id: 节点 ID。
        params_data: 从服务端返回的 ``paramsData`` 修改而来的完整参数结构。
    """

    graph_name: str
    node_id: str
    params_data: dict[str, Any]


@dataclass
class FileParamRef:
    """``runtime.get_file_param_md5`` 参数。

    Attributes:
        graph_name: 图名称。
        param_name: 参数映射名称。
        param_type: 参数类型，默认 ``"init_params"``。
    """

    graph_name: str
    param_name: str
    param_type: str = "init_params"
